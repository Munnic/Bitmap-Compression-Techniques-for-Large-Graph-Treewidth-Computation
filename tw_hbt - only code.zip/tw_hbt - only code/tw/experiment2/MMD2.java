package tw.experiment2;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import tw.common.XBitSet;

public class MMD2 {
  static boolean TRACE_TIME = false;
  boolean TRACE_ADDED_EDGES = false;
  
  Graph g;
  static int maxDepth;
  
  int[][] nb; //List of neighbor sets for all the vertices
  int[][] h;  //Result
  int[][] byDegree; //Sorted vertices by their degree
  int byDegreeSize;
  Vertex[] vertex;
  XBitSet remaining; //Vertices that are not eliminated yet
  int nRanked;
  
  int minDegree;
  int maxDegree;
  
  static int round;
  
  static int doubleAddedEdgesMD;
  
  static int[][] substars;
  static int[][] shortSNeighbs;
  static int[][] longSNeighbs;
  
  static double sepSubLowerLimit;
  static double sepSubUpperLimit;
  
  static int[] marked;
  static int[] markedSepSub;
  
  ArrayList<Integer> lengthComps;
  static int countLengthComp;
  
  static int nSepSubs;
  
  static XBitSet verticesNotLBSimplicial;
  static int compN;
  
  long timeOrder = 0;
  long timeIsChordal = 0;
  long timeRangedBFS = 0;
  long timeBFS = 0;
  
  boolean orderNotChordal;
  
  
  public MMD2(Graph g) {  	
    this.g = g;
    nb = g.neighbor.clone(); 
    h = g.neighbor.clone();
    vertex = new Vertex[g.n];
    
    verticesNotLBSimplicial = (XBitSet) g.all.clone();
    
    for (int v = 0; v < g.n; v++) {
      vertex[v] = new Vertex(v);
    }
    
  	round = 1;
  	nSepSubs = 0;
  	doubleAddedEdgesMD  = 0; 	
  	
    substars = new int[10000][];
    shortSNeighbs = new int[10000][];
    longSNeighbs = new int[10000][];
  }
  
  
  public void runMMD2() {  
  	long timeStart = System.nanoTime();

  	order();
  	
  	/*Edges added in MD*/
  	int addedEdgesMD = doubleAddedEdgesMD / 2;
  	
  	while (!isChordal(h)) {
  		//System.out.println("round " + ++round + ", " + verticesNotLBSimplicial.cardinality() + " vertices remaining");
  		
  		/*New nb = H, with only those vertices which are not LBsimplicial*/
  		nb = new int[g.n][]; 
  		vertex = new Vertex[g.n];
      for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
      	
      	int[] newNeighbors = new int[h[v].length]; 
      	int nextElement = 0;
      	for (int i = 0; i < h[v].length; i++) {
      		int w = h[v][i];
      		if (verticesNotLBSimplicial.get(w)) {
      			newNeighbors[nextElement++] = w;
      		}
      	}
      	
      	/*copy to new nb[][]*/
      	nb[v] = new int[nextElement];
      	System.arraycopy(newNeighbors, 0, nb[v], 0, nextElement);      	
      }
      
      /*Instantiate the vertices*/
      for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){
      	vertex[v] = new Vertex(v);
      }
      order();
  	}
  	
  	long totalTime = System.nanoTime() - timeStart;
  	
  	if(TRACE_ADDED_EDGES) {  		
  		/*Edges in H*/
	  	int hEdges = 0;
	  	for (int v = 0; v < g.n; v++) {
	  		hEdges += h[v].length;
	  	} 	
	  	/*Edges of G*/
	  	int gEdges = 0;
	  	for (int i = 0; i < g.n; i++) {
	  		gEdges += g.neighbor[i].length;
	  	}
	  	int addedEdgesMMD2 = (hEdges - gEdges) / 2;  	
	  	System.out.println("   Added edges MD - MMD2: " + (addedEdgesMD - addedEdgesMMD2));
  	}
  	
  	if (TRACE_TIME) {
  		System.out.println("   Time (ms) total = " + totalTime/1000000 + ",  isChordal = " + timeIsChordal/1000000 + ",  order = " + timeOrder/1000000 + ",  completeBFS = " + timeBFS/1000000 + ",  rangedBFS = " + timeRangedBFS/1000000);
  		System.out.printf("   nSepSubs = %d",nSepSubs);
  		System.out.println();
  	} 
  	
  	System.out.print(totalTime/1000000 + "   ");
  }
    

  
  public void order() {
  	orderNotChordal = true;
  	long time0 = System.nanoTime();
    nRanked = 0;
    remaining = (XBitSet) verticesNotLBSimplicial.clone();
  	
  	/*init maxDegree*/
  	maxDegree = 0;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		if (vertex[v].degree > maxDegree)
  			maxDegree = vertex[v].degree;
  	}
  
  	byDegreeSize = maxDegree + 1;
  	
  	int[] initDegrees = new int [byDegreeSize];
  	int[] trackDegrees = new int[byDegreeSize];
  	   
    /*init minDegree*/
  	minDegree = verticesNotLBSimplicial.cardinality() - 1;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		initDegrees[vertex[v].degree]++;
  		if (vertex[v].degree < minDegree)
  			minDegree = vertex[v].degree;
  	} 	
  	
  	/*instantiate byDegree*/
    byDegree = new int[byDegreeSize][];
    for (int i = 0; i < byDegreeSize; i++) {
      byDegree[i] = new int[initDegrees[i]];
    }       
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
    	int deg = vertex[v].degree;
    	byDegree[deg][trackDegrees[deg]++] = v;
    }    
    assert nRanked == verticesNotLBSimplicial.cardinality();

    while (!remaining.isEmpty()) {
      assert nRanked == remaining.cardinality();
      
      /*Take first ranked vertex*/
      /*add substars of v to H*/
      /*remove v from byDegree*/
      /*fill the neighborhood of v*/
      Vertex vert = firstRanked();      
      int v = vert.id;       
      vert.findSubstars(remaining, true, nb);     
      vert.removeSelf(); 
      vert.fillNeighborhood();      
   
    }
    timeOrder += System.nanoTime() - time0;
  }
  



  //Determine which degree vertex we consider next, and return the vertex number with lowest degree.
  Vertex firstRanked() {
    while (byDegree[minDegree].length == 0) {
      minDegree++;
    }
    int id = byDegree[minDegree][0];
    return vertex[id];
  }
  
  
  
  /** tests if the target graph is chordal
  * added Dec 3, 2019, Hisao Tamaki
  * @return {@code true} if the target graph is chordal
  * {@code false} otherwise.
  */
	 public boolean isChordal(int[][] graph) {  
		 	orderNotChordal = false;
		 	markedSepSub = new int[g.n];
		 	long time0 = System.nanoTime();
		 	boolean result = true; 	
		 	
		 	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) { 		
		 		/*If all the neighbors form a clique. No further computation is necessary.*/
				if (isClique(graph[v],graph)) {  				
					verticesNotLBSimplicial.clear(v);
					continue;
				}
		
			/*If any of the vertices is not LBSimplicial, the graph is not Chordal*/
		   if (!vertex[v].isLBSimplicial(graph))
		       result = false;
		   }
		 	 timeIsChordal += System.nanoTime() - time0;
		   return result;
	 }
 

	

	 /**
	* Decides if the given vertex set is a clique of this target graph.
	* @param vs the vertex set
	* @return {@code true} if {@code vs} is a clique
	* {@code false} otherwise.
	*/
	 public boolean isClique(int[] vs, int[][] graph) {
		
	 	/*iterate quadratically over vs */
	for (int j = 0; j < vs.length; j++) {
		int v = vs[j];
		
		int nbCount = 0;
		for (int i = 0; i < vs.length; i++) {
			
			/*if vertex itself, continue*/
			if (v == vs[i])
				continue;
			
			/*add to nbCount until first element in neighbor[v] that is >= to vs[i]*/
			while (graph[v][nbCount] < vs[i] && nbCount < graph[v].length - 1) {
					nbCount++;
			}
			
			/*if element in vs[i] is not equal to this element in neighbor[v], return false*/
	 			if (vs[i] < graph[v][nbCount]) {
	 				return false;
	 			}		
	 		}  		
	 	}
	 	return true;  
	 }
	 
	int[] getSubstarBFS(int v, int compN, int[][] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 

      v = queue.poll();      
      for (int i = 0; i < graph[v].length; i++) {
      	int w = graph[v][i];	  			
      	if (marked[w] == 0) { 
          marked[w] = compN; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = -2;
        	substar.add(w);
        }
  		}
    }	        
    return toSortedIntArray(substar);
	}
	  
		
	int[] getSubstarBFS_Chordal(int v, int compN, int[][] graph) {
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
    
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll();

      //v in substar and already visited        
      if (marked[v] == compN - 10)
      	continue;
      
      countLengthComp++;
      
      for (int i = 0; i < graph[v].length; i++) {
      	int w = graph[v][i];	     	
      	
      	/*If already visited, continue*/
      	if(marked[w] < -1)
      		continue;
  			
      	/*If vertex not yet explored and not part of a separating substar*/
      	else if (marked[w] == 0) { 
          marked[w] = compN;             
          queue.add(w);   
  			}
      	
      	/*If we reached a neighbor*/
      	else if (marked[w] == -1) {
      		marked[w] = compN;
        	substar.add(w);
        }
      	
      	/*If we reach a vertex that is part of a separating substar
      	 *  1) check from which side we reached this substar,
      	 *  		and mark all vertices on the other side with compN.
      	 *  2) mark the entire substar and put each vertex in queue
      	 */
      	else if(marked[w] > 0) {
      		int s = markedSepSub[w];
      		int x = Arrays.binarySearch(shortSNeighbs[s], v); 
      		
      		/*v in longSNeighbs
      		 * 1) continue searching in longSNeighbs */
      		if (x < 0) {
      			for (int a = 0; a < longSNeighbs[s].length; a++) {
      				int z = longSNeighbs[s][a];
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		/*v in shortSNeighbs
      		 * 1) continue searching in shortSNeighbs*/
      		else {
      			for (int a = 0; a < shortSNeighbs[s].length; a++) {
      				int z = shortSNeighbs[s][a];
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		
      		/*mark substar with compN*/
      		for (int b = 0; b < substars[s].length; b++) {
      			int y = substars[s][b]; 
            marked[y] = compN - 10;         			
      		}        		
      	}        	
  		}
    }     
    return toSortedIntArray(substar);
	} 
	
  /*Add substar to the separating substars*/
  void addToSeparatingSubs(int[] sub, int compNumber, boolean subNoClique, int[][] graph) {
  	
  	/*Make sure that separating substars do not overlap with one another*/
  	boolean noOverlap = true;
  	for (int s : sub) {
  		if (markedSepSub[s] != 0) {
  			noOverlap = false;
  			break;
  		}      			
  	}	
  	
  	if (noOverlap) {
  		/* Mark the vertices in markedSepSub*/
  		for (int s : sub) {
  			markedSepSub[s] = nSepSubs + 1;
  		}
  		
  		/*Save the short-sided and long-sided neighbor sets of the substar*/
  		int[] neighbsCompSide = getSubNeighbors(sub, compNumber, true, graph);
  		int[] neighbsOtherSide = getSubNeighbors(sub, compNumber, false, graph);
  		
  		/*keep track of the substar, and its two neighbor sets*/
  		substars[nSepSubs + 1] = sub;  		
  		
  		if (neighbsCompSide.length > neighbsOtherSide.length) {
  			shortSNeighbs[nSepSubs + 1] = neighbsOtherSide;
  			longSNeighbs[nSepSubs + 1] = neighbsCompSide; 			
  		}
  		else {
  			shortSNeighbs[nSepSubs + 1] = neighbsCompSide;
  			longSNeighbs[nSepSubs + 1] = neighbsOtherSide; 	
  		}
  		
  		nSepSubs++;
  	}
  }
 
 
	
	/*Form the substar into a cliques*/
	void addSubstar (int[] sub) {	
  	for(int s : sub) {   		
  		int[] toAdd = Graph.removeElement(sub, s);  		
  		h[s] = Graph.getUnion(h[s], toAdd); /**O(degree1 + degree2)*/  		
  	}
	}
	
	/*marks the substar*/
	int[] markSubstar(int[] sub, int[][] graph) {			
		for(int s : sub) {
			marked[s] = nSepSubs + 10;
		}
		return marked;
	}
	
  
	/*convert ArrayList of Integers to int[] and sort*/
  int[] toSortedIntArray(ArrayList<Integer> input) {
		int[] result = new int [input.size()];
		for (int i = 0; i < input.size(); i++)
			result[i] = input.get(i);
		Arrays.sort(result);
		return result;
  }
  
  
  /*Gives the neighbors of the substars
   * If true: in the comp it separated
   * If false: in the rest of the graph*/
  int[] getSubNeighbors(int[] sub, int compNumber, boolean isComp, int[][] graph) {
  	ArrayList<Integer> result = new ArrayList<Integer>();
  	marked = markSubstar(sub, graph);

  	for (int s : sub) {
  		for (int i = 0; i < graph[s].length; i++) {
  			int v = graph[s][i];
  			if (isComp) {
	  			if (marked[v] == compNumber && !result.contains(v))
	  				result.add(v);
  			}
  			else {
  				if (marked[v] != compNumber && marked[v] != nSepSubs + 10 && !result.contains(v)) {
  					result.add(v);
  				}
  			}
  		}  		
  	}
  	return toSortedIntArray(result);
  }
  

 class Vertex  {
   int id; //number to distinguish vertex
   int degree;
   
   Vertex(int id) {
     this.id = id;
     evaluate();
   }
   
   
   
   /* ---------- MMD functions ------------------*/
   
   
   /* Finds the substars*/
   ArrayList<int[]> findSubstars(XBitSet consideredVertices, boolean addSubstarsToH, int[][] graph) {
   	ArrayList<int[]> result = new ArrayList<int[]>();
   	
   	/*Use RangedBFS to see whether a full computation of the components is needed.
   	 * Only for order()*/   	   	
   	if(orderNotChordal) {
   		boolean substarIsMaximal = false;     	
	      long time0 = System.nanoTime();
	      if (maxDepth > 0) {
	      	substarIsMaximal = rangedBFS(maxDepth, graph);
	      }      
	      timeRangedBFS += System.nanoTime() - time0;
   	
	      /*if the substar contains all neighbors of id, return all neighbors as the only substar.*/
	      if (substarIsMaximal) {
	      	result.add(graph[id]);	      	
	      	if (addSubstarsToH)
	        	addSubstar(graph[id]);    	
	      	return result;
	      }
     }
     
     /*compute all substars in their entirety*/
   	/*marked keeps track of which vertices have been visited*/ 
   	marked = new int[g.n];
   	marked = markSeparator(marked, graph);
     
     /*number of components*/
     int compN = 0;
     long time2 = System.nanoTime();
     
     for (int v = consideredVertices.nextSetBit(0); v >= 0; v = consideredVertices.nextSetBit(v + 1)) {
       if (marked[v] == 0) {        	
         compN++;
         marked = markSeparator(marked, graph);
         int[] substar = getSubstarBFS(v, compN, graph);
         if (addSubstarsToH)
         	addSubstar(substar);
         result.add(substar);
       }
     }
     timeBFS += System.nanoTime() - time2;
     return result;      
   }

   
   /* Finds the substars*/
   ArrayList<int[]> findSubstars_Chordal(XBitSet consideredVertices, boolean addSubstarsToH, int[][] graph) {
   	ArrayList<int[]> result = new ArrayList<int[]>();
   	lengthComps = new ArrayList<Integer>();
     
     /*compute all substars in their entirety*/      
   	
   	/*marked keeps track of which vertices have been visited*/
     marked = markSeparator_Chordal(graph);
     
     /*component numbering*/
     compN = -1;
     long time2 = System.nanoTime();
     
     /*We start searching from each second neighbor*/
     XBitSet secondNeighbors = getSecondNeighbors(graph);
     for (int v = secondNeighbors.nextSetBit(0); v >= 0; v = secondNeighbors.nextSetBit(v + 1)) {
       if (marked[v] >= 0) {        	
         compN--;
         countLengthComp = 0;
         marked = markSeparator(marked, graph);
         
         int[] substar = getSubstarBFS_Chordal(v, compN, graph);
         
         lengthComps.add(countLengthComp);
         result.add(substar);
       }
     }
     
   	int totalVerticesReached = 0;
   	for (int i = 0; i < lengthComps.size(); i++) {
   		totalVerticesReached += lengthComps.get(i);
   	}      
   	
   	/*Add substar to the separating substars*/ 	
     for (int i = 0; i < lengthComps.size(); i++) {
     	if (sepSubLowerLimit * totalVerticesReached < lengthComps.get(i) && lengthComps.get(i) < sepSubUpperLimit * totalVerticesReached) {
     		int compNumber = -i - 2;
     		addToSeparatingSubs(result.get(i), compNumber, true, graph);
     		break;
     	}	  
     }
     timeBFS += System.nanoTime() - time2;
     return result;      
   }

   
 	
 	
 	/*marks the separator with -1*/
 	/*Make sure that separating substars that overlap with N[id] don't count*/
 	int[] markSeparator_Chordal(int[][] graph) {
 		
 		int[] result = markedSepSub.clone();
 		
 		/*remove separating substar that overlap with id and its neighbors*/
 		if (result[id] != 0) {
 			int s = result[id];
 			for (int i = 0; i < substars[s].length; i++) {
 				result[substars[s][i]] = 0;
 			}  				
 		}
 		//Neighbors
 		for(int i = 0; i < graph[id].length; i++) {
 			int w = graph[id][i];
   		if (result[w] > 0) {
   			int s = result[w];
   			for (int j = 0; j < substars[s].length; j++) {
   				result[substars[s][j]] = 0;
   			}  				
   		} 			
 		}
 		
 		/*Mark ID and its neighbors with -1*/
 		result[id] = -1;
 		for(int i = 0; i < graph[id].length; i++) {
 			int w = graph[id][i];
 			result[w] = -1;
 		}
 		return result;
 	}
 	
   
   /*returns true if it finds a substar which is connected to all first neighbors.
    *Uses BFS to start searching from a second neighbor*/
   boolean rangedBFS(int maxDepth, int[][] graph) {    	    	
   	if (graph[id].length == 0 || graph[id].length == 1)
   		return true;
   	
   	/*mark the neighborhood*/
   	int [] markedRanged = new int[g.n];
   	markedRanged = markSeparator(markedRanged, graph);
   	
   	/*Depth keeps track of the reached depth of the vertices*/  
   	int[] depth = new int[g.n];

   	/*nReached keeps track of the amount of neighbors which have been reached*/
   	int nReached = 0;
   	
   	/*Add the first second neighbor to the queue that's not also a first neighbor*/
 		LinkedList<Integer> queue = new LinkedList<Integer>();
 		for (int i = 0; i < graph[id].length; i++) {
 			int neighb = graph[id][i];
 			for (int j = 0; j < graph[neighb].length; j++) {
 				int secondNeighb = graph[neighb][j];
 				if (markedRanged[secondNeighb] == 0) {
 					queue.add(secondNeighb);
 					markedRanged[secondNeighb] = 1;
 					break;
 				}
 			}
 			if (queue.size() == 1)
 				break;
 		}
 		
 		
 		/*If no vertices added to queue, return true*/
 		if (queue.size() == 0)
 			return true;

     while (queue.size() != 0) { 
       // Dequeue a vertex v  from queue
       int v = queue.poll();  
       
       if (depth[v] == maxDepth)
       	break;
       
       /*for each neighbor of v*/
       for (int i = 0; i < graph[v].length; i++) {
       	int w = graph[v][i];	
       	
       	if (markedRanged[w] == -2)
       		continue;        	
       	
       	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
       	else if (markedRanged[w] == 0) { 
       		markedRanged[w] = 1;
         	queue.add(w);   
         	depth[w] = depth[v] + 1;
   			}
       	
       	/*If the vertex is a first neighbor and not yet explored,
       	 * add the neighbor to reached*/
       	else if (markedRanged[w] == -1) {
       		nReached++;
       		markedRanged[w] = -2;
       		if (graph[id].length == nReached)
           	return true;
       	}
   		}
     }	
     return false;
   }


 	/*marks the separator with -1*/
 	int[] markSeparator(int[] result, int[][] graph) {
 		result[id] = -1;
 		for(int i = 0; i < graph[id].length; i++) {
 			result[graph[id][i]] = -1;
 		}
 		return result;
 	}
 	
 	
 	/** 
	  * tests if the given vertex is LB-Simplicial in the target graph
	  * added Dec 3, 2019, Hisao Tamaki
	  * @param v the vertex for which the test is performed
	  * @return {@code true} if v is LB-simplicial in the target graph, 
	  * {@code false} otherwise.
	  */
	  public boolean isLBSimplicial(int[][] graph) {
	  	ArrayList<int[]> substars;
	  	
	  	/*In the first round, use separating substars for speed up*/
	  	if (round == 1) {
	  		substars = findSubstars_Chordal(g.all, false, graph);
	  	}
	  	else {
	  		substars = findSubstars(g.all, false, graph);
	  	}
	  		
	  	for (int i = 0; i < substars.size(); i++) {
	  		if (!isClique (substars.get(i), graph))
	  			return false;
	  	}
	  	
	  	verticesNotLBSimplicial.clear(id);
	    return true;
	  }

	  
 	/*obtain second neighbors*/
 	XBitSet getSecondNeighbors(int[][] graph) {
			XBitSet secondNeighbors = new XBitSet(g.n);
			for (int i = 0; i < graph[id].length; i++) {
				int w = graph[id][i];
				for (int j = 0; j < graph[w].length; j++) {
					secondNeighbors.set(graph[w][j]);
				}
			}
		
			for (int i = 0; i < graph[id].length; i++) {
				secondNeighbors.clear(graph[id][i]);
			}
			secondNeighbors.clear(id);
			return secondNeighbors;
 	}
 	
   
   
   /* ------------------ MD functions ---------------------*/
   
   
	  /*Fill the neighborhood into a clique*/
   void fillNeighborhood() {   	
   	for(int i = 0; i < nb[id].length; i++) {  
   		int v = nb[id][i];  
   		int degreeBefore = vertex[v].degree;
   		int[] toAdd = Graph.removeElement(nb[id], v); 
   		nb[v] = Graph.getUnion(nb[v], toAdd); /**O(degree1 + degree2)*/
   		vertex[v].updateRank();
   		doubleAddedEdgesMD += vertex[v].degree - degreeBefore;
   	}
   }
   
   /*Remove vertex from byDegree and from the neighborhood of other vertices*/
   public void removeSelf() {

   	/*remove from byDegree*/
   	removeFromByDegree(degree);
   	
   	/*for each neighbor n*/
   	for(int i = 0; i < nb[id].length; i++) { 
   		int n = nb[id][i]; 
   		
   		/*delete the element from neighborhood*/
   		vertex[n].deleteElement(id);
   		
   		/*update the rank*/
   		vertex[n].updateRank(); 
   	}
   	nRanked--;
   	remaining.clear(id);
   }
   
   /*Update the rank of a vertex in byDegree*/
   public void updateRank() {
     int oldDegree = degree;
     evaluate();
     if (degree != oldDegree) {
     	removeFromByDegree(oldDegree);
       nRanked--;
       addToRanked();
     }
   }
   
   /*Add a vertex to byDegree*/
   /**This is O(n) for low degree, but O(1) for high degree */
   public void addToByDegree() {
   	
   	int newLength = byDegree[degree].length + 1;
   	
     /*Construct a new neighborhood array*/
     int[] newArray = new int[newLength]; 
     
     if(byDegree[degree].length == 0)
     	newArray[0] = id;    
     else if(id < byDegree[degree][0]) {
     	newArray[0] = id;
     	System.arraycopy(byDegree[degree], 0, newArray, 1, newLength-1);
     }
     else {	    
 	    int i = 0;
 	    while(i < byDegree[degree].length && byDegree[degree][i] < id ) {
 	    	newArray[i] = byDegree[degree][i];
 	    	i++;
 	    }
 	    newArray[i] = id;
 	    i++;
 	    while(i < newLength) {
 	    	newArray[i] = byDegree[degree][i-1];
 	    	i++;
 	    }
     }
     
     byDegree[degree] = newArray;
   } 
   
   /*Remove a vertex from byDegree*/
   public void removeFromByDegree(int deg) {
   	
   	int position = Arrays.binarySearch(byDegree[deg], 0, byDegree[deg].length, id); 
   	int newLength = byDegree[deg].length - 1;
   	
     /*Construct a new neighborhood array*/
     int[] newArray = new int[newLength];      
     if(position == 0) {
     	System.arraycopy(byDegree[deg], 1, newArray, 0, newLength);
     }
     else {
       System.arraycopy(byDegree[deg], 0, newArray, 0, position);
       System.arraycopy(byDegree[deg], position + 1, newArray, position, newLength - position);
     }
     
     byDegree[deg] = newArray;
   }
   
   public void addToRanked() {       	

   	/*If the degree is larger than byDegreeSize, byDegree is enlarged to twice its size.*/
   	if(degree >= byDegreeSize) { 
   		byDegreeSize *= 2;
   		int[][] newByDegree = new int[byDegreeSize][];
   		      
       for (int i = 0; i < byDegreeSize/2; i++) {
         newByDegree[i] = byDegree[i];
       }       
       for (int i = byDegreeSize/2; i < byDegreeSize; i++) {
       	newByDegree[i] = new int[] {};
       }  
       
       byDegree = newByDegree;  
   	}
   	
   	addToByDegree();
     nRanked++;
     
     if (degree > maxDegree)
     	maxDegree = degree;
     
     if (degree < minDegree) {
         minDegree = degree;
     }
   }

   
   /* Deletes an element from the neighborhood */
   public void deleteElement (int deleteV) { 
   	int newDegree = nb[id].length - 1;
     
     /*Find position of element to be deleted. If element not found, return*/
     int position = Arrays.binarySearch(nb[id], 0, newDegree + 1, deleteV);       
     if (position < 0) {
       return;
     } 
     
     /*Construct a new neighborhood array*/
     int[] newArray = new int[newDegree];      
     if(position == 0) {
     	System.arraycopy(nb[id], 1, newArray, 0, newDegree);
     }
     else {
	      System.arraycopy(nb[id], 0, newArray, 0, position);
	      System.arraycopy(nb[id], position + 1, newArray, position, newDegree - position);
     }
     nb[id] = newArray;
   } 
   

   //Determines the size of the average fill, needed for each vertex
   void evaluate() {
     this.degree = nb[id].length;
     assert degree > 0;
   }
   

 }

  
}












