package tw.experiment2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

public class RunExp2 {

	static boolean runPKT    = true;	
	static int numberOfRuns  = 17; //max tot 17!!! (Since we skipped some)
	static int run = 9;
	
	/**------------------  WRITE TO FILE OR NOT?????? ------------------------*/
	

	/*which data structures and algorithms do we measure?*/
	static boolean expIntsBFS 				 = true;
	static boolean expEWAHBFS 				 = false;
	static boolean expXBitPAR 			   = false;
	static boolean expRoaring12BFS  	 = false;
	static boolean expRoaring16BFS  	 = false;
	static boolean expRoaringRun16BFS  = false;

	
	
	/*For experiment these should be false*/
	static boolean startNewFile = false; //Create a new file or append to old one?
	static boolean writeToFile = false;
	static boolean writeToFileGeneral = false;
		
	
	static int edges;
	
	static long time0;
	
	public static void main (String args[]) {
		
		time0 = System.nanoTime();
		while (run <= numberOfRuns) {
			if (runPKT)  
				runPKT();
			
			run++;
			
		}
	}

	
	
	static void runPKT() {
		// n = 96, 115, 1000, 2142, 3448, 8124, 10811, 15827, 30836, 33919, 45145, 72703, 106443
		// For experiment: 105 - 444624
		
		// *1.4: int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * f) * f) * f) * f)
		// *1.2: int n = nStart; n <= nEnd; n = (int) ((int) (n * f) * f)
		
		
		
		int nStart 		 = 444624;
		int nEnd   		 = 444624;
		double f = 1.1; 
		
		AbstractMMD.maxDepth = 5;
		AbstractMMD.sepSubLowerLimit = 0.04;
		AbstractMMD.sepSubUpperLimit = 0.9;

		
		for (int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * f) * f) * f) * f)) {
			/*adjust for skip in graphs*/
			if (n == 998) {
				n = 1000;
			}
	      		   		
  		String graphName 	= "pkt_n" + n + "_k40_p0.075_seed1";
  		String path 			= "instance/pkt";
  		String graph      = "graphs/" + graphName;
  		
  		String filePath   							= "log/experiment2/FirstResults/MemoryAndTime";
  		String filePathGeneral    			= "log/experiment2/FirstResults/General";
  		String filePathContinuousMemory = "log/experiment2/FirstResults/ContinuousMemory";
  		
  		/*Read graph and tree decomposition*/
  		Graph g              = Graph.readGraph(path, graph);
  		
  		g = shuffleVertices(g, run);
  		
  		edges = 0;
  		for (int j = 0; j < g.n; j++) {
  			edges += g.neighbor[j].length;
  		}
  		edges = edges / 2;


  		System.out.println("\n\nGraph: pkt_" + n + ", n = " + g.n + ", depth = " + AbstractMMD.maxDepth);
  		
  		performExperiments(g, filePath, filePathGeneral, filePathContinuousMemory, graphName);
  		
  		long time1 = (System.nanoTime() - time0) / 1000000000;
			System.out.println("\nElapsed time since start = " + time1/3600 + " hours, " + time1%3600 + " seconds" );
  		
		}
	}
	
	
	static void performExperiments(Graph g, String filePath, String filePathGeneral, String filePathContinuousMemory, String graphName) {
		
		
		if (expIntsBFS) {
  		MMD_Ints exp1 = new MMD_Ints(g);
  		String fileName = filePath + "/Ints/BFS_Ints_" + graphName + ".csv" ;	   
  		String fileNameGeneral = filePathGeneral + "/Ints/" + graphName + ".csv" ;	
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/Ints/" + graphName + ".csv" ;	 
  		
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
  		if(writeToFileGeneral && run == 0) createNewFileGeneral(fileNameGeneral, g.n, edges);
  		
			exp1.runExperiment();
  		if (writeToFile)
  			exp1.writeToFile(fileName);
  		if(writeToFileGeneral)  		
  			exp1.writeToFileGeneral(fileNameGeneral);
		}
		
		
		if (expXBitPAR && (g.n <= 97128)) {
  		MMD_XBit exp2 = new MMD_XBit(g);
  		String fileName = filePath + "/XBitSet/PAR_XBitSet_" + graphName + ".csv" ;	
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/XBitSet/" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
			exp2.runExperiment();
  		if (writeToFile)
  			exp2.writeToFile(fileName);
		}
		
		

		
		if (expEWAHBFS) {
  		MMD_EWAH exp3 = new MMD_EWAH(g);
  		String fileName = filePath + "/EWAH/BFS_EWAH_" + graphName + ".csv" ;	
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/EWAH/" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
			exp3.runExperiment();
  		if (writeToFile)
  			exp3.writeToFile(fileName);
		}
		
		if (expRoaring12BFS) {
  		MMD_Roaring exp6 = new MMD_Roaring(g, 12, false);
  		String fileName = filePath + "/Roaring12/BFS_Roaring12_"  + graphName + ".csv" ;
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/Roaring12/" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
			exp6.runExperiment();
  		if (writeToFile)
  			exp6.writeToFile(fileName);
		}
		
		
		if (expRoaring16BFS) {
  		MMD_Roaring exp8 = new MMD_Roaring(g, 16, false);
  		String fileName = filePath + "/Roaring16/BFS_Roaring16_" + graphName + ".csv" ;	
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/Roaring16/" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
			exp8.runExperiment();
  		if (writeToFile)
  			exp8.writeToFile(fileName); 		
		}		
		
		
		if (expRoaringRun16BFS) {
  		MMD_Roaring exp8 = new MMD_Roaring(g, 16, true);
  		String fileName = filePath + "/RoaringRun16/BFS_RoaringRun16_" + graphName + ".csv" ;	
  		AbstractMMD.fileNameMemory = filePathContinuousMemory + "/RoaringRun16/" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) { 
  			createNewFile(fileName, g.n, edges);
  			createNewFileContinuousMemory(AbstractMMD.fileNameMemory, g.n, edges);
  		}
			exp8.runExperiment();
  		if (writeToFile)
  			exp8.writeToFile(fileName);
		}		
		

	}	
	
	
	
	
	private static void createNewFile(String fileName, int gn, int edges) {
		if (startNewFile) {
			File fileOld = new File(fileName);		
			fileOld.delete();
		}
		File fileNew = new File(fileName);
		
		try {
			FileWriter ps = new FileWriter(fileNew);		
			ps.write("g.n = " + gn + ", g.e = " + edges + ", nRuns =" + numberOfRuns + "\n");
			ps.write("Memory(B) G, H, MaxMemoryOrder, MaxMemoryIsChordal"
					+ ", Time(micro s) total, order, isChordal, round2, RangedBFS, FindSubstars, findSubstarsChordal");
			ps.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }	
	
	private static void createNewFileGeneral(String fileName, int gn, int edges) {
		if (startNewFile) {
			File fileOld = new File(fileName);		
			fileOld.delete();
		}
		File fileNew = new File(fileName);
		
		try {
			FileWriter ps = new FileWriter(fileNew);		
			ps.write("g.n = " + gn + ", g.e = " + edges + ", nRuns =" + numberOfRuns + "\n");
			ps.write("#sebsubs, isClique success (%), RangedBFS success (%), added edges MD, added edges MMD, added edges difference");
			ps.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }	
	
	private static void createNewFileContinuousMemory(String fileName, int gn, int edges) {
		if (startNewFile) {
			File fileOld = new File(fileName);		
			fileOld.delete();
		}
		File fileNew = new File(fileName);
		
		try {
			FileWriter ps = new FileWriter(fileNew);		
			ps.write("g.n = " + gn + ", g.e = " + edges + ", nRuns =" + numberOfRuns + "\n");
			ps.write("Memory order (10) and isChordal (10)");
			ps.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
  }	
	
	
	/*shuffle the vertices of the graph.*/
	static Graph shuffleVertices(Graph g, int seed) {
		
		/*Create random list of length g.n*/
		Random random = new Random(seed);
		Integer[] arr = new Integer[g.n];
    for (int i = 0; i < g.n; i++) {
        arr[i] = i;
    }
    Collections.shuffle(Arrays.asList(arr), random);
    
		
		//Mark all unvisited vertices with -1
		int[] verticesVisited = new int[g.n];
		for (int i = 0; i < g.n; i++) {
			verticesVisited[i] = -1;
		}
		
		int[][] oldGraph = g.neighbor.clone();

    
    LinkedList<Integer> queue = new LinkedList<Integer>();
    queue.add(arr[0]);
   
    verticesVisited[arr[0]] = arr[0]; //This is the new name of the vertex, at the position of its old name.

  	int i = 1; //Keeps track of the new numbering of the vertices. 
    while (queue.size() != 0) { 
    	
    	int v = queue.poll();
    	g.neighbor[verticesVisited[v]] = new int[oldGraph[v].length];

    	//For each neighboring vertex
    	for (int k = 0; k < oldGraph[v].length; k++) {
    		int w = oldGraph[v][k];
    		
    		//If it doesn't have a name yet, give the vertex it's new name and add to queue.
    		if(verticesVisited[w] == -1) {
    			verticesVisited[w] = arr[i]; 
    			i++;
    			queue.add(w);
    		}
    		
    		//add to neighborhood, with it's new name
    		g.neighbor[verticesVisited[v]][k] = verticesVisited[w];
    	}
    	
    	Arrays.sort(g.neighbor[verticesVisited[v]]); 	
    }
		return g; 
	}
	
	
	
	
	
	
	
	
	
	
}



















