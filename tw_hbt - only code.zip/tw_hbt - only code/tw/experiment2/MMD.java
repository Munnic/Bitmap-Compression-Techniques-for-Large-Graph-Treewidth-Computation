package tw.experiment2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Set;

import tw.common.XBitSet;

public class MMD {
  static boolean TRACE_TIME = false;
  static boolean TRACE_PROGRESS = false;
  boolean TRACE_ORDER_VS_ISCHORDAL = false;
  boolean TRACE_ADDED_EDGES = false;
  boolean showRangedBFS = false;
  
  Graph g;
  static int maxDepth;
  
  static int[] dominator; //If a vertex is dominated by another vertex, it will be included in its bag in the TD.
  int[][] nb; //List of neighbor sets for all the vertices
  int[][] h;  //Result
  int[][] byDegree; //Sorted vertices by their degree
  int byDegreeSize;
  Vertex[] vertex;
  XBitSet remaining; //Vertices that are not eliminated yet
  int nRanked;
  int minDegree;
  int maxDegree;
  int[] bagIndex;
  long fillTime;
  long deleteElementTime;
  long updateRankTime;
  int counter;
  
  static int doubleAddedEdgesMD;
  

  static int[] marked;
  static XBitSet verticesNotLBSimplicial;
  
  long timeOrder = 0;
  long timeIsChordal = 0;
  long timeRangedBFS = 0;
  long timeBFS = 0;
  
  static boolean useShortcutClique = true;
  
  boolean orderNotChordal;
  int Tries_Order = 0;
  int Success_Order = 0;
  int Tries_Chordal = 0;
  int Success_Chordal = 0;
  int Tries_Clique = 0;
  int Success_Clique = 0;
  
  
  public MMD(Graph g) {  	
    this.g = g;
    nb = g.neighbor.clone(); 
    h = g.neighbor.clone();
    vertex = new Vertex[g.n];
    
    verticesNotLBSimplicial = (XBitSet) g.all.clone();
    
    for (int v = 0; v < g.n; v++) {
      vertex[v] = new Vertex(v);
    }
  }
  
  
  public void runMMD() {  
  	long timeStart = System.nanoTime();
  	int round = 1;
  	
  	/*Edges of G*/
  	int gEdges = 0;
  	for (int i = 0; i < g.n; i++) {
  		gEdges += vertex[i].degree;
  	}
  	
  	
  	doubleAddedEdgesMD  = 0; 	

  	order();
  	
  	/*Edges added in MD*/
  	int addedEdgesMD = doubleAddedEdgesMD / 2;
  	
  	while (!isChordal(h)) {
  		//System.out.println("round " + ++round + ", " + verticesNotLBSimplicial.cardinality() + " vertices remaining");
  		
  		
  		/*New nb = H, with all LBsimplicial vertices removed*/
  		nb = new int[g.n][]; 
  		vertex = new Vertex[g.n];
      for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
      	
      	int[] newNeighbors = new int[h[v].length]; 
      	int nextElement = 0;
      	for (int i = 0; i < h[v].length; i++) {
      		
      		int w = h[v][i];
      		
      		/*only add to new nb if a potential neighbor is not LBSimplicial*/
      		if (verticesNotLBSimplicial.get(w)) {
      			newNeighbors[nextElement++] = w;
      		}
      	}
      	
      	/*copy to new nb[][]*/
      	nb[v] = new int[nextElement];
      	System.arraycopy(newNeighbors, 0, nb[v], 0, nextElement);      	
      }
      
      /*Instantiate the vertices*/
      for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){
      	vertex[v] = new Vertex(v);
      }

      order();
  	}
  	
  	long totalTime = System.nanoTime() - timeStart;
  	
  	/*Added edges in MMD*/
  	if(TRACE_ADDED_EDGES) {
	  	int hEdges = 0;
	  	for (int v = 0; v < g.n; v++) {
	  		hEdges += h[v].length;
	  	} 	
	  	int addedEdgesMMD = (hEdges - gEdges) / 2;  	
	  	System.out.println("   Added edges MD - MMD: " + (addedEdgesMD - addedEdgesMMD));
  	}
  	
  	
  	if (TRACE_ORDER_VS_ISCHORDAL) {
  		double percentageOrder = (double) Success_Order / Tries_Order * 100;
  		double percentageChordal = (double) Success_Chordal / Tries_Chordal * 100;
  		double percentageClique = (double) Success_Clique / Tries_Clique * 100;
  		
  		System.out.println("   Time (ms) total = " + totalTime/1000000 + ",  isChordal = " + timeIsChordal/1000000 + ",  order = " + timeOrder/1000000 + ",  completeBFS = " + timeBFS/1000000 + ",  rangedBFS = " + timeRangedBFS/1000000);
  		/**System.out.printf("   Success percentage rangedBFS in isChordal = %.5f,  order = %.2f", percentageChordal, percentageOrder);
  		if (useShortcutClique)
  			System.out.printf(",  shortcutClique: %.2f", percentageClique);
  		System.out.println();*/
  	}
  	
  	//System.out.println("   Vertices visited: " + verticesVisited + ", vertices polled: " + verticesPolled);
  
  	System.out.print(totalTime/1000000 + "   " );
 
  }
    

  
  public void order() {
  	orderNotChordal = true;
  	
  	long time0 = System.nanoTime();
    
    nRanked = 0;
    remaining = (XBitSet) verticesNotLBSimplicial.clone();
  	
  	
  	/*init maxDegree*/
  	maxDegree = 0;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		if (vertex[v].degree > maxDegree)
  			maxDegree = vertex[v].degree;
  	}
  
  	byDegreeSize = maxDegree + 1;
  	
  	int[] initDegrees = new int [byDegreeSize];
  	int[] trackDegrees = new int[byDegreeSize];
  	   
  	
    /*init minDegree*/
  	minDegree = verticesNotLBSimplicial.cardinality() - 1;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		initDegrees[vertex[v].degree]++;
  		if (vertex[v].degree < minDegree)
  			minDegree = vertex[v].degree;
  	} 	
  	
  	/*instantiate byDegree*/
    byDegree = new int[byDegreeSize][];
    for (int i = 0; i < byDegreeSize; i++) {
      byDegree[i] = new int[initDegrees[i]];
    }       
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
    	int deg = vertex[v].degree;
    	byDegree[deg][trackDegrees[deg]++] = v;
    }    
    assert nRanked == verticesNotLBSimplicial.cardinality();
    
    
    int count = 0;
       
         
    /**O(n) For each vertex, do:
     * - O(?) add substars of v to H
     * - O(m) remove v from bydegree and nb[][] 
     * - O(n^2) fill the neighborhood of v into a clique*/
    while (!remaining.isEmpty()) {
      assert nRanked == remaining.cardinality();
      
      /*show progress*/
      if(TRACE_PROGRESS && (g.n - nRanked) / 1000 > count) {
      	count++;
      	int eliminated = g.n - remaining.cardinality();
      	System.out.println("n = " + g.n  + "     nElimated: " + eliminated +  "     minDegree = " + minDegree + "     maxDegree = " + maxDegree);      	
      }

      /*Take first ranked vertex*/
      /*add substars of v to H*/
      /*remove v from byDegree*/
      /*fill the neighborhood of v*/
      Vertex vert = firstRanked();      
      int v = vert.id;       
      

      vert.findSubstars(remaining, true, nb);
      
      vert.removeSelf(); 
      vert.fillNeighborhood();      

      
      // update the rankings of the affected vertices
      for (int k = 0; k < nb[v].length; k++) {    	  
	    	int w = nb[v][k];  
	    	vertex[w].updateRank();
      }
      
    }
    
    timeOrder += System.nanoTime() - time0;
  }
  



  //Determine which degree vertex we consider next, and return the vertex number with lowest degree.
  Vertex firstRanked() {
    while (byDegree[minDegree].length == 0) {
      minDegree++;
    }
    int id = byDegree[minDegree][0];
    return vertex[id];
  }


  class Vertex implements Comparable<Vertex> {
    int id; //number to distinguish vertex
    int degree;
    
    Vertex(int id) {
      this.id = id;
      evaluate();
    }
    
    
    /* Finds the substars*/
    ArrayList<int[]> findSubstars(XBitSet consideredVertices, boolean addSubstarsToH, int[][] graph) {
    	
    	ArrayList<int[]> result = new ArrayList<int[]>();
    	

    	/*Use RangedBFS to see whether a full computation of the components is needed.
    	 * Only for order()*/   	   	
    	if(orderNotChordal) {
    		boolean substarIsMaximal = false; 
 	
	    	if (orderNotChordal)
	    		Tries_Order++;
	    	if (!orderNotChordal)
	    		Tries_Chordal++;
	    	
	
	      long time0 = System.nanoTime();
	      if (maxDepth > 0) {
	      	substarIsMaximal = rangedBFS(maxDepth, graph);
	      }      
	      timeRangedBFS += System.nanoTime() - time0;
    	

	      /*if the substar contains all neighbors of id, return all neighbors as the only substar.*/
	      if (substarIsMaximal) {
	      	result.add(graph[id]);
	      	
	      	if (addSubstarsToH)
	        	addSubstar(graph[id]);
	      	
	      	
	      	if (orderNotChordal)
	      		Success_Order++;
	      	else
	      		Success_Chordal++;
	      	
	      	return result;
	      }
      }
      
      
      
      /*compute all substars in their entirety*/
    	long time2 = System.nanoTime();
      /*compute the connected components and the corresponding substar*/
      /*add the edges in the substar to H
       * Add the substar to the result.
       * We only consider those vertices which are still under consideration.*/
      
    	/*marked keeps track of which vertices have been visited*/
      /*Mark the vertices in the separator with -1*/  
    	marked = new int[g.n];
    	marked = markSeparator(marked, graph);
    	
      /*number of components*/
      int nc = 0;
      
      for (int v = consideredVertices.nextSetBit(0); v >= 0; v = consideredVertices.nextSetBit(v + 1)) {
        if (marked[v] == 0) {        	
          nc++;
          marked = markSeparator(marked, graph);
          int[] substar = getSubstarBFS(v, nc, graph);
          
          if (addSubstarsToH)
          	addSubstar(substar);
          
          result.add(substar);
        }
      }
      timeBFS += System.nanoTime() - time2;
      
      return result;      
      
    }

    
    /*returns true if there is a substar which is connected to all first neighbors.
     *Uses BFS to start searching from a second neighbor*/
    boolean rangedBFS(int maxDepth, int[][] graph) {    	
    	
    	//System.out.println("\nNeighbors: " + Arrays.toString(graph[id]));
    	
    	if (graph[id].length == 0 || graph[id].length == 1)
    		return true;
    	
    	/*mark the neighborhood*/
    	int [] markedRanged = new int[g.n];
    	markedRanged = markSeparator(markedRanged, graph);
    	
    	
    	/*Depth keeps track of the reached depth of the vertices*/  
    	int[] depth = new int[g.n];


    	/*nReached keeps track of the amount of neighbors which have been reached*/
    	int nReached = 0;
    	
    	/*Add the first second neighbor to the queue that's not also a first neighbor*/
  		LinkedList<Integer> queue = new LinkedList<Integer>();
  		for (int i = 0; i < graph[id].length; i++) {
  			int neighb = graph[id][i];
  			for (int j = 0; j < graph[neighb].length; j++) {
  				int secondNeighb = graph[neighb][j];
  				if (markedRanged[secondNeighb] == 0) {
  					queue.add(secondNeighb);
  					markedRanged[secondNeighb] = 1;
  					break;
  				}
  			}
  			if (queue.size() == 1)
  				break;
  		}
  		
  		
  		/*If no vertices added to queue, return true*/
  		if (queue.size() == 0)
  			return true;

      while (queue.size() != 0) { 
        // Dequeue a vertex v  from queue
        int v = queue.poll();  
        
        if (depth[v] == maxDepth)
        	break;
        
        /*for each neighbor of v*/
        for (int i = 0; i < graph[v].length; i++) {
        	int w = graph[v][i];	
        	
        	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
        	if (markedRanged[w] == 0) { 
        		markedRanged[w] = 1;
          	queue.add(w);   
          	depth[w] = depth[v] + 1;
    			}
        	
        	/*If the vertex is a first neighbor and not yet explored,
        	 * add the neighbor to reached*/
        	if (markedRanged[w] == -1) {
        		nReached++;
        		markedRanged[w] = -2;
        		if (graph[id].length == nReached)
            	return true;
        	}
    			
    		}
      }	
      
      
      return false;

    }


  	/*marks the separator with -1*/
  	int[] markSeparator(int[] result, int[][] graph) {
  		
  		result[id] = -1;
  		
  		for(int i = 0; i < graph[id].length; i++) {
  			result[graph[id][i]] = -1;
  		}
  		return result;
  	}
  	
  	
  	/** 
	  * tests if the given vertex is LB-Simplicial in the target graph
	  * added Dec 3, 2019, Hisao Tamaki
	  * @param v the vertex for which the test is performed
	  * @return {@code true} if v is LB-simplicial in the target graph, 
	  * {@code false} otherwise.
	  */
	  public boolean isLBSimplicial(int[][] graph) {
	  	
	  	ArrayList<int[]> substars = findSubstars(g.all, false, graph);
	  	
	  	for (int i = 0; i < substars.size(); i++) {
	  		if (!isClique (substars.get(i), graph))
	  			return false;
	  	}
	  	
	  	verticesNotLBSimplicial.clear(id);
	    return true;
	  }

  	
  	
    
    
    /* ------------------ Old ---------------------*/
    
    
    /**worst case O(n^2)*/
	  /*This function could be a bit quicker. Now we first add id to the neighborhood, and then remove it. This is double work*/
    void fillNeighborhood() {   	
    	for(int i = 0; i < nb[id].length; i++) {    //for each neighbor v.
    		int v = nb[id][i];  
    		
    		int degreeBefore = vertex[v].degree;
    		
    		int[] toAdd = Graph.removeElement(nb[id], v); 
    		nb[v] = Graph.getUnion(nb[v], toAdd); /**O(degree1 + degree2)*/
    		vertex[v].updateRank();
    		
    		doubleAddedEdgesMD += vertex[v].degree - degreeBefore;
    	}
    }
    
    /*Remove vertex from byDegree and from the neighborhood of other vertices*/
    /**O(N) times ( O(neighbors) + for low degree O(n))
     * So for the relevant high degree vertices this is O(n m)*/
    public void removeSelf() {
    	
    	/*remove from byDegree*/
    	removeFromByDegree(degree,id);
    	
    	/*for each neighbor n*/
    	for(int i = 0; i < nb[id].length; i++) { 
    		int n = nb[id][i]; 
    		
    		/*delete the element from neighborhood*/
    		vertex[n].deleteElement(id);
    		
    		/*update the rank*/
    		vertex[n].updateRank(); 
    	}
    	nRanked--;
    	remaining.clear(id);
    }
    
    /*Update the rank of a vertex in byDegree*/
    /**This is O(n) for low degree, but O(1) for high degree, because that's the complexity of addToRanked and remove_BD */
    public void updateRank() {
    	long time1 = System.currentTimeMillis();
      int oldDegree = degree;
      evaluate();
      if (degree != oldDegree) {
      	removeFromByDegree(oldDegree,id);
        nRanked--;
        addToRanked();
      }
      updateRankTime += System.currentTimeMillis() - time1;
    }
    

    /**This is O(n) for low degree, but O(1) for high degree, because that's the complexity of add_BD */
    public void addToRanked() {       	

    	/*If the degree is larger than byDegreeSize, byDegree is enlarged to twice its size.*/
    	if(degree >= byDegreeSize) { 
    		byDegreeSize *= 2;
    		int[][] newByDegree = new int[byDegreeSize][];
    		      
        for (int i = 0; i < byDegreeSize/2; i++) {
          newByDegree[i] = byDegree[i];
        }       
        for (int i = byDegreeSize/2; i < byDegreeSize; i++) {
        	newByDegree[i] = new int[] {};
        }  
        
        byDegree = newByDegree;  
    	}
    	
    	addToByDegree(degree,id);
      nRanked++;
      
      if (degree > maxDegree)
      	maxDegree = degree;
      
      if (degree < minDegree) {
          minDegree = degree;
      }
    }

    
    /* Function to delete an element from the neighborhood */
    /**O(neighbors)*/
    public void deleteElement (int deleteV) { 
    	
    	long time = System.currentTimeMillis();
    	int newDegree = nb[id].length - 1;
      
      /*Find position of element to be deleted. If element not found, return*/
      int position = Arrays.binarySearch(nb[id], 0, newDegree + 1, deleteV);       
      if (position < 0) {
        return;
      } 
      
      /*Construct a new neighborhood array*/
      int[] newArray = new int[newDegree];      
      if(position == 0) {
      	System.arraycopy(nb[id], 1, newArray, 0, newDegree);
      }
      else {
	      System.arraycopy(nb[id], 0, newArray, 0, position);
	      System.arraycopy(nb[id], position + 1, newArray, position, newDegree - position);
      }
      nb[id] = newArray;
      deleteElementTime += System.currentTimeMillis() - time;
    } 
    

    //Determines the size of the average fill, needed for each vertex
    void evaluate() {
      this.degree = nb[id].length;
      assert degree > 0;
    }
    

    //Determines which vertex should be eliminated earlier.
    @Override
    public int compareTo(Vertex v) {
      if (degree == v.degree) {
        return id - v.id;
      }
      long diff = ((long) v.degree) - ((long) degree);
      if (diff < 0) {
        return -1;
      }
      else if (diff == 0){
        return v.degree - degree;
      }
      else {
        return 1;
      }
    }

    
    @Override
    public int hashCode() {
      return id;
    }

  }

  //Find the position of element 'key' in array 'arr'.
  /**public int binarySearch(int arr[], int low, int high, int key) 
  { 
      if (high < low) 
          return -1; 
      int mid = (low + high) / 2; 
      if (key == arr[mid]) 
          return mid; 
      if (key > arr[mid]) 
          return binarySearch(arr, (mid + 1), high, key); 
      return binarySearch(arr, low, (mid - 1), key); 
  }*/
  
  
  /* Returns true if arr2[] is a subset of arr1[] */
  public boolean isSubset(int arr2[], int arr1[]) { 
      int i = 0, j = 0; 
      int m = arr1.length;
      int n = arr2.length;
      
      if(m < n) 
      return false; 

      while( i < n && j < m ) 
      { 
          if( arr1[j] < arr2[i] ) 
              j++; 
          else if( arr1[j] == arr2[i] ) 
          { 
              j++; 
              i++; 
          } 
          else if( arr1[j] > arr2[i] ) 
              return false; 
      } 
        
      if( i < n ) 
          return false; 
      else
          return true; 
  } 
 
  
  //Subtract array 2 from array 1.
  public int[] subtract(int arr1[], int arr2[]) { 
	    int i = 0, j = 0; 
	    int m = arr1.length;
	    int n = arr2.length;
	    
	    int[] newArray = new int[]{};
	    int degree = 0;
	    
	    //Iterate over array 2. Collect the elements in array 1 that are not in array 2.
	    while (i < m && j < n) { 
	    	
	    	if (arr1[i] < arr2[j]) {
	    		
	    		degree++;
	  	        newArray = Arrays.copyOf(newArray, degree);
	  	        newArray[degree - 1] = arr1[i++];
	    	}
	    	else if (arr2[j] < arr1[i])
	    		j++;
	    	else {
	    		i++;
	    		j++;
	    	}
	    }
	     
	    /* Collect remaining elements of array one*/
	    while(i < m) {
	        degree++;
	        newArray = Arrays.copyOf(newArray, degree);
	        newArray[degree - 1] = arr1[i++];
	    } 
	    return newArray;    
	  }  
  
  /*Remove a vertex from byDegree*/
  /**This is O(n) for low degree, but O(1) for high degree */
  public void removeFromByDegree(int deg, int v) {
  	
  	int position = Arrays.binarySearch(byDegree[deg], 0, byDegree[deg].length, v); 
  	int newLength = byDegree[deg].length - 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength];      
    if(position == 0) {
    	System.arraycopy(byDegree[deg], 1, newArray, 0, newLength);
    }
    else {
      System.arraycopy(byDegree[deg], 0, newArray, 0, position);
      System.arraycopy(byDegree[deg], position + 1, newArray, position, newLength - position);
    }
    
    byDegree[deg] = newArray;
  }
  
  /*Add a vertex to byDegree*/
  /**This is O(n) for low degree, but O(1) for high degree */
  public void addToByDegree(int deg, int v) {
  	
  	int newLength = byDegree[deg].length + 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength]; 
    
    if(byDegree[deg].length == 0)
    	newArray[0] = v;    
    else if(v < byDegree[deg][0]) {
    	newArray[0] = v;
    	System.arraycopy(byDegree[deg], 0, newArray, 1, newLength-1);
    }
    else {	    
	    int i = 0;
	    while(i < byDegree[deg].length && byDegree[deg][i] < v ) {
	    	newArray[i] = byDegree[deg][i];
	    	i++;
	    }
	    newArray[i] = v;
	    i++;
	    while(i < newLength) {
	    	newArray[i] = byDegree[deg][i-1];
	    	i++;
	    }
    }
    
    byDegree[deg] = newArray;
  } 
  
    

  
  
  
  //Add int v to array arr
  public static int[] addVertex(int arr[], int v) { 
  	int m = arr.length;
  	
    int[] result = new int[m + 1];
    int placeOfV = -1;
    
    for (int i = 0; i < m; i++) {
    	if (arr[i] == v) {
    		return arr;
    	}
    	if (arr[i] > v) {
    		result[i] = v;
    		placeOfV = i;
    		break;
    	}
    	result[i] = arr[i];
    }
    
    if (placeOfV == -1)
    	result[m] = v;
    else
    	System.arraycopy(arr, placeOfV, result, placeOfV + 1, m - placeOfV);
         
    return result;
  } 
  

	
	
	int[] getSubstarBFS(int v, int nc, int[][] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = nc; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll(); 
      
      
      for (int i = 0; i < graph[v].length; i++) {
      	int w = graph[v][i];	
  			
      	if(marked[w] > 0)
      		continue;
      	
      	else if (marked[w] == 0) { 
          marked[w] = nc; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = nc;
        	substar.add(w);
        }
  		}
      
    }	
        
    return toSortedIntArray(substar);
	}
	
	
	void addSubstar (int[] sub) {
		
		/*Add the substar to the neighborhoods */
  	for(int s : sub) {   		

  		int[] toAdd = Graph.removeElement(sub, s);  		
  		h[s] = Graph.getUnion(h[s], toAdd); /**O(degree1 + degree2)*/  		

  	}
	}
	
   
   /** tests if the target graph is chordal
   * added Dec 3, 2019, Hisao Tamaki
   * @return {@code true} if the target graph is chordal
   * {@code false} otherwise.
   */
  public boolean isChordal(int[][] graph) {  
  	orderNotChordal = false;
  	
  	
  	long time0 = System.nanoTime();
  	
  	boolean result = true; 	
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		
  		/*If all the neighbors form a clique. No further computation is necessary.*/
  		if(useShortcutClique) {
  			Tries_Clique++;
  			if (isClique(graph[v],graph)) {
  				Success_Clique++;
  				verticesNotLBSimplicial.clear(v);
  	 			continue;
  			}
  		}
  		
  		/*If the vertex is not LBSimplicial, the graph is not Chordal*/
      if (!vertex[v].isLBSimplicial(graph)) {
        result = false;
      }
    }
  	
  	timeIsChordal += System.nanoTime() - time0;
    return result;
  }
  
  /**
   * Decides if the given vertex set is a clique of this target graph.
   * @param vs the vertex set
   * @return {@code true} if {@code vs} is a clique
   * {@code false} otherwise.
   */
  public boolean isClique(int[] vs, int[][] graph) {
	
  	/*iterate quadratically over vs */
  	for (int j = 0; j < vs.length; j++) {
  		int v = vs[j];
  		
  		int nbCount = 0;
  		for (int i = 0; i < vs.length; i++) {
  			
  			/*if vertex itself, continue*/
  			if (v == vs[i])
  				continue;
  			
  			/*add to nbCount until first element in neighbor[v] that is >= to vs[i]*/
  			while (graph[v][nbCount] < vs[i] && nbCount < graph[v].length - 1) {
					nbCount++;
  			}
  			
  			/*if vertex itself, continue*/
  			if (v == vs[i])
  				continue;
  			
  			/*if element in vs[i] is not equal to this element in neighbor[v], return false*/
  			if (vs[i] < graph[v][nbCount]) {
  				return false;
  			}		
  		}  		
  	}
  	return true;  
  }
  
	/*convert ArrayList of Integers to int[] and sort*/
  int[] toSortedIntArray(ArrayList<Integer> input) {
		int[] result = new int [input.size()];
		for (int i = 0; i < input.size(); i++)
			result[i] = input.get(i);
		Arrays.sort(result);
		return result;
  }
  
  
  boolean isSubsetSquared(ArrayList<int[]> substars) {
  	
  	if (substars.size() == 0)
  		return true;
  	
  	/*First we find the largest substar*/
  	int[] largest = substars.get(0);
  	int locationLargest = 0;
  	for (int i = 1; i < substars.size(); i++) {
  		if (substars.get(i).length > largest.length) {
  			largest = substars.get(i);
  			locationLargest = i;
  		}
  	}
  	
  	/*Then we check for each substar, whether it is a subset of the largest substar*/
  	for (int i = 1; i < substars.size(); i++) {
  		if (i != locationLargest) {
  			if (!isSubset(substars.get(i), largest))
  				return false;
  		}
  	} 
  	
  	return true;
  }
  
  
  
  
  
  
}



/**
 *    
    /*returns true if all neighbors are connected by a path of length at most 2 times depth - 1.
     *Uses BFS*
    boolean rangedBFS_Old(int maxDepth, int[][] graph) {    	
    	
    	System.out.println("\n" + Arrays.toString(graph[id]));
    	
    	if (graph[id].length == 0 || graph[id].length == 1)
    		return true;
    	
    	/*mark the neighborhood*
    	int[] markedRanged = markSeparatorShort(graph);
    	
    	/**
      System.out.println("\nneighborsMarked");
  		for (int i = 0; i < graph[id].length; i++)
  			System.out.print(markedRanged[graph[id][i]] + ", ");
  		System.out.println("}");*/
    	
    	/*Depth keeps track of the reached depth of the vertices*  
    	int[] depth = new int[g.n];

    	/*Connected keeps track of which neighbors have reached each other through a discovered path*
    	XBitSet[] connected = new XBitSet[graph[id].length];
    	for (int i = 0; i < graph[id].length; i++) {
    		connected[i] = new XBitSet(graph[id].length);
    	}
    	
    	/*Add all neighbors to queue*
  		LinkedList<Integer> queue = new LinkedList<Integer>();
  		for (int i = 0; i < graph[id].length; i++)
  			queue.add(graph[id][i]);
        
      while (queue.size() != 0) { 
        // Dequeue a vertex v  from queue
        int v = queue.poll();  
        int mark = markedRanged[v];
        
        /*for each neighbor of v*
        for (int i = 0; i < graph[v].length; i++) {
        	int w = graph[v][i];	
        	
        	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*
        	if (markedRanged[w] == 0) { 
            markedRanged[w] = mark; 
            if (depth[v] < maxDepth) {
            	queue.add(w);   
            	depth[w] = depth[v] + 1;
            }
    			}
    			
        	/*vertex is already marked and marked differently than the vertex we're exploring from, 
        	 * connect the two sets of second neighbors which reach this vertex*
        	else if (markedRanged[w] > 0 && markedRanged[w] != mark) { 
        		connected[markedRanged[w] - 1].set(markedRanged[v] - 1);
        		connected[markedRanged[v] - 1].set(markedRanged[w] - 1);
    			}

    		}
      }	

    	return isConnected(connected);
    }
    
    /*This function could perhaps be improved by starting with the largest or smallest element of connected*/
    /*if the set of second neighbors that reach each other is the complete set of neighbors, return true, otherwise return false.
     * Important to note that connected has to be symmetric. Otherwise it's not correct.* 
    boolean isConnected(XBitSet[] connected) {
    	
    	XBitSet connectedSet = (XBitSet) connected[0].clone();
    	
    	/*Add all elements which are reached to queue*
  		LinkedList<Integer> queue = new LinkedList<Integer>();
  		for (int v = connectedSet.nextSetBit(0); v >= 0; v = connectedSet.nextSetBit(v + 1))
  			queue.add(v);
    	
  		
  		while (queue.size() != 0) { 
        // Dequeue a vertex v  from queue
        int v = queue.poll();
        
        /*New vertices reached, add to connectedSet and queue*
        for (int w = connected[v].nextSetBit(0); w >= 0; w = connected[v].nextSetBit(w + 1)) {
        	if (!connectedSet.get(w)) {
        		connectedSet.set(w);
        		queue.add(w);
        		
        	}
        }
  		}
  			
  		if (connectedSet.cardinality() == connected.length) {
  			return true;
  		}
  		else
  			return false;
    }
    
  	/*marks the separator with -1*
  	int[] markSeparatorShort(int[][] graph) {
  		
  		int[] markedRanged = new int[g.n];
  		markedRanged[id] = -1;
  		 		
  		for(int i = 0; i < graph[id].length; i++) {
  			markedRanged[graph[id][i]] = i + 1;
  		}
  		return markedRanged;
  	}    
     
 * 
 * 
 */









