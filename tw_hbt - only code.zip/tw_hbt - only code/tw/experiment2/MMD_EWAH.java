package tw.experiment2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import com.googlecode.javaewah.*;

import tw.common.XBitSet;

public class MMD_EWAH extends AbstractMMD <EWAHCompressedBitmap> {

	public MMD_EWAH(Graph g) {
		super(g);
		this.g = g;
		this.nb = new EWAHCompressedBitmap[g.n];
		this.h = new EWAHCompressedBitmap[g.n];
		System.out.println("EWAH");
	}

	/*Cast the from int[] to the data structure*/
	@Override
	EWAHCompressedBitmap cast(int[] set) {		
		EWAHCompressedBitmap result = EWAHCompressedBitmap.bitmapOf(set);
		return result;
	}
	
	@Override
	int getDegree(int v, EWAHCompressedBitmap[] graph){
		return graph[v].cardinality();
	}


	@Override
	void removeSelf(int id) {
	 	/*remove from byDegree*/
	 	removeFromByDegree(id, nb[id].cardinality());
	 	
	 	/*for each neighbor n*/
	 	IntIterator iter = nb[id].intIterator();
    while (iter.hasNext()) {
    	int n = iter.next(); 
	 		int degreeBefore = nb[n].cardinality();

	 		/*delete id from neighborhood*/
	 		deleteElement(n, id);

	 		/*update the rank*/
	 		updateRank(n, degreeBefore); 
	 	}
	 	nRanked--;
	 	remaining.clear(id);	
	}
	
	 /* Deletes an element deleteV from the neighborhood of ID */
	 public void deleteElement (int id, int deleteV) { 
	 	nb[id].clear(deleteV);
	 } 
	 
	 
	void fillNeighborhood(int id) {   	
		IntIterator iter = nb[id].intIterator();
	  while (iter.hasNext()) {
	    int v = iter.next(); 
		 	int degreeBefore = nb[v].cardinality(); 
		 	
	 		nb[v] = nb[v].or(nb[id]);	
	 		nb[v].clear(v);	
	 		
	 		updateRank(v, degreeBefore);
	 		doubleAddedEdgesMD += nb[v].cardinality() - degreeBefore;
		}
	}


	@Override
	boolean rangedBFS(int id, int maxDepth, EWAHCompressedBitmap[] graph) {
	 	if (graph[id].cardinality() == 0 || graph[id].cardinality() == 1)
	 		return true;
	 	
	 	/*mark the neighborhood*/
	 	int [] markedRanged = new int[g.n];
	 	markedRanged = markSeparator(id, markedRanged, graph);
	 	
	 	/*Depth keeps track of the reached depth of the vertices*/  
	 	int[] depth = new int[g.n];

	 	/*nReached keeps track of the amount of neighbors which have been reached*/
	 	int nReached = 0;
	 	
	 	/*Add the first second neighbor to the queue that's not also a first neighbor*/
		LinkedList<Integer> queue = new LinkedList<Integer>();
		IntIterator iter = graph[id].intIterator();
	  while (iter.hasNext()) {
	    int neighb = iter.next(); 
			IntIterator iter2 = nb[neighb].intIterator();
		  while (iter2.hasNext()) {
		    int secondNeighb = iter2.next(); 
				if (markedRanged[secondNeighb] == 0) {
					queue.add(secondNeighb);
					markedRanged[secondNeighb] = 1;
					break;
				}
			}
			if (queue.size() == 1)
				break;
		}
		
		
		/*If no vertices added to queue, return true*/
		if (queue.size() == 0)
			return true;

	   while (queue.size() != 0) { 
	     // Dequeue a vertex v  from queue
	     int v = queue.poll();  
	     
	     if (depth[v] == maxDepth)
	     	break;
	     
	     /*for each neighbor of v*/
	 		IntIterator iter3 = graph[v].intIterator();
		  while (iter3.hasNext()) {
		    int w = iter3.next(); 
	     	
	     	if (markedRanged[w] == -2)
	     		continue;        	
	     	
	     	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
	     	else if (markedRanged[w] == 0) { 
	     		markedRanged[w] = 1;
	       	queue.add(w);   
	       	depth[w] = depth[v] + 1;
	 			}
	     	
	     	/*If the vertex is a first neighbor and not yet explored,
	     	 * add the neighbor to reached*/
	     	else if (markedRanged[w] == -1) {
	     		nReached++;
	     		markedRanged[w] = -2;
	     		if (graph[id].cardinality() == nReached)
	         	return true;
	     	}
	 		}
	   }	
	   return false;
	 }

	@Override
	/*Form the substar into a cliques in H*/
	void addSubstarToH (EWAHCompressedBitmap sub) {	
		IntIterator iter = sub.intIterator();
	  while (iter.hasNext()) {
	  	int s = iter.next(); 
  		h[s] = h[s].or(sub);
  		h[s].clear(s);	
  	}
	}

	@Override
	/*marks the separator with -1*/
	int[] markSeparator(int id, int[] mar, EWAHCompressedBitmap[] graph) {
		mar[id] = -1;
		IntIterator iter = graph[id].intIterator();
	  while (iter.hasNext()) {
	  	int v = iter.next();
	    mar[v] = -1;
		}
		return mar;
	}

	@Override
	EWAHCompressedBitmap getSubstarBFS(int v, int compN, EWAHCompressedBitmap[] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 

      v = queue.poll();   
      
  		IntIterator iter = graph[v].intIterator();
  	  while (iter.hasNext()) {
  	    int w = iter.next(); 
  	    
  	    if (marked[w] > 0)
      		continue;
        			
      	if (marked[w] == 0) { 
          marked[w] = compN; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = -2;
        	substar.add(w); 
        }
  		}
    }	        
    return arrayListToDataStructure(substar);
	}

	@Override
	EWAHCompressedBitmap arrayListToDataStructure(ArrayList<Integer> list) {
		EWAHCompressedBitmap result = new EWAHCompressedBitmap();
		Collections.sort(list);
		for (int i = 0; i < list.size(); i++) {
			result.set(list.get(i));
		}
		return result;
  }

	/*Seems correct*/
	@Override
	boolean isClique(EWAHCompressedBitmap vs, EWAHCompressedBitmap[] graph) {
		 
		if(vs.cardinality() == 0 || vs.cardinality() == 1)
			return true;

		IntIterator iter = vs.intIterator();
	  while (iter.hasNext()) {
	    int v = iter.next(); 		

	    if (graph[v].and(vs).cardinality() != vs.cardinality() - 1)
	    	return false; 		
		 	}
		return true;  
	}


	@Override
	EWAHCompressedBitmap[] setUpRound2() {
		/*New nb = H, with only those vertices which are not LBsimplicial*/
		EWAHCompressedBitmap[] result = new EWAHCompressedBitmap[g.n]; 
		
		/*Convert verticesNotLBSimplicial to vertsNotLBS*/
		EWAHCompressedBitmap vertsNotLBS = new EWAHCompressedBitmap();
    for (int k = verticesNotLBSimplicial.nextSetBit(0); k >= 0; k = verticesNotLBSimplicial.nextSetBit(k+1))
    	vertsNotLBS.set(k);
		
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
    	result[v] = h[v].and(vertsNotLBS);
    }
    return result;
	}



	@Override
	int[] markSeparator_Chordal(int id, EWAHCompressedBitmap[] graph) {
		int[] result = markedSepSub.clone();
		
		/*remove separating substar that overlap with id and its neighbors*/
		if (result[id] != 0) {
			int s = result[id];
			
			IntIterator iter = substars[s].intIterator();
		  while (iter.hasNext()) { 
		    result[iter.next()] = 0;
			}  				
		}
		//Neighbors
		IntIterator iter = graph[id].intIterator();
	  while (iter.hasNext()) {
	    int w = iter.next(); 

	 		if (result[w] > 0) {
	 			int s = result[w];
	 			IntIterator iter2 = substars[s].intIterator();
			  while (iter2.hasNext()) {
			    result[iter2.next()] = 0;
	 			}  				
	 		} 			
		}
		
		/*Mark ID and its neighbors with -1*/
		result[id] = -1;
		IntIterator iter3 = graph[id].intIterator();
	  while (iter3.hasNext()) {
	  	result[iter3.next()] = -1;
		}
		return result;
	}

	@Override
	XBitSet getSecondNeighbors(int id, EWAHCompressedBitmap[] graph) {
		XBitSet secondNeighbors = new XBitSet(g.n);
		
		IntIterator iter = graph[id].intIterator();
	  while (iter.hasNext()) {
	    int w = iter.next();
	    
	    IntIterator iter2 = graph[w].intIterator();
		  while (iter2.hasNext()) {
		  	secondNeighbors.set(iter2.next());
		  }
		}
	
	  IntIterator iter3 = graph[id].intIterator();
	  while (iter3.hasNext()) {
	  	secondNeighbors.clear(iter3.next());
	  }
		secondNeighbors.clear(id);
		return secondNeighbors;
	}

	@Override
	EWAHCompressedBitmap getSubstarBFS_Chordal(int v, int compN, EWAHCompressedBitmap[] graph) {
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
    
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll();

      //v in substar and already visited        
      if (marked[v] == compN - 10)
      	continue;
      
      countLengthComp++;
      
      IntIterator iter = graph[v].intIterator();
  	  while (iter.hasNext()) {
  	    int w = iter.next();     	
      	
      	/*If already visited, continue*/
      	if(marked[w] < -1)
      		continue;
  			
      	/*If vertex not yet explored and not part of a separating substar*/
      	else if (marked[w] == 0) { 
          marked[w] = compN;             
          queue.add(w);   
  			}
      	
      	/*If we reached a neighbor*/
      	else if (marked[w] == -1) {
      		marked[w] = compN;
        	substar.add(w);
        }
      	
      	/*If we reach a vertex that is part of a separating substar
      	 *  1) check from which side we reached this substar,
      	 *  		and mark all vertices on the other side with compN.
      	 *  2) mark the entire substar and put each vertex in queue
      	 */
      	else if(marked[w] > 0) {
      		int s = markedSepSub[w];
      		
      		if (!shortSNeighbs[s].get(v)) {
      		/*v in longSNeighbs
      		 * 1) continue searching in longSNeighbs */
      			if (!shortSNeighbs[s].get(v)) {
      				
	    				IntIterator iter2 = longSNeighbs[s].intIterator();
	    			  while (iter2.hasNext()) {
	    			    int z = iter2.next();	
	      				if (marked[z] == 0) {
	                marked[z] = compN;               
	                queue.add(z);  
	      				}
	            	else if (marked[z] == -1) {
	            		marked[z] = compN;
	              	substar.add(z);
	              }
	      			}
      			}
      		}
      		/*v in shortSNeighbs
      		 * 1) continue searching in shortSNeighbs*/
      		else {
      			IntIterator iter2 = shortSNeighbs[s].intIterator();
    			  while (iter2.hasNext()) {
    			    int z = iter2.next();
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		
      		/*mark substar with compN*/
    			IntIterator iter3 = substars[s].intIterator();
  			  while (iter3.hasNext()) {
  			    int y = iter3.next();	
            marked[y] = compN - 10;         			
      		}        		
      	}        	
  		}
    }     
    return arrayListToDataStructure(substar);
	}

	@Override
	int[] markSubstar(EWAHCompressedBitmap sub, EWAHCompressedBitmap[] graph) {	
		IntIterator iter = sub.intIterator();
	  while (iter.hasNext()) {
			marked[iter.next()] = nSepSubs + 10;
		}
		return marked;
	}

	@Override
	EWAHCompressedBitmap getSubNeighbors(EWAHCompressedBitmap sub, int compNumber, boolean isComp, EWAHCompressedBitmap[] graph) {
  	ArrayList<Integer> result = new ArrayList<Integer>();
  	marked = markSubstar(sub, graph);

  	IntIterator iter = sub.intIterator();
	  while (iter.hasNext()) {
	  	int s = iter.next();
	  	
	  	IntIterator iter2 = graph[s].intIterator();
		  while (iter2.hasNext()) {
		  	int v = iter2.next();
  
  			if (isComp) {
	  			if (marked[v] == compNumber && !result.contains(v))
	  				result.add(v);
  			}
  			else {
  				if (marked[v] != compNumber && marked[v] != nSepSubs + 10 && !result.contains(v)) {
  					result.add(v);
  				}
  			}
  		}  		
  	}
  	return arrayListToDataStructure(result);
  }

	@Override
	void addToSeparatingSubs(EWAHCompressedBitmap sub, int compNumber, boolean subNoClique,	EWAHCompressedBitmap[] graph) {
  	/*Make sure that separating substars do not overlap with one another*/
  	boolean noOverlap = true;
  	
  	IntIterator iter = sub.intIterator();
	  while (iter.hasNext()) {
	  	if (markedSepSub[iter.next()] != 0) {
	  		noOverlap = false;
	  		break;
  		}      			
  	}	
  	
  	if (noOverlap) {
  		/* Mark the vertices in markedSepSub*/
  		for (int s : sub) {
  			markedSepSub[s] = nSepSubs + 1;
  		}
  		
  		/*Save the short-sided and long-sided neighbor sets of the substar*/
  		EWAHCompressedBitmap neighbsCompSide = getSubNeighbors(sub, compNumber, true, graph);
  		EWAHCompressedBitmap neighbsOtherSide = getSubNeighbors(sub, compNumber, false, graph);
  		
  		/*keep track of the substar, and its two neighbor sets*/
  		substars[nSepSubs + 1] = sub;  		
  		
  		if (neighbsCompSide.cardinality() > neighbsOtherSide.cardinality()) {
  			shortSNeighbs[nSepSubs + 1] = neighbsOtherSide;
  			longSNeighbs[nSepSubs + 1] = neighbsCompSide; 			
  		}
  		else {
  			shortSNeighbs[nSepSubs + 1] = neighbsCompSide;
  			longSNeighbs[nSepSubs + 1] = neighbsOtherSide; 	
  		}
  		
  		nSepSubs++;
  	}
  }
	
	@Override
	EWAHCompressedBitmap cloneBuiltIn(EWAHCompressedBitmap set) {
		return set.clone();
	}

	@Override
	EWAHCompressedBitmap[] initiateSubstars(int length) {
		EWAHCompressedBitmap[] result = new EWAHCompressedBitmap[length];
		return result;
	}

	@Override
	void printVertexSet(EWAHCompressedBitmap vs) {
		// TODO Auto-generated method stub
		
	}
	

}










