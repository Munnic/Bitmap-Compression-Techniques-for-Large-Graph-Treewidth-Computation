package tw.experiment2;

import java.util.ArrayList;
import java.util.Arrays;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;

import tw.common.XBitSet;

public abstract class AbstractMMD<T> {
	
  boolean TRACE_TIME = true;
  boolean TRACE_MEMORY = true;
  boolean TRACE_ADDED_EDGES = true;
  boolean TRACE_IMPROVEMENTS = false;
  
  Graph g;
  static int maxDepth;
  
  T[] nb;
  T[] h; //result
  int[][] byDegree; //Sorted vertices by their degree
  int byDegreeSize;
  XBitSet remaining; //Vertices that are not eliminated yet
  int nRanked;
  int[] initDegrees;
  
  int minDegree;
  int maxDegree;
  
  static int round;
  
  static int doubleAddedEdgesMD;
  
  /*These were static in MMD2*/
  T[] substars;
  T[] shortSNeighbs;
  T[] longSNeighbs;
  
  static double sepSubLowerLimit;
  static double sepSubUpperLimit;
  
  static int[] marked;
  static int[] markedSepSub;
  
  ArrayList<Integer> lengthComps;
  static int countLengthComp;
  
  static int nSepSubs;
  static int cliqueTries;
  static int cliqueSuccess;
  static int rangedBFSTries;
  static int rangedBFSSuccess;
  
  static XBitSet verticesNotLBSimplicial;
  static int compN;
  
 
  long timeOrder = 0;
  long timeIsChordal = 0;
  long timeRangedBFS = 0;
  long timeFindSubstars = 0;
  long timeFindSubstarsChordal = 0;
  long totalTime;
  long totalTimeCorrection;
  int addedEdgesMD;
  long round2Start = 0;
  long timeRound2 = 0;
  
  Runtime runtime = Runtime.getRuntime();
  long memoryG;
  long memoryH;
  long maxMemoryIsChordal;
  long maxMemoryOrder;
  long memoryStart;
  static String fileNameMemory; 
  
  boolean orderNotChordal;
	

  public AbstractMMD(Graph g) {  	
  	
  	memoryStart = measureMemoryForceGC();
  	
    this.g = g;
    nb = (T[]) new Object[g.n];
    h = (T[]) new Object[g.n];
    substars = (T[]) new Object[1000];
    shortSNeighbs = (T[]) new Object[1000];
    longSNeighbs = (T[]) new Object[1000];
    
    verticesNotLBSimplicial = (XBitSet) g.all.clone();
    
  	round = 1;
  	nSepSubs = 0;
  	doubleAddedEdgesMD  = 0; 	
  	cliqueTries = 0;
  	cliqueSuccess = 0;
  	rangedBFSTries = 0;
  	rangedBFSSuccess = 0;
  	maxMemoryIsChordal = 0;
  	maxMemoryOrder = 0;
  	totalTimeCorrection = 0;
  	
  }
  
  
  /*Abstract methods*/
  /*General*/
  abstract T cast(int[] set); /*Cast the from int[] to the data structure*/
	abstract int getDegree(int v, T[] graph);
	abstract T[] setUpRound2();
	abstract T cloneBuiltIn(T set);
	
	/*MD*/
	abstract void removeSelf(int v);
	abstract void fillNeighborhood(int id);
	
	/*MMD.order()*/
	abstract boolean rangedBFS(int id, int maxDepth, T[] graph);
	abstract void addSubstarToH (T sub);
	abstract int[] markSeparator(int id, int[] mar, T[] graph);
	abstract T getSubstarBFS(int v, int compN, T[] graph);
	abstract T arrayListToDataStructure(ArrayList<Integer> list);
	
	/*MMD.isChordal()*/
	abstract boolean isClique(T vs, T[] graph);
	abstract int[] markSeparator_Chordal(int id, T[] graph);
	abstract XBitSet getSecondNeighbors(int id, T[] graph);
	abstract T getSubstarBFS_Chordal(int v, int compN, T[] graph);	
	
	/*Add to separating subs*/
	abstract int[] markSubstar(T sub, T[] graph);
	abstract T getSubNeighbors(T sub, int compNumber, boolean isComp, T[] graph);
	abstract void addToSeparatingSubs(T sub, int compNumber, boolean subNoClique, T[] graph);
	abstract T[] initiateSubstars(int length);
	
	abstract void printVertexSet(T vs);
	
	
	
	
  public void runExperiment() {
  	long timeStart = System.nanoTime();
  	  	
  	/*Cast graph to nb and h*/
  	long memory1 = measureMemoryForceGC();	
		for (int v = 0; v < g.n; v ++) {
			nb[v] = cast(g.neighbor[v]);
		}
		
		long time0 = System.nanoTime();
		memoryG = measureMemoryForceGC() - memory1;
		totalTimeCorrection += System.nanoTime() - time0;
		
		for (int v = 0; v < g.n; v ++) {
			h[v] = cast(g.neighbor[v]);
		}
		
		/*Initiate substars, longNeighbs and shortNeighbs*/
    substars = initiateSubstars(substars.length);
    shortSNeighbs = initiateSubstars(shortSNeighbs.length);
    longSNeighbs = initiateSubstars(longSNeighbs.length);
		

  	order();
  	
  	
  	/*Edges added in MD*/
  	addedEdgesMD = doubleAddedEdgesMD / 2;

  	while (!isChordal(h)) {
  		
  		if(round == 1)
  			round2Start = System.nanoTime();
  		
  		System.out.println("   round " + ++round + ", " + verticesNotLBSimplicial.cardinality() + " vertices remaining");
  		
  		nb = setUpRound2();
  		
  		if (round == 5) {
  			System.out.println("verticesNotLBSimplicial: " + verticesNotLBSimplicial);
  			System.out.println("nb = ");
  			for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){
  				printVertexSet(nb[v]);
  			}
  			
  			System.out.println("first 20 elements in nb:");
  			for(int v = 0; v < 20; v++) {
  				printVertexSet(nb[v]);
  			}
  			
  			System.exit(1);
  			
  		}
  		
  		
      order();
  	}
  	
  	if (round2Start != 0)
  		timeRound2 = System.nanoTime() - round2Start;
  	
  	totalTime = System.nanoTime() - timeStart - totalTimeCorrection;
  	 
  	long memory2 = measureMemoryForceGC();
		T[] h2 = (T[]) new Object[g.n];					
		for (int v = 0; v < g.n; v ++) {
			h2[v] = cloneBuiltIn(h[v]);
		}		
		memoryH = measureMemoryForceGC() - memory2;
		h2[4] = nb[4];
  		
  	printStuff();
  }
  
  
  public void order() {
  	orderNotChordal = true;
  	long time0 = System.nanoTime();
    nRanked = 0;
    remaining = (XBitSet) verticesNotLBSimplicial.clone();
    boolean newLine = true;
  	
  	/*init maxDegree, minDegree, and byDegree*/
  	maxDegree = getMaxDegree(nb);
  	byDegreeSize = maxDegree + 1;
  	initDegrees = new int [byDegreeSize];
  	minDegree = getMinDegree(nb);
  	getByDegree(nb);

    /*Take first ranked vertex*/
    /*  add substars of v to H*/
    /*  remove v from byDegree*/
    /*  fill the neighborhood of v*/
    while (!remaining.isEmpty()) {
    	
		 	/*Measure memory*/
	    int measureMemory = remaining.cardinality() % (g.n / 10); 
	    if (measureMemory == 0 && round == 1) {
	    	long time1 = System.nanoTime();
	    	long memory = measureMemoryForceGC() - memoryStart;
	    	if (RunExp2.writeToFile)
	    		writeToFileMemoryContinuous(fileNameMemory, memory, newLine);
	    	newLine = false;
	    	if (memory > maxMemoryOrder)
	    		maxMemoryOrder = memory;
		    long timeMeasuring = System.nanoTime() - time1;
		    timeOrder -= timeMeasuring;
		    totalTimeCorrection += timeMeasuring;
	  	}

    	
      assert nRanked == remaining.cardinality();   
      int v = firstRanked();        
      findSubstars(v, remaining, true, nb);     
      fillNeighborhood(v);      
      removeSelf(v);
    }
    timeOrder += System.nanoTime() - time0;
  }
  
  
  /** tests if the target graph is chordal
  * added Dec 3, 2019, Hisao Tamaki
  * @return {@code true} if the target graph is chordal
  * {@code false} otherwise.
  */
	 public boolean isChordal(T[] graph) {   
		 
		 	orderNotChordal = false;
		 	markedSepSub = new int[g.n];
		 	long time0 = System.nanoTime();
		 	boolean result = true; 	
		 	
		 	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) { 		
		 		
		 		
			 	/*Measure memory, subtract time */
		    int measureMemory = verticesNotLBSimplicial.cardinality() % (g.n / 10); 
		    if (measureMemory == 0 && round == 1) {
		    	long time1 = System.nanoTime();
		    	long memory0 = measureMemoryForceGC() - memoryStart;
		    	if (RunExp2.writeToFile)
		    		writeToFileMemoryContinuous(fileNameMemory, memory0, false);
		    	if (memory0 > maxMemoryIsChordal)
		    		maxMemoryIsChordal = memory0;
			    long timeMeasuring = System.nanoTime() - time1;
			    timeIsChordal -= timeMeasuring;
			    totalTimeCorrection += timeMeasuring;
		  	}
		 		
		 		
		 		/*If all the neighbors form a clique. No further computation is necessary.*/
		    cliqueTries++;
				if (isClique(graph[v], graph)) {  
					cliqueSuccess++;
					verticesNotLBSimplicial.clear(v);
					continue;
				}
		
			/*If any of the vertices is not LBSimplicial, the graph is not Chordal*/
		   if (!isLBSimplicial(v, graph))
		       result = false;
		   }
		 	
		 	 timeIsChordal += System.nanoTime() - time0;
		   return result;
	 }
	 
	  	 
	 /** 
	  * tests if the given vertex is LB-Simplicial in the target graph
	  * added Dec 3, 2019, Hisao Tamaki
	  * @param v the vertex for which the test is performed
	  * @return {@code true} if v is LB-simplicial in the target graph, 
	  * {@code false} otherwise.
	  */
	  public boolean isLBSimplicial(int id, T[] graph) {
	  	ArrayList<T> substars;
	  	
	  	if (round == 1) {
	  		substars = findSubstars_Chordal(id, g.all, false, graph);
	  	}
	  	else {
	  		substars = findSubstars(id, g.all, false, graph);
	  	}
	  		
	  	for (int i = 0; i < substars.size(); i++) {
	  		if (!isClique (substars.get(i), graph))
	  			return false;
	  	}
	  	
	  	verticesNotLBSimplicial.clear(id);
	    return true;
	  }
	  
	  
	  /* Finds the substars*/
	  ArrayList<T> findSubstars_Chordal(int id, XBitSet consideredVertices, boolean addSubstarsToH, T[] graph) {
	  	long time2 = System.nanoTime();
	  	
	  	ArrayList<T> result = new ArrayList<T>();
	  	lengthComps = new ArrayList<Integer>();
	    
	    /*compute all substars in their entirety*/      
	  	
	  	/*marked keeps track of which vertices have been visited*/
	    marked = markSeparator_Chordal(id, graph);
	    
	    /*component numbering*/
	    compN = -1;
	    
	    /*We start searching from each second neighbor*/
	    XBitSet secondNeighbors = getSecondNeighbors(id, graph);
	    for (int v = secondNeighbors.nextSetBit(0); v >= 0; v = secondNeighbors.nextSetBit(v + 1)) {
	      if (marked[v] >= 0) {        	
	        compN--;
	        countLengthComp = 0;
	        marked = markSeparator(id, marked, graph);
	        
	        T substar = getSubstarBFS_Chordal(v, compN, graph);
	        
	        lengthComps.add(countLengthComp);
	        result.add(substar);
	      }
	    }
	    
	  	int totalVerticesReached = 0;
	  	for (int i = 0; i < lengthComps.size(); i++) {
	  		totalVerticesReached += lengthComps.get(i);
	  	}      
	  	
	  	/*Add substar to the separating substars*/ 	
	    for (int i = 0; i < lengthComps.size(); i++) {
	    	if (sepSubLowerLimit * totalVerticesReached < lengthComps.get(i) && lengthComps.get(i) < sepSubUpperLimit * totalVerticesReached) {
	    		int compNumber = -i - 2;
	    		
	    		addToSeparatingSubs(result.get(i), compNumber, true, graph);
	    		break;
	    	}	  
	    }
	    	    
	    timeFindSubstarsChordal += System.nanoTime() - time2;
	    return result;      
	  }
  
    
  
  /* Finds the substars*/
  ArrayList<T> findSubstars(int id, XBitSet consideredVertices, boolean addSubstarsToH, T[] graph) {
  	ArrayList<T> result = new ArrayList<T>();
  	
  	/*Use RangedBFS to see whether a full computation of the components is needed.
  	 * Only for order()*/	
  	if(orderNotChordal) {
  		long time0 = System.nanoTime();
  		rangedBFSTries++; 		
  		boolean substarIsMaximal = false;     	
	    if (maxDepth > 0) {
	     	substarIsMaximal = rangedBFS(id, maxDepth, graph);
	    }      
	    timeRangedBFS += System.nanoTime() - time0;
	
	    /*if the substar contains all neighbors of id, return all neighbors as the only substar.*/
	    if (substarIsMaximal) {
	    	rangedBFSSuccess++;
	    	result.add(graph[id]);	      	
	    	if (addSubstarsToH)
	      	addSubstarToH(graph[id]);    	
	    	return result;
	    }
    }
    
    /*compute all substars in their entirety*/
  	/*marked keeps track of which vertices have been visited*/ 
  	marked = new int[g.n];
  	marked = markSeparator(id, marked, graph);
    
    /*number of components*/
    int compN = 0;
    long time2 = System.nanoTime();
    
    for (int v = consideredVertices.nextSetBit(0); v >= 0; v = consideredVertices.nextSetBit(v + 1)) {
      if (marked[v] == 0) {        	
        compN++;
        marked = markSeparator(id, marked, graph);
        T substar = getSubstarBFS(v, compN, graph);
        if (addSubstarsToH)
        	addSubstarToH(substar);
        result.add(substar);
      }
    }
    timeFindSubstars += System.nanoTime() - time2;
    
    return result;      
  }
  
  
  
  
  int getMaxDegree(T[] graph) {
  	int maxDegree = 0;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		int degree = getDegree(v, graph);
  		if (degree > maxDegree)
  			maxDegree = degree;
  	}
  	return maxDegree;
  }
  
  int getMinDegree(T[] graph) {
  	minDegree = verticesNotLBSimplicial.cardinality() - 1;
  	for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
  		int degree = getDegree(v, graph);
  		initDegrees[degree]++;
  		if (degree < minDegree)
  			minDegree = degree;
  	} 	
  	return minDegree;
  }
  
  /*instantiate byDegree*/
  void getByDegree(T[] graph) {
    byDegree = new int[byDegreeSize][];
    int[] trackDegrees = new int[byDegreeSize];
    for (int i = 0; i < byDegreeSize; i++) {
      byDegree[i] = new int[initDegrees[i]];
    }       
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)) {
    
    	int degree = getDegree(v, graph);	
    	byDegree[degree][trackDegrees[degree]++] = v;
    	
    }    
    assert nRanked == verticesNotLBSimplicial.cardinality();
  }
  
  //Determine which degree vertex we consider next, and return the vertex number with lowest degree.
  int firstRanked() {
    while (byDegree[minDegree].length == 0) {
      minDegree++;
    }
    return byDegree[minDegree][0];
  }
  

  /*Update the rank of a vertex in byDegree*/
  public void updateRank(int id, int oldDegree) {
    if (getDegree(id, nb) != oldDegree) {    	
    	removeFromByDegree(id, oldDegree);
      addToRanked(id);
    }
  }
  
  /*Remove a vertex from byDegree*/
  public void removeFromByDegree(int id, int deg) {
  	int position = Arrays.binarySearch(byDegree[deg], 0, byDegree[deg].length, id); 
  	int newLength = byDegree[deg].length - 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength];      
    if(position == 0) {
    	System.arraycopy(byDegree[deg], 1, newArray, 0, newLength);
    }
    else {
      System.arraycopy(byDegree[deg], 0, newArray, 0, position);
      System.arraycopy(byDegree[deg], position + 1, newArray, position, newLength - position);
    }
    nRanked--;
    byDegree[deg] = newArray;
  }
  
  
  public void addToRanked(int id) {  

  	int degree = getDegree(id, nb); 
  	
   	/*If the degree is larger than byDegreeSize, byDegree is enlarged to twice its size.*/
   	if(degree >= byDegreeSize) { 
   		byDegreeSize *= 2;
   		int[][] newByDegree = new int[byDegreeSize][];    
       for (int i = 0; i < byDegreeSize/2; i++) {
         newByDegree[i] = byDegree[i];
       }       
       for (int i = byDegreeSize/2; i < byDegreeSize; i++) {
       	newByDegree[i] = new int[] {};
       }  
       byDegree = newByDegree;  
   	}
   	
 	 addToByDegree(id, degree);
   nRanked++;
   
   if (degree > maxDegree)
   	maxDegree = degree;  
   if (degree < minDegree) {
       minDegree = degree;
   }
  }
  
  /*Add a vertex to byDegree*/
  public void addToByDegree(int id, int degree) {

  	int newLength = byDegree[degree].length + 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength]; 
    
    if(byDegree[degree].length == 0)
    	newArray[0] = id;    
    else if(id < byDegree[degree][0]) {
    	newArray[0] = id;
    	System.arraycopy(byDegree[degree], 0, newArray, 1, newLength-1);
    }
    else {	    
     int i = 0;
     while(i < byDegree[degree].length && byDegree[degree][i] < id ) {
     	newArray[i] = byDegree[degree][i];
     	i++;
     }
     newArray[i] = id;
     i++;
     while(i < newLength) {
     	newArray[i] = byDegree[degree][i-1];
     	i++;
     }
    }    
    byDegree[degree] = newArray;
  } 
  
  void printStuff() {
  	
  	if(TRACE_ADDED_EDGES) {  		
  		/*Edges in H*/
	  	int hEdges = 0;
	  	for (int v = 0; v < g.n; v++) {
	  		hEdges += getDegree(v, h);
	  	} 	
	  	/*Edges of G*/
	  	int gEdges = 0;
	  	for (int i = 0; i < g.n; i++) {
	  		gEdges += g.neighbor[i].length;
	  	}
	  	int addedEdgesMMD3 = (hEdges - gEdges) / 2;  	
	  	System.out.println("   Added edges MD - MMD3: " + (addedEdgesMD - addedEdgesMMD3));
  	}
  	
  	if (TRACE_TIME) {
  		System.out.println("   Time (ms) total = " + totalTime/1000000 + ",  isChordal = " + timeIsChordal/1000000 + ",  order = " + timeOrder/1000000 + 
  				",  timeFindSubstars = " + timeFindSubstars/1000000 + ",  timeFindSubstarsChordal = " + timeFindSubstarsChordal/1000000 + ",  rangedBFS = " + timeRangedBFS/1000000);
  		System.out.printf("   nSepSubs = %d",nSepSubs);
  	} 
  	
  	if(TRACE_MEMORY) {
  		System.out.println("   MemoryG = " + memoryG + ", memoryH = " + memoryH + ", maxOrder = " + maxMemoryOrder + ", maxChordal = " + maxMemoryIsChordal);
  	
  	}
  	
  	if (TRACE_IMPROVEMENTS) {
  		double percentageClique = (double) cliqueSuccess / cliqueTries * 100;
  		double percentageRangedBFS = (double) rangedBFSSuccess / rangedBFSTries * 100;
  		System.out.printf("   Success percentage rangedBFS = %.5f,  clique = %.2f", percentageRangedBFS, percentageClique);
  	}
  	
  }
  
	void writeToFile(String fileName) {		
		File file = new File(fileName);		
   	
    try {
    	FileWriter ps = new FileWriter(file, true);

    	ps.write("\n" + memoryG + ", " + memoryH + ", " + maxMemoryOrder + ", " + maxMemoryIsChordal + ", "
    			  + totalTime/1000 + ", " + timeOrder/1000 + ", " + timeIsChordal/1000 + ", "
      			+ timeRound2/1000 + ", " + timeRangedBFS/1000 + ", " + timeFindSubstars/1000 + ", " + timeFindSubstarsChordal/1000);
    	
      ps.close();
    } catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	void writeToFileMemoryContinuous(String fileName, long memory, boolean newLine) {	
		File file = new File(fileName);		
   	
    try {
    	FileWriter ps = new FileWriter(file, true);
    	
    	if (newLine)
    		ps.write("\n");
    	
    	ps.write(memory + ", ");
    	
      ps.close();
    } catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	void writeToFileGeneral(String fileName) {		
		File file = new File(fileName);		
   	
		double percentageClique = (double) cliqueSuccess / cliqueTries * 100;
		double percentageRangedBFS = (double) rangedBFSSuccess / rangedBFSTries * 100;
		
		/*Edges in H*/
  	int hEdges = 0;
  	for (int v = 0; v < g.n; v++) {
  		hEdges += getDegree(v, h);
  	} 	
  	/*Edges of G*/
  	int gEdges = 0;
  	for (int i = 0; i < g.n; i++) {
  		gEdges += g.neighbor[i].length;
  	}
  	int addedEdgesMMD3 = (hEdges - gEdges) / 2; 
  	int addedEdgesDifference = addedEdgesMD - addedEdgesMMD3;
		
    try {
    	FileWriter ps = new FileWriter(file, true);

    	ps.write("\n" + nSepSubs + ", " + percentageClique + ", " + percentageRangedBFS + ", "
      			+ addedEdgesMD + ", " + addedEdgesMMD3 + ", " + addedEdgesDifference);

      ps.close();
    } catch (IOException e) {
			e.printStackTrace();
		}		
	}
	
	public long measureMemoryForceGC() {
		WeakReference<long[]> garbage = new WeakReference <long[]> (new long[10000000] );
		garbage.get()[100] = 100;
		runtime.gc();
		if (garbage.get() != null) {
			System.out.println("GC failed...");
			System.exit(1);
		}
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
  
  
  
}





















