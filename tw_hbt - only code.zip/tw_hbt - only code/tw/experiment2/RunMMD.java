package tw.experiment2;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;

public class RunMMD {
	
	static int numberOfRuns  = 1;
	static int run = 0;
//	static String typeOfMeasurement = "timePKT";
	
	/*--------Zorg dat aan het file geappendeerd wordt!!!------------*/
	
	static boolean runPace   = false;
	static boolean runPKT    = true;
	static boolean runRandom = false;
	
	static boolean runMMD;
	static boolean runMMD2;
	static boolean runMMD3;
	
	
	/*which data structures and algorithms do we measure?*/
	static boolean expIntsBFS 			= true;
	static boolean expXBitBFS 			= false;
	static boolean expEWAHBFS 			= false;
	static boolean expRoaring8BFS 	= false;
	static boolean expRoaring10BFS  = false;
	static boolean expRoaring12BFS  = false;
	static boolean expRoaring14BFS  = false;
	static boolean expRoaring16BFS  = false;
	
	static boolean expIntsPAR 			= false;
	static boolean expXBitPAR 			= false;
	static boolean expEWAHPAR 			= false;
	static boolean expRoaring8PAR 	= false;
	static boolean expRoaring10PAR  = false;
	static boolean expRoaring12PAR  = false;
	static boolean expRoaring14PAR  = false;
	static boolean expRoaring16PAR  = false;	
	
	static boolean useRun8      = false;
	static boolean useRun10     = false; //do we make use of runOptimize? (false for comparison!!)
	static boolean useRun12     = true;
	static boolean useRun14     = false;
	static boolean useRun16     = false;
	static boolean withoutRun = true;  //do make use of Roaring without runOptimize?
	
	/*For experiment these should be true*/
	static boolean startNewFile = false; //Create a new file or append to afalsed one?
	static boolean writeToFile = false;
	static boolean analyzeCompsDistribution = false;
	static boolean analyseRunOpt  = false;
	
	/*For experiment these should be false*/
	static boolean traceDataStructures = false;
	static boolean traceTime = true;
	
	static int edges;
	


	public static void main (String args[]) {
		
		while (run < numberOfRuns) {
			
			if (runPKT)  runPKT ();
			run++;
		}
	}
	

	
	
	static void runPKT() {
		
		System.out.println("g.n   MMD0   MMD   MMD2");
		
		runMMD  = true;
		runMMD2 = true;
		runMMD3 = false;
				
		// n = 115, 1000, 2142, 3448, 8124, 10811, 15827, 30836, 33919, 45145, 72703, 106443

		
		// *1.4: int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * nFactor) * nFactor) * nFactor) * nFactor)
		// *1.2: int n = nStart; n <= nEnd; n = (int) ((int) (n * nFactor) * nFactor)
		
		
		int nStart 		 = 1000;
		int nEnd   		 = 953086;
		double nFactor = 1.1; //Every time * nFactor
		
		MMD.maxDepth = 5;
		MMD2.maxDepth = 5;
		MMD3.maxDepth = 5;
		
		
		MMD2.sepSubLowerLimit = 0.04;
		MMD2.sepSubUpperLimit = 0.9;
		MMD3.sepSubLowerLimit = 0.04;
		MMD3.sepSubUpperLimit = 0.9;

		
		for (int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * nFactor) * nFactor) * nFactor) * nFactor)) {
			/*adjust for skip in graphs*/
			if (n == 998) {
				n = 1000;
			}
	      		   		
  		String graphName = "pkt_n" + n + "_k40_p0.075_seed1";
  		String path = "instance/pkt";
  		String graph      = "graphs/" + graphName;
  		
  		String filePath   = "log/experiment2/FirstResults";
  		
  		
  		/*Read graph and tree decomposition*/
  		Graph g              = Graph.readGraph(path, graph);

  		//System.out.println("\n\nGraph: pkt_" + n + ", n = " + g.n + ", depth = " + MMD.maxDepth);
  		
  		System.out.print(g.n + "   ");
  		
  		performExperiments(g, filePath, graphName);
  		
  		System.out.println();
  		
		}
	}

	
	 
	static void performExperiments(Graph g, String filePath, String graphName) {
		
		boolean runMMD0 = true;
		if (runMMD0 && g.n <= 66137) {
			//System.out.println("\nMMD0");
			MMD0 mmd = new MMD0 (g);
			mmd.runMMD0();
		}
		
		
		if(runMMD) {
			//System.out.println("\nMMD");
			MMD mmd = new MMD (g);
			mmd.runMMD();
		}
		
		if (runMMD2) {
			//System.out.println("\nMMD2.  Lower limit = " + MMD2.sepSubLowerLimit + ",  upper limit = " + MMD2.sepSubUpperLimit);
			MMD2 mmd2 = new MMD2 (g);
			mmd2.runMMD2();
			
		}
		
		if (runMMD3) {
			System.out.println("\nMMD3.  Lower limit = " + MMD3.sepSubLowerLimit + ",  upper limit = " + MMD3.sepSubUpperLimit);
			MMD3 mmd3  = new MMD3 (g);
			mmd3.runMMD3();
			
		}

		
	}	
	
	static void runRandom() {
		

  	int nMin = 100;
  	int nMax = 100;
  	int nStep = 2; //Each next round n * nStep

  	for (int n = nMin; n <= nMax; n *= nStep) {		
			/*Compute the probability of an edge*/
			double p = 0.03;			
				
			
			/*Generate graph*/
			System.out.println("\nGenerating graph. n = " + n + ", p = " + p + "");
			Graph g = Graph.randomGraph(n, p);
      
      /*Clean the graph*/
      g.cleanUp();

      System.out.println(Arrays.toString(g.neighbor[0]));
  		
  		
  		System.out.println("Run: " + run + ", Graph: random_" + n + ", n = " + g.n);
  		
  		for (int i = 0; i < g.n; i++) {
  			edges += g.neighbor[i].length;
  		}
  		edges = edges / 2;
  		
  		performExperiments(g, " ", " ");
  		
  		p *= 0.5;
	      		
		}
	}
	

	
	
	
	
	private static void createNewFile(String fileName, int gn, int edges) {
		if (startNewFile) {
			File fileOld = new File(fileName);		
			fileOld.delete();
		}
		File fileNew = new File(fileName);
		
		try {
			FileWriter ps = new FileWriter(fileNew);		
			ps.write("g.n, time (micro s), vertices polled, vertices visited");
			ps.write(gn);
			ps.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}







