package tw.experiment2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;


import tw.common.XBitSet;

public class MMD_XBit extends AbstractMMD <XBitSet> {

	public MMD_XBit(Graph g) {
		super(g);
		this.g = g;
		this.nb = new XBitSet[g.n];
		this.h = new XBitSet[g.n];
		System.out.println("XBit");
	}

	/*Cast the from int[] to the data structure*/
	@SuppressWarnings("unchecked")
	@Override
	XBitSet cast(int[] set) {		
		XBitSet result = new XBitSet(g.n, set);
		return result;
	}
	

	@Override
	int getDegree(int v, XBitSet[] graph){
		return graph[v].cardinality();
	}


	@Override
	void removeSelf(int id) {
		
	 	/*remove from byDegree*/
	 	removeFromByDegree(id, nb[id].cardinality());
	 	
	 	/*for each neighbor n*/
	 	for (int n = nb[id].nextSetBit(0); n >= 0; n = nb[id].nextSetBit(n + 1)) {
	 		int degreeBefore = nb[n].cardinality();

	 		/*delete id from neighborhood*/
	 		deleteElement(n, id);

	 		/*update the rank*/
	 		updateRank(n, degreeBefore); 
	 	}
	 	nRanked--;
	 	remaining.clear(id);	
	}
	
	 /* Deletes an element deleteV from the neighborhood of ID */
	 public void deleteElement (int id, int deleteV) { 
	 	nb[id].clear(deleteV);
	 } 
	 
	 
	void fillNeighborhood(int id) {  
		
		for (int v = nb[id].nextSetBit(0); v >= 0; v = nb[id].nextSetBit(v + 1)) { 
		 	int degreeBefore = nb[v].cardinality(); 
		 	
	 		nb[v].or(nb[id]);	
	 		nb[v].clear(v);	
	 		
	 		updateRank(v, degreeBefore);
	 		doubleAddedEdgesMD += nb[v].cardinality() - degreeBefore;
		}
	}


	@Override
	boolean rangedBFS(int id, int maxDepth, XBitSet[] graph) {
	 	if (graph[id].cardinality() == 0 || graph[id].cardinality() == 1)
	 		return true;
	 	
	 	/*mark the neighborhood*/
	 	int [] markedRanged = new int[g.n];
	 	markedRanged = markSeparator(id, markedRanged, graph);
	 	
	 	/*Depth keeps track of the reached depth of the vertices*/  
	 	int[] depth = new int[g.n];

	 	/*nReached keeps track of the amount of neighbors which have been reached*/
	 	int nReached = 0;
	 	
	 	/*Add the first second neighbor to the queue that's not also a first neighbor*/
		LinkedList<Integer> queue = new LinkedList<Integer>();
		
		for (int neighb = graph[id].nextSetBit(0); neighb >= 0; neighb = graph[id].nextSetBit(neighb + 1)) {
			for (int secondNeighb = graph[neighb].nextSetBit(0); secondNeighb >= 0; secondNeighb = graph[neighb].nextSetBit(secondNeighb + 1)) {
				if (markedRanged[secondNeighb] == 0) {
					queue.add(secondNeighb);
					markedRanged[secondNeighb] = 1;
					break;
				}
			}
			if (queue.size() == 1)
				break;
		}
		
		
		/*If no vertices added to queue, return true*/
		if (queue.size() == 0)
			return true;

	   while (queue.size() != 0) { 
	     // Dequeue a vertex v  from queue
	     int v = queue.poll();  
	     
	     if (depth[v] == maxDepth)
	     	break;
	     
	     /*for each neighbor of v*/
	     
	     for (int w = graph[v].nextSetBit(0); w >= 0; w = graph[v].nextSetBit(w + 1)) {	     	
	     	if (markedRanged[w] == -2)
	     		continue;        	
	     	
	     	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
	     	else if (markedRanged[w] == 0) { 
	     		markedRanged[w] = 1;
	       	queue.add(w);   
	       	depth[w] = depth[v] + 1;
	 			}
	     	
	     	/*If the vertex is a first neighbor and not yet explored,
	     	 * add the neighbor to reached*/
	     	else if (markedRanged[w] == -1) {
	     		nReached++;
	     		markedRanged[w] = -2;
	     		if (graph[id].cardinality() == nReached)
	         	return true;
	     	}
	 		}
	   }	
	   return false;
	 }

	@Override
	/*Form the substar into a cliques in H*/
	void addSubstarToH (XBitSet sub) {	
		
		for (int s = sub.nextSetBit(0); s >= 0; s = sub.nextSetBit(s + 1)) {	  
  		h[s].or(sub);
  		h[s].clear(s);	
  	}
	}

	@Override
	/*marks the separator with -1*/
	int[] markSeparator(int id, int[] mar, XBitSet[] graph) {
		mar[id] = -1;
		
		for (int v = graph[id].nextSetBit(0); v >= 0; v = graph[id].nextSetBit(v + 1)) {	 
	    mar[v] = -1;
		}
		return mar;
	}

	@Override
	XBitSet getSubstarBFS(int v, int compN, XBitSet[] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 

      v = queue.poll();   
      
      for (int w = graph[v].nextSetBit(0); w >= 0; w = graph[v].nextSetBit(w + 1)) {	   	    
  	    if (marked[w] > 0)
      		continue;
        			
      	if (marked[w] == 0) { 
          marked[w] = compN; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = -2;
        	substar.add(w);
        }
  		}
    }	        
    return arrayListToDataStructure(substar);
	}

	@Override
	XBitSet arrayListToDataStructure(ArrayList<Integer> list) {
		XBitSet result = new XBitSet();
		Collections.sort(list);
		for (int i = 0; i < list.size(); i++) {
			result.set(list.get(i));
		}
		return result;
  }

	/*Seems correct*/
	@Override
	boolean isClique(XBitSet vs, XBitSet[] graph) {
		 
		if(vs.cardinality() == 0 || vs.cardinality() == 1)
			return true;

		for (int v = vs.nextSetBit(0); v >= 0; v = vs.nextSetBit(v + 1)) {	 
			XBitSet overlap = graph[v].intersectWith(vs);
	    if (overlap.cardinality() != vs.cardinality() - 1)
	    	return false; 		
		 	}
		return true;  
	}


	@Override
	XBitSet[] setUpRound2() {
		/*New nb = H, with only those vertices which are not LBsimplicial*/
		XBitSet[] result = new XBitSet[g.n]; 
		
		/*Convert verticesNotLBSimplicial to vertsNotLBS*/
		XBitSet vertsNotLBS = new XBitSet();
    for (int k = verticesNotLBSimplicial.nextSetBit(0); k >= 0; k = verticesNotLBSimplicial.nextSetBit(k+1))
    	vertsNotLBS.set(k);
		
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
    	result[v] = h[v].intersectWith(vertsNotLBS);
    }
    return result;
	}



	@Override
	int[] markSeparator_Chordal(int id, XBitSet[] graph) {
		int[] result = markedSepSub.clone();
		
		/*remove separating substar that overlap with id and its neighbors*/
		if (result[id] != 0) {
			int s = result[id];
			
			for (int w = substars[s].nextSetBit(0); w >= 0; w = substars[s].nextSetBit(w + 1)) {	 
		    result[w] = 0;
			}  				
		}
		//Neighbors
		for (int w = graph[id].nextSetBit(0); w >= 0; w = graph[id].nextSetBit(w + 1)) {	  
	 		if (result[w] > 0) {
	 			int s = result[w];
	 			
	 			for (int x = substars[s].nextSetBit(0); x >= 0; x = substars[s].nextSetBit(x + 1)) {	 
			    result[x] = 0;
	 			}  				
	 		} 			
		}
		
		/*Mark ID and its neighbors with -1*/
		result[id] = -1;
		
		for (int w = graph[id].nextSetBit(0); w >= 0; w = graph[id].nextSetBit(w + 1)) {	 
	  	result[w] = -1;
		}
		return result;
	}

	@Override
	XBitSet getSecondNeighbors(int id, XBitSet[] graph) {
		XBitSet secondNeighbors = new XBitSet(g.n);
		
		for (int w = graph[id].nextSetBit(0); w >= 0; w = graph[id].nextSetBit(w + 1)) {
			for (int x = graph[w].nextSetBit(0); x >= 0; x = graph[w].nextSetBit(x + 1)) {
		  	secondNeighbors.set(x);
		  }
		}
	
		for (int w = graph[id].nextSetBit(0); w >= 0; w = graph[id].nextSetBit(w + 1)) {
	  	secondNeighbors.clear(w);
	  }
		secondNeighbors.clear(id);
		return secondNeighbors;
	}

	@Override
	XBitSet getSubstarBFS_Chordal(int v, int compN, XBitSet[] graph) {
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
    
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll();

      //v in substar and already visited        
      if (marked[v] == compN - 10)
      	continue;
      
      countLengthComp++;
      
      for (int w = graph[v].nextSetBit(0); w >= 0; w = graph[v].nextSetBit(w + 1)) {    	
      	
      	/*If already visited, continue*/
      	if(marked[w] < -1)
      		continue;
  			
      	/*If vertex not yet explored and not part of a separating substar*/
      	else if (marked[w] == 0) { 
          marked[w] = compN;             
          queue.add(w);   
  			}
      	
      	/*If we reached a neighbor*/
      	else if (marked[w] == -1) {
      		marked[w] = compN;
        	substar.add(w);
        }
      	
      	/*If we reach a vertex that is part of a separating substar
      	 *  1) check from which side we reached this substar,
      	 *  		and mark all vertices on the other side with compN.
      	 *  2) mark the entire substar and put each vertex in queue
      	 */
      	else if(marked[w] > 0) {
      		int s = markedSepSub[w];
      		
      		if (!shortSNeighbs[s].get(v)) {
      		/*v in longSNeighbs
      		 * 1) continue searching in longSNeighbs */
      			if (!shortSNeighbs[s].get(v)) {
      				
      				for (int z = longSNeighbs[s].nextSetBit(0); z >= 0; z = longSNeighbs[s].nextSetBit(z + 1)) {
	      				if (marked[z] == 0) {
	                marked[z] = compN;               
	                queue.add(z);  
	      				}
	            	else if (marked[z] == -1) {
	            		marked[z] = compN;
	              	substar.add(z);
	              }
	      			}
      			}
      		}
      		/*v in shortSNeighbs
      		 * 1) continue searching in shortSNeighbs*/
      		else {
      			for (int z = shortSNeighbs[s].nextSetBit(0); z >= 0; z = shortSNeighbs[s].nextSetBit(z + 1)) {
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		
      		/*mark substar with compN*/
      		for (int y = substars[s].nextSetBit(0); y >= 0; y = substars[s].nextSetBit(y + 1)) {
            marked[y] = compN - 10;         			
      		}        		
      	}        	
  		}
    }     
    return arrayListToDataStructure(substar);
	}

	@Override
	int[] markSubstar(XBitSet sub, XBitSet[] graph) {	
		
		for (int w = sub.nextSetBit(0); w >= 0; w = sub.nextSetBit(w + 1)) {
			marked[w] = nSepSubs + 10;
		}
		return marked;
	}

	@Override
	XBitSet getSubNeighbors(XBitSet sub, int compNumber, boolean isComp, XBitSet[] graph) {
  	ArrayList<Integer> result = new ArrayList<Integer>();
  	marked = markSubstar(sub, graph);

  	for (int s = sub.nextSetBit(0); s >= 0; s = sub.nextSetBit(s + 1)) {
  		for (int v = graph[s].nextSetBit(0); v >= 0; v = graph[s].nextSetBit(v + 1)) {
  
  			if (isComp) {
	  			if (marked[v] == compNumber && !result.contains(v))
	  				result.add(v);
  			}
  			else {
  				if (marked[v] != compNumber && marked[v] != nSepSubs + 10 && !result.contains(v)) {
  					result.add(v);
  				}
  			}
  		}  		
  	}
  	return arrayListToDataStructure(result);
  }

	@Override
	void addToSeparatingSubs(XBitSet sub, int compNumber, boolean subNoClique,	XBitSet[] graph) {
  	/*Make sure that separating substars do not overlap with one another*/
  	boolean noOverlap = true;
  	
  	for (int w = sub.nextSetBit(0); w >= 0; w = sub.nextSetBit(w + 1)) {
	  	if (markedSepSub[w] != 0) {
	  		noOverlap = false;
	  		break;
  		}      			
  	}	
  	
  	if (noOverlap) {
  		/* Mark the vertices in markedSepSub*/
  		for (int s = sub.nextSetBit(0); s >= 0; s = sub.nextSetBit(s + 1)) {
  			markedSepSub[s] = nSepSubs + 1;
  		}
  		
  		/*Save the short-sided and long-sided neighbor sets of the substar*/
  		XBitSet neighbsCompSide = getSubNeighbors(sub, compNumber, true, graph);
  		XBitSet neighbsOtherSide = getSubNeighbors(sub, compNumber, false, graph);
  		
  		/*keep track of the substar, and its two neighbor sets*/
  		substars[nSepSubs + 1] = sub;  		
  		
  		if (neighbsCompSide.cardinality() > neighbsOtherSide.cardinality()) {
  			shortSNeighbs[nSepSubs + 1] = neighbsOtherSide;
  			longSNeighbs[nSepSubs + 1] = neighbsCompSide; 			
  		}
  		else {
  			shortSNeighbs[nSepSubs + 1] = neighbsCompSide;
  			longSNeighbs[nSepSubs + 1] = neighbsOtherSide; 	
  		}
  		
  		nSepSubs++;
  	}
  }
	
	@Override
	XBitSet cloneBuiltIn(XBitSet set) {
		return (XBitSet) set.clone();
	}

	@Override
	XBitSet[] initiateSubstars(int length) {
		XBitSet[] result = new XBitSet[length];
		return result;
	}

	@Override
	void printVertexSet(XBitSet vs) {
		// TODO Auto-generated method stub
		
	}
	

}










