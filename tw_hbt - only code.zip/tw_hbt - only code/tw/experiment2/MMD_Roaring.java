package tw.experiment2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import org.roaringbitmap.*;
import tw.common.XBitSet;

public class MMD_Roaring extends AbstractMMD <RoaringBitmap> {

	int containerSize;
	boolean useRun;

	public MMD_Roaring(Graph g, int containerSize, boolean useRun) {
		super(g);
		this.g = g;
		this.nb = new RoaringBitmap[g.n];
		this.h = new RoaringBitmap[g.n];
		
		this.containerSize = containerSize;
		this.useRun = useRun;
		
		/*Update all constants*/
		RoaringBitmap.containerSize = containerSize;
		BitmapContainer.MAX_CAPACITY =  (int) Math.pow(2, containerSize);
		BitmapContainer.BLOCKSIZE = BitmapContainer.MAX_CAPACITY / 64;
		ArrayContainer.MAX_CONTAINER_SIZE = containerSize;
		ArrayContainer.DEFAULT_MAX_SIZE = (int) Math.pow(2, containerSize - 4);
		ArrayContainer.ARRAY_LAZY_LOWERBOUND = ArrayContainer.DEFAULT_MAX_SIZE/4;
		
		if(useRun)
			System.out.println("RoaringRun16");
		else
			System.out.println("Roaring" + containerSize );
	}

	/*Cast the from int[] to the data structure*/
	@SuppressWarnings("unchecked")
	@Override
	RoaringBitmap cast(int[] set) {		
		RoaringBitmap result = RoaringBitmap.bitmapOf(containerSize, set);
		if (useRun)
			result.runOptimize();
		return result;
	}
	
	@Override
	int getDegree(int v, RoaringBitmap[] graph){
		return graph[v].getCardinality();
	}


	@Override
	void removeSelf(int id) {
		
	 	/*remove from byDegree*/
	 	removeFromByDegree(id, nb[id].getCardinality());
	 	
	 	/*for each neighbor n*/
	 	PeekableIntIterator iter = nb[id].getIntIterator();
    while (iter.hasNext()) {
    	int n = iter.next(); 
	 		int degreeBefore = nb[n].getCardinality();
	 		
	 		/*delete id from neighborhood*/
	 		deleteElement(n, id);

	 		/*update the rank*/
	 		updateRank(n, degreeBefore); 
	 	}
	 	nRanked--;
	 	remaining.clear(id);	
	 	
	 	
	}
	
	 /* Deletes an element deleteV from the neighborhood of ID */
	 public void deleteElement (int id, int deleteV) { 
	 	 nb[id].remove(deleteV);
	 } 
	 
	 
	void fillNeighborhood(int id) {   	
		PeekableIntIterator iter = nb[id].getIntIterator();
	  while (iter.hasNext()) {
	    int v = iter.next(); 
		 	int degreeBefore = nb[v].getCardinality(); 
		 	
	 		nb[v] = RoaringBitmap.or(nb[v], nb[id]);	
	 		nb[v].remove(v);	
	 		
	 		if(useRun)
	 			nb[v].runOptimize();
	 		
	 		updateRank(v, degreeBefore);
	 		doubleAddedEdgesMD += nb[v].getCardinality() - degreeBefore;
		}
	}


	@Override
	boolean rangedBFS(int id, int maxDepth, RoaringBitmap[] graph) {
	 	if (graph[id].getCardinality() == 0 || graph[id].getCardinality() == 1)
	 		return true;
	 	
	 	/*mark the neighborhood*/
	 	int [] markedRanged = new int[g.n];
	 	markedRanged = markSeparator(id, markedRanged, graph);
	 	
	 	/*Depth keeps track of the reached depth of the vertices*/  
	 	int[] depth = new int[g.n];

	 	/*nReached keeps track of the amount of neighbors which have been reached*/
	 	int nReached = 0;
	 	
	 	/*Add the first second neighbor to the queue that's not also a first neighbor*/
		LinkedList<Integer> queue = new LinkedList<Integer>();
		PeekableIntIterator iter = graph[id].getIntIterator();
	  while (iter.hasNext()) {
	    int neighb = iter.next(); 
			PeekableIntIterator iter2 = nb[neighb].getIntIterator();
		  while (iter2.hasNext()) {
		    int secondNeighb = iter2.next(); 
				if (markedRanged[secondNeighb] == 0) {
					queue.add(secondNeighb);
					markedRanged[secondNeighb] = 1;
					break;
				}
			}
			if (queue.size() == 1)
				break;
		}
		
		
		/*If no vertices added to queue, return true*/
		if (queue.size() == 0)
			return true;

	   while (queue.size() != 0) { 
	     // Dequeue a vertex v  from queue
	     int v = queue.poll();  
	     
	     if (depth[v] == maxDepth)
	     	break;
	     
	     /*for each neighbor of v*/
	 		PeekableIntIterator iter3 = graph[v].getIntIterator();
		  while (iter3.hasNext()) {
		    int w = iter3.next(); 
	     	
	     	if (markedRanged[w] == -2)
	     		continue;        	
	     	
	     	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
	     	else if (markedRanged[w] == 0) { 
	     		markedRanged[w] = 1;
	       	queue.add(w);   
	       	depth[w] = depth[v] + 1;
	 			}
	     	
	     	/*If the vertex is a first neighbor and not yet explored,
	     	 * add the neighbor to reached*/
	     	else if (markedRanged[w] == -1) {
	     		nReached++;
	     		markedRanged[w] = -2;
	     		if (graph[id].getCardinality() == nReached)
	         	return true;
	     	}
	 		}
	   }	
	   return false;
	 }
	
	@Override
	/*Form the substar into a cliques in H*/
	void addSubstarToH (RoaringBitmap sub) {	
		PeekableIntIterator iter = sub.getIntIterator();
	  while (iter.hasNext()) {
	  	int s = iter.next(); 
  		h[s] = RoaringBitmap.or(h[s], sub);
  		h[s].remove(s);	
  		if(useRun)
  			h[s].runOptimize();
  	}
	}

	@Override
	/*marks the separator with -1*/
	int[] markSeparator(int id, int[] mar, RoaringBitmap[] graph) {
		mar[id] = -1;
		PeekableIntIterator iter = graph[id].getIntIterator();
	  while (iter.hasNext()) {
	  	int v = iter.next();
	    mar[v] = -1;
		}
		return mar;
	}

	@Override
	RoaringBitmap getSubstarBFS(int v, int compN, RoaringBitmap[] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 

      v = queue.poll();   
      
  		PeekableIntIterator iter = graph[v].getIntIterator();
  	  while (iter.hasNext()) {
  	    int w = iter.next(); 
  	    
  	    if (marked[w] > 0)
      		continue;
        			
      	if (marked[w] == 0) { 
          marked[w] = compN; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = -2;
        	substar.add(w);
        }
  		}
    }	        
    return arrayListToDataStructure(substar);
	}
	
	@Override
	RoaringBitmap arrayListToDataStructure(ArrayList<Integer> list) {
		RoaringBitmap result = new RoaringBitmap();
		Collections.sort(list);
		for (int i = 0; i < list.size(); i++) {
			result.add(list.get(i));
		}
		if(useRun)
			result.runOptimize();
		return result;
  }

	/*Seems correct*/
	@Override
	boolean isClique(RoaringBitmap vs, RoaringBitmap[] graph) {
		 
		if(vs.getCardinality() == 0 || vs.getCardinality() == 1)
			return true;

		PeekableIntIterator iter = vs.getIntIterator();
	  while (iter.hasNext()) {
	    int v = iter.next(); 		
	    RoaringBitmap overlap = RoaringBitmap.and(graph[v], vs);
	    if (overlap.getCardinality() != vs.getCardinality() - 1)
	    	return false; 		
		 	}
		return true;  
	}


	@Override
	RoaringBitmap[] setUpRound2() {
		/*New nb = H, with only those vertices which are not LBsimplicial*/
		RoaringBitmap[] result = new RoaringBitmap[g.n]; 
		
		/*Convert verticesNotLBSimplicial to vertsNotLBS*/
		RoaringBitmap vertsNotLBS = new RoaringBitmap();
    for (int k = verticesNotLBSimplicial.nextSetBit(0); k >= 0; k = verticesNotLBSimplicial.nextSetBit(k+1))
    	vertsNotLBS.add(k);
		
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
    	result[v] = RoaringBitmap.and(h[v], vertsNotLBS);
    }
    return result;
	}



	@Override
	int[] markSeparator_Chordal(int id, RoaringBitmap[] graph) {
		int[] result = markedSepSub.clone();
		
		/*remove separating substar that overlap with id and its neighbors*/
		if (result[id] != 0) {
			int s = result[id];
			
			PeekableIntIterator iter = substars[s].getIntIterator();
		  while (iter.hasNext()) { 
		    result[iter.next()] = 0;
			}  				
		}
		//Neighbors
		PeekableIntIterator iter = graph[id].getIntIterator();
	  while (iter.hasNext()) {
	    int w = iter.next(); 

	 		if (result[w] > 0) {
	 			int s = result[w];
	 			PeekableIntIterator iter2 = substars[s].getIntIterator();
			  while (iter2.hasNext()) {
			    result[iter2.next()] = 0;
	 			}  				
	 		} 			
		}
		
		/*Mark ID and its neighbors with -1*/
		result[id] = -1;
		PeekableIntIterator iter3 = graph[id].getIntIterator();
	  while (iter3.hasNext()) {
	  	result[iter3.next()] = -1;
		}
		return result;
	}

	@Override
	XBitSet getSecondNeighbors(int id, RoaringBitmap[] graph) {
		XBitSet secondNeighbors = new XBitSet(g.n);
		
		PeekableIntIterator iter = graph[id].getIntIterator();
	  while (iter.hasNext()) {
	    int w = iter.next();
	    
	    PeekableIntIterator iter2 = graph[w].getIntIterator();
		  while (iter2.hasNext()) {
		  	secondNeighbors.set(iter2.next());
		  }
		}
	
	  PeekableIntIterator iter3 = graph[id].getIntIterator();
	  while (iter3.hasNext()) {
	  	secondNeighbors.clear(iter3.next());
	  }
		secondNeighbors.clear(id);
		return secondNeighbors;
	}

	@Override
	RoaringBitmap getSubstarBFS_Chordal(int v, int compN, RoaringBitmap[] graph) {
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
    
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll();

      //v in substar and already visited        
      if (marked[v] == compN - 10)
      	continue;
      
      countLengthComp++;
      
      PeekableIntIterator iter = graph[v].getIntIterator();
  	  while (iter.hasNext()) {
  	    int w = iter.next();     	
      	
      	/*If already visited, continue*/
      	if(marked[w] < -1)
      		continue;
  			
      	/*If vertex not yet explored and not part of a separating substar*/
      	else if (marked[w] == 0) { 
          marked[w] = compN;             
          queue.add(w);   
  			}
      	
      	/*If we reached a neighbor*/
      	else if (marked[w] == -1) {
      		marked[w] = compN;
        	substar.add(w);
        }
      	
      	/*If we reach a vertex that is part of a separating substar
      	 *  1) check from which side we reached this substar,
      	 *  		and mark all vertices on the other side with compN.
      	 *  2) mark the entire substar and put each vertex in queue
      	 */
      	else if(marked[w] > 0) {
      		int s = markedSepSub[w];
      		
      		if (!shortSNeighbs[s].contains(v)) {
      		/*v in longSNeighbs
      		 * 1) continue searching in longSNeighbs */
      			if (!shortSNeighbs[s].contains(v)) {
      				
	    				PeekableIntIterator iter2 = longSNeighbs[s].getIntIterator();
	    			  while (iter2.hasNext()) {
	    			    int z = iter2.next();	
	      				if (marked[z] == 0) {
	                marked[z] = compN;               
	                queue.add(z);  
	      				}
	            	else if (marked[z] == -1) {
	            		marked[z] = compN;
	              	substar.add(z);
	              }
	      			}
      			}
      		}
      		/*v in shortSNeighbs
      		 * 1) continue searching in shortSNeighbs*/
      		else {
      			PeekableIntIterator iter2 = shortSNeighbs[s].getIntIterator();
    			  while (iter2.hasNext()) {
    			    int z = iter2.next();
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		
      		/*mark substar with compN*/
    			PeekableIntIterator iter3 = substars[s].getIntIterator();
  			  while (iter3.hasNext()) {
  			    int y = iter3.next();	
            marked[y] = compN - 10;         			
      		}        		
      	}        	
  		}
    }     
    return arrayListToDataStructure(substar);
	}

	@Override
	int[] markSubstar(RoaringBitmap sub, RoaringBitmap[] graph) {	
		PeekableIntIterator iter = sub.getIntIterator();
	  while (iter.hasNext()) {
			marked[iter.next()] = nSepSubs + 10;
		}
		return marked;
	}

	@Override
	RoaringBitmap getSubNeighbors(RoaringBitmap sub, int compNumber, boolean isComp, RoaringBitmap[] graph) {
  	ArrayList<Integer> result = new ArrayList<Integer>();
  	marked = markSubstar(sub, graph);

  	PeekableIntIterator iter = sub.getIntIterator();
	  while (iter.hasNext()) {
	  	int s = iter.next();
	  	
	  	PeekableIntIterator iter2 = graph[s].getIntIterator();
		  while (iter2.hasNext()) {
		  	int v = iter2.next();
  
  			if (isComp) {
	  			if (marked[v] == compNumber && !result.contains(v))
	  				result.add(v);
  			}
  			else {
  				if (marked[v] != compNumber && marked[v] != nSepSubs + 10 && !result.contains(v)) {
  					result.add(v);
  				}
  			}
  		}  		
  	}
  	return arrayListToDataStructure(result);
  }

	
	@Override
	void addToSeparatingSubs(RoaringBitmap sub, int compNumber, boolean subNoClique,	RoaringBitmap[] graph) {
  	/*Make sure that separating substars do not overlap with one another*/
  	boolean noOverlap = true;
  	
  	PeekableIntIterator iter = sub.getIntIterator();
	  while (iter.hasNext()) {
	  	if (markedSepSub[iter.next()] != 0) {
	  		noOverlap = false;
	  		break;
  		}      			
  	}	
  	
  	if (noOverlap) {
  		/* Mark the vertices in markedSepSub*/
  		for (int s : sub) {
  			markedSepSub[s] = nSepSubs + 1;
  		}
  		
  		/*Save the short-sided and long-sided neighbor sets of the substar*/
  		RoaringBitmap neighbsCompSide = getSubNeighbors(sub, compNumber, true, graph);
  		RoaringBitmap neighbsOtherSide = getSubNeighbors(sub, compNumber, false, graph);
  		
  		/*keep track of the substar, and its two neighbor sets*/
  		substars[nSepSubs + 1] = sub;  		
  		
  		if (neighbsCompSide.getCardinality() > neighbsOtherSide.getCardinality()) {
  			shortSNeighbs[nSepSubs + 1] = neighbsOtherSide;
  			longSNeighbs[nSepSubs + 1] = neighbsCompSide; 			
  		}
  		else {
  			shortSNeighbs[nSepSubs + 1] = neighbsCompSide;
  			longSNeighbs[nSepSubs + 1] = neighbsOtherSide; 	
  		}
  		
  		nSepSubs++;
  	}
  }
	
	@Override
	RoaringBitmap cloneBuiltIn(RoaringBitmap roar) {
		return roar.clone();
	}

	@Override
	RoaringBitmap[] initiateSubstars(int length) {
		RoaringBitmap[] result = new RoaringBitmap[length];
		return result;
	}

	@Override
	void printVertexSet(RoaringBitmap vs) {
		// TODO Auto-generated method stub
		
	}

}










