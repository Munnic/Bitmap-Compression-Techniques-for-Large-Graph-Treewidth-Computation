package tw.experiment2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;

import tw.common.XBitSet;

public class MMD_Ints  extends AbstractMMD <int[]> {

	public MMD_Ints(Graph g) {
		super(g);
		this.g = g;
		this.nb = new int[g.n][];
		this.h = new int[g.n][];
		System.out.println("Ints");
	}

	@Override
	int[] cast(int[] set) {
		return set.clone();
	}

	@Override
	int getDegree(int v, int[][] graph) {
		return graph[v].length;
	}

	@Override
	void removeSelf(int id) {
	 	/*remove from byDegree*/
	 	removeFromByDegree(id, nb[id].length);
	 	
	 	/*for each neighbor n*/
	 	for(int i = 0; i < nb[id].length; i++) { 
	 		int n = nb[id][i]; 
	 		int degreeBefore = nb[n].length;
	 		
	 		/*delete the element from neighborhood*/
	 		deleteElement(n, id);
	 		
	 		/*update the rank*/
	 		updateRank(n, degreeBefore); 
	 	}
	 	nRanked--;
	 	remaining.clear(id);
	}

	@Override
	void fillNeighborhood(int id) {
		for(int i = 0; i < nb[id].length; i++) {  
	 		int v = nb[id][i];  
	 		int degreeBefore = nb[v].length;
	 		int[] toAdd = Graph.removeElement(nb[id], v); 
	 		nb[v] = Graph.getUnion(nb[v], toAdd); /**O(degree1 + degree2)*/
	 		updateRank(v, degreeBefore);
	 		doubleAddedEdgesMD += nb[v].length - degreeBefore;
	 	}
	}
	
	 /* Deletes an element deleteV from the neighborhood of ID */
	 public void deleteElement (int id, int deleteV) { 
	 	int newDegree = nb[id].length - 1;
	   
	   /*Find position of element to be deleted. If element not found, return*/
	   int position = Arrays.binarySearch(nb[id], 0, newDegree + 1, deleteV);       
	   if (position < 0) {
	     return;
	   } 
	   
	   /*Construct a new neighborhood array*/
	   int[] newArray = new int[newDegree];      
	   if(position == 0) {
	   	System.arraycopy(nb[id], 1, newArray, 0, newDegree);
	   }
	   else {
	      System.arraycopy(nb[id], 0, newArray, 0, position);
	      System.arraycopy(nb[id], position + 1, newArray, position, newDegree - position);
	   }
	   nb[id] = newArray;
	 } 
	

	@Override
	boolean rangedBFS(int id, int maxDepth, int[][] graph) {
	 	if (graph[id].length == 0 || graph[id].length == 1)
	 		return true;
	 	
	 	/*mark the neighborhood*/
	 	int [] markedRanged = new int[g.n];
	 	markedRanged = markSeparator(id, markedRanged, graph);
	 	
	 	/*Depth keeps track of the reached depth of the vertices*/  
	 	int[] depth = new int[g.n];

	 	/*nReached keeps track of the amount of neighbors which have been reached*/
	 	int nReached = 0;
	 	
	 	/*Add the first second neighbor to the queue that's not also a first neighbor*/
		LinkedList<Integer> queue = new LinkedList<Integer>();
		for (int i = 0; i < graph[id].length; i++) {
			int neighb = graph[id][i];
			for (int j = 0; j < graph[neighb].length; j++) {
				int secondNeighb = graph[neighb][j];
				if (markedRanged[secondNeighb] == 0) {
					queue.add(secondNeighb);
					markedRanged[secondNeighb] = 1;
					break;
				}
			}
			if (queue.size() == 1)
				break;
		}
		
		
		/*If no vertices added to queue, return true*/
		if (queue.size() == 0)
			return true;

	   while (queue.size() != 0) { 
	     // Dequeue a vertex v  from queue
	     int v = queue.poll();  
	     
	     if (depth[v] == maxDepth)
	     	break;
	     
	     /*for each neighbor of v*/
	     for (int i = 0; i < graph[v].length; i++) {
	     	int w = graph[v][i];	
	     	
	     	if (markedRanged[w] == -2)
	     		continue;        	
	     	
	     	/*vertex not yet explored. Mark the vertex and add to queue if depth not to large.*/
	     	else if (markedRanged[w] == 0) { 
	     		markedRanged[w] = 1;
	       	queue.add(w);   
	       	depth[w] = depth[v] + 1;
	 			}
	     	
	     	/*If the vertex is a first neighbor and not yet explored,
	     	 * add the neighbor to reached*/
	     	else if (markedRanged[w] == -1) {
	     		nReached++;
	     		markedRanged[w] = -2;
	     		if (graph[id].length == nReached)
	         	return true;
	     	}
	 		}
	   }	
	   return false;
	}

	@Override
	void addSubstarToH(int[] sub) {
  	for(int s : sub) {   		
  		int[] toAdd = Graph.removeElement(sub, s);  		
  		h[s] = Graph.getUnion(h[s], toAdd);  		
  	}
	}

	@Override
	int[] markSeparator(int id, int[] mar, int[][] graph) {
		mar[id] = -1;
		for(int i = 0; i < graph[id].length; i++) {
			mar[graph[id][i]] = -1;
		}
		return mar;
	}

	@Override
	int[] getSubstarBFS(int v, int compN, int[][] graph) {
		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 

      v = queue.poll();      
      for (int i = 0; i < graph[v].length; i++) {
      	int w = graph[v][i];	
      	
      	if (marked[w] > 0)
      		continue;
      	
      	if (marked[w] == 0) { 
          marked[w] = compN; 
          queue.add(w);   
  			}
      	else if (marked[w] == -1) {
      		marked[w] = -2;
        	substar.add(w);
        }
  		}
    }	        
    return arrayListToDataStructure(substar);
	}

	@Override
	int[] arrayListToDataStructure(ArrayList<Integer> input) {
		int[] result = new int [input.size()];
		for (int i = 0; i < input.size(); i++)
			result[i] = input.get(i);
		Arrays.sort(result);
		return result;
	}

	@Override
	boolean isClique(int[] vs, int[][] graph) {
		 
		 if (vs.length == 0 || vs.length == 1)
			 return true;
		
		 /*iterate quadratically over vs */
		for (int j = 0; j < vs.length; j++) {
			int v = vs[j];
			
			int nbCount = 0;
			for (int i = 0; i < vs.length; i++) {
				
				/*if vertex itself, continue*/
				if (v == vs[i])
					continue;
				
				/*add to nbCount until first element in neighbor[v] that is >= to vs[i]*/
				while (graph[v][nbCount] < vs[i] && nbCount < graph[v].length - 1) {
						nbCount++;
				}
				
				/*if element in vs[i] is not equal to this element in neighbor[v], return false*/
		 			if (vs[i] < graph[v][nbCount]) {
		 				return false;
		 			}		
		 		}  		
		 	}
		 	return true;  
	}

	@Override
	int[][] setUpRound2() {
		/*New nb = H, with only those vertices which are not LBsimplicial*/
		int[][] result = new int[g.n][]; 
    for (int v = verticesNotLBSimplicial.nextSetBit(0); v >= 0; v = verticesNotLBSimplicial.nextSetBit(v + 1)){     
    	
    	int[] newNeighbors = new int[h[v].length]; 
    	int nextElement = 0;
    	for (int i = 0; i < h[v].length; i++) {
    		int w = h[v][i];
    		if (verticesNotLBSimplicial.get(w)) {
    			newNeighbors[nextElement++] = w;
    		}
    	}
    	
    	/*copy to new nb[][]*/
    	result[v] = new int[nextElement];
    	System.arraycopy(newNeighbors, 0, result[v], 0, nextElement);      	
    }
    return result;
	}

	@Override
	int[] getSubstarBFS_Chordal(int v, int compN, int[][] graph) {

		
		ArrayList<Integer> substar = new ArrayList<>();		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = compN; 
		
    queue.add(v);
    
    while (queue.size() != 0) { 
      // Dequeue a vertex from queue
      v = queue.poll();

      //v in substar and already visited        
      if (marked[v] == compN - 10)
      	continue;
      
      countLengthComp++;
      
      for (int i = 0; i < graph[v].length; i++) {
      	int w = graph[v][i];	     	
      	
      	/*If already visited, continue*/
      	if(marked[w] < -1)
      		continue;
  			
      	/*If vertex not yet explored and not part of a separating substar*/
      	else if (marked[w] == 0) { 
          marked[w] = compN;             
          queue.add(w);   
  			}
      	
      	/*If we reached a neighbor*/
      	else if (marked[w] == -1) {
      		marked[w] = compN;
        	substar.add(w);
        }
      	
      	/*If we reach a vertex that is part of a separating substar
      	 *  1) check from which side we reached this substar,
      	 *  		and mark all vertices on the other side with compN.
      	 *  2) mark the entire substar and put each vertex in queue
      	 */
      	else if(marked[w] > 0) {
      		int s = markedSepSub[w];
      		int x = Arrays.binarySearch(shortSNeighbs[s], v); 
      		
      		/*v in longSNeighbs
      		 * 1) continue searching in longSNeighbs */
      		if (x < 0) {
      			for (int a = 0; a < longSNeighbs[s].length; a++) {
      				int z = longSNeighbs[s][a];
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		/*v in shortSNeighbs
      		 * 1) continue searching in shortSNeighbs*/
      		else {
      			for (int a = 0; a < shortSNeighbs[s].length; a++) {
      				int z = shortSNeighbs[s][a];
      				if (marked[z] == 0) {
                marked[z] = compN;               
                queue.add(z);  
      				}
            	else if (marked[z] == -1) {
            		marked[z] = compN;
              	substar.add(z);
              }
      			}
      		}
      		
      		/*mark substar with compN*/
      		for (int b = 0; b < substars[s].length; b++) {
      			int y = substars[s][b]; 
            marked[y] = compN - 10;         			
      		}        		
      	}        	
  		}
    }     
    return arrayListToDataStructure(substar);
	} 

	@Override
	int[] markSeparator_Chordal(int id, int[][] graph) {
		
		int[] result = markedSepSub.clone();
		
		/*remove separating substar that overlap with id and its neighbors*/
		if (result[id] != 0) {
			int s = result[id];
			for (int i = 0; i < substars[s].length; i++) {
				result[substars[s][i]] = 0;
			}  				
		}
		//Neighbors
		for(int i = 0; i < graph[id].length; i++) {
			int w = graph[id][i];
	 		if (result[w] > 0) {
	 			int s = result[w];
	 			for (int j = 0; j < substars[s].length; j++) {
	 				result[substars[s][j]] = 0;
	 			}  				
	 		} 			
		}
		
		/*Mark ID and its neighbors with -1*/
		result[id] = -1;
		for(int i = 0; i < graph[id].length; i++) {
			int w = graph[id][i];
			result[w] = -1;
		}
		return result;
	}

	@Override
	XBitSet getSecondNeighbors(int id, int[][] graph) {
		XBitSet secondNeighbors = new XBitSet(g.n);
		for (int i = 0; i < graph[id].length; i++) {
			int w = graph[id][i];
			for (int j = 0; j < graph[w].length; j++) {
				secondNeighbors.set(graph[w][j]);
			}
		}
	
		for (int i = 0; i < graph[id].length; i++) {
			secondNeighbors.clear(graph[id][i]);
		}
		secondNeighbors.clear(id);
		return secondNeighbors;
}


	@Override
  void addToSeparatingSubs(int[] sub, int compNumber, boolean subNoClique, int[][] graph) {

		
  	/*Make sure that separating substars do not overlap with one another*/
  	boolean noOverlap = true;
  	for (int s : sub) {
  		if (markedSepSub[s] != 0) {
  			noOverlap = false;
  			break;
  		}      			
  	}	
  	
  	if (noOverlap) {
  		/* Mark the vertices in markedSepSub*/
  		for (int s : sub) {
  			markedSepSub[s] = nSepSubs + 1;
  		}
  		
  		/*Save the short-sided and long-sided neighbor sets of the substar*/
  		int[] neighbsCompSide = getSubNeighbors(sub, compNumber, true, graph);
  		int[] neighbsOtherSide = getSubNeighbors(sub, compNumber, false, graph);
  		
  		/*keep track of the substar, and its two neighbor sets*/
  		substars[nSepSubs + 1] = sub;  		
  		
  		if (neighbsCompSide.length > neighbsOtherSide.length) {
  			shortSNeighbs[nSepSubs + 1] = neighbsOtherSide;
  			longSNeighbs[nSepSubs + 1] = neighbsCompSide; 			
  		}
  		else {
  			shortSNeighbs[nSepSubs + 1] = neighbsCompSide;
  			longSNeighbs[nSepSubs + 1] = neighbsOtherSide; 	
  		}
  		
  		nSepSubs++;
  		
  	}
  }
	
	@Override
  int[] getSubNeighbors(int[] sub, int compNumber, boolean isComp, int[][] graph) {
  	ArrayList<Integer> result = new ArrayList<Integer>();
  	marked = markSubstar(sub, graph);

  	for (int s : sub) {
  		for (int i = 0; i < graph[s].length; i++) {
  			int v = graph[s][i];
  			if (isComp) {
	  			if (marked[v] == compNumber && !result.contains(v))
	  				result.add(v);
  			}
  			else {
  				if (marked[v] != compNumber && marked[v] != nSepSubs + 10 && !result.contains(v)) {
  					result.add(v);
  				}
  			}
  		}  		
  	}
  	return arrayListToDataStructure(result);
  }
  
	/*marks the substar*/
  @Override
	int[] markSubstar(int[] sub, int[][] graph) {			
		for(int s : sub) {
			marked[s] = nSepSubs + 10;
		}
		return marked;
	}

  
	@Override
	int[] cloneBuiltIn(int[] set) {
		return set.clone();
	}

	@Override
	int[][] initiateSubstars(int length) {
		int[][] result = new int[length][];
		return result;
	}

	@Override
	void printVertexSet(int[] vs) {
		System.out.println(Arrays.toString(vs));
		
	}


}









