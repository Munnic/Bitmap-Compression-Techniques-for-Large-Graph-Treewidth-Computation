

package tw.experiment1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Random;



import tw.common.XBitSet;

public class testXBitSet {

	public static void main(String args[]) {
		
		
		XBitSet[] set = new XBitSet[5]; 
		
  	for (int i = 0; i < set.length; i++) {
  		set[i] = new XBitSet(set.length);
  	}
		
		set[0].set(1);
		set[0].set(3);
		set[1].set(0);
		set[1].set(4);
		set[3].set(1);
		
		set[2].set(4);
		set[4].set(1);
		set[4].set(2);

		set[4].set(3);
		
		System.out.println(isConnected(set));
		
		
		
		
				
		/*Is clone correct?
		for (int i = 1000; i <= 1000000; i*= 10) {
			int[] set = getInts(i, 2);
			
			
			Runtime runtime = Runtime.getRuntime();
			runtime.gc();
			long memory1 = runtime.totalMemory() - runtime.freeMemory();
			
			XBitSet set1 = new XBitSet(i);
			set1.set(7);
			
			long memoryOriginal = runtime.totalMemory() - runtime.freeMemory() - memory1;
			
			/*-------------------------------------------
			
			runtime.gc();
			memory1 = runtime.totalMemory() - runtime.freeMemory();

			XBitSet set2 = new XBitSet(i);
			set1.set(8);

			long memoryCopy = runtime.totalMemory() - runtime.freeMemory() - memory1;
			
			
			
			System.out.println("\nmemoryOriginal = " + memoryOriginal + ", memoryCopy = " + memoryCopy + ", difference = " + (memoryOriginal - memoryCopy));
		
		}*/
		/*
		for (int v = result2.getFirstSetBit(); v >= 0; v = result2.getFirstSetBit()) {
			System.out.println(v);
			result2.set(v, false);
		}*/
	
		
		//System.out.println(result2);
		
		//EWAHIterator it = new EWAHIterator.getEWAHIterator(result2);
		//EWAHIterator it = result2.getEWAHIterator();
				
		/**
		long time1 = System.currentTimeMillis();
		IntIteratorImpl iter = new IntIteratorImpl(result2.getEWAHIterator());
		while(iter.hasNext()) {
			int x = iter.next();
		}
		long twoStep = System.currentTimeMillis() - time1;
		
		System.out.println("Time twoStep = ");
		
		long time2 = System.currentTimeMillis();
		IntIterator it = result2.intIterator();
		while(it.hasNext()) {
			int x = it.next();
		}
		long oneStep = System.currentTimeMillis() - time2;
		
		long time0 = System.currentTimeMillis();
		for (int v = result2.getFirstSetBit(); v >= 0; v = result2.getFirstSetBit()) {
			result2.set(v, false);
			int x = v;
		}
		long firstBit = System.currentTimeMillis() - time0;
		
		
		System.out.println("Time twoStep = " + twoStep + ", time oneStep = " + oneStep + ", time firstSetBit = " + firstBit);
		*/
	}

  public static boolean isConnected(XBitSet[] connected) {
  	
  	if (connected.length == 0)
  		return true;
  	
  	XBitSet connectedSet = (XBitSet) connected[0].clone();
  	
  	/*Add all elements which are reached to queue*/
		LinkedList<Integer> queue = new LinkedList<Integer>();
		for (int v = connectedSet.nextSetBit(0); v >= 0; v = connectedSet.nextSetBit(v + 1))
			queue.add(v);
  	
		
		while (queue.size() != 0) { 
      // Dequeue a vertex v  from queue
      int v = queue.poll();
      
      /*New vertices reached, add to connectedSet and queue*/
      for (int w = connected[v].nextSetBit(0); w >= 0; w = connected[v].nextSetBit(w + 1)) {
      	if (!connectedSet.get(w)) {
      		connectedSet.set(w);
      		queue.add(w);
      		
      	}
      }
		}
		
		System.out.println("connected");
		
		for (int i = 0; i < connected.length; i++) {
			System.out.println(connected[i]);
		}
		
		System.out.println("connectedSet");
		
		System.out.println(connectedSet);

		

		
		
		if (connectedSet.cardinality() == connected.length) {
			return true;
		}
		else
			return false;
  }
	
	public static int[] getInts(int size, int factor) {
		int[] set = new int[size];
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		return set;
		
	}
	
	public static long measureMemory() {
		Runtime runtime = Runtime.getRuntime();
		runtime.gc(); 
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	static ArrayList<XBitSet> cloneArrayList(ArrayList<XBitSet> list, int size){
		ArrayList<XBitSet>  newList = new ArrayList<XBitSet>();
		for (int i = 0; i < list.size(); i++) {		
			XBitSet newSet = new XBitSet(size);
			for(int w = list.get(i).nextSetBit(0); w >= 0; w = list.get(i).nextSetBit(w + 1)){
				newSet.set(w);
			}
			newList.add(newSet);
			//newList.add((XBitSet) list.get(i).clone());
		}		
		return newList;
	}
	
	
	static XBitSet cloneTest(XBitSet original, int size) {
		XBitSet result = new XBitSet(size);
		return result;
	}
	
}

