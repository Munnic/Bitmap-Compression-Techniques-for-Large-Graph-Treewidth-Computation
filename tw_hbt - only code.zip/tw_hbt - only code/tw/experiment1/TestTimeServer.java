package tw.experiment1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Random;

public class TestTimeServer {
	
	public static void main(String args[]) {
		
		int nStart = 115;
		int nEnd = 4817330;
		double nFactor = 1.1;
		
		for (int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * nFactor) * nFactor) * nFactor) * nFactor)) {
			if (n == 1097) {
				n = 1100;
			}
			System.out.println(n);
		
		}
		
		/*
		String test1 = measureProcessorTime();
		
		int[] set1 = getInts(1000, 100, 4);
		String test2 = measureProcessorTime();
		
		System.out.println("\nDit is test1: " + test1 + "\nDit is test2: " + test2);*/
		
	}

	static String measureProcessorTime() {
		try
    {
       Runtime rt = Runtime.getRuntime();
       String[] cmdString = {"time"};

       System.out.println(Arrays.toString(cmdString));
       Process pr = rt.exec(cmdString);

       BufferedReader input = new BufferedReader(new InputStreamReader(
                                                 pr.getInputStream()));

       String line = null;

       while ((line = input.readLine()) != null)
       {
          System.out.println(line);
       }

       int exitVal = pr.waitFor();
       System.out.println("Exited with error code " + exitVal);
       
       
       return line;

    }
    catch (Exception e)
    {
       System.out.println(e.toString());
       e.printStackTrace();
    }
		
		return "niet gelukt";
		
	}
	
	public static int[] getInts(int size, int factor, int seed) {
		int[] set = new int[size];
		Random random = new Random(seed);
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		return set;
		
	}
	
}
