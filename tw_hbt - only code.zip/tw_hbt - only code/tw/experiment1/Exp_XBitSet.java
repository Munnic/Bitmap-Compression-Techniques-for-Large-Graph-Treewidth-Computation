package tw.experiment1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import org.roaringbitmap.PeekableIntIterator;
import org.roaringbitmap.RoaringBitmap;

import tw.common.XBitSet;
import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;


/**Important note:
 * To do: For XBitSet we can have 2 algorithms to construct the components.*/
public class Exp_XBitSet extends AbstractExperiment <XBitSet> {
	
	Graph_NR g;
	TreeDecomposition_NR td;

	
	Exp_XBitSet (Graph_NR g, TreeDecomposition_NR td, int lengthSepList, boolean BFS, boolean parallel){		
		super(g, td, lengthSepList, BFS, parallel);
		this.g = g;
		this.nb = new XBitSet[g.n];
		
		if (Run.traceDataStructures) {
			System.out.println("Data structure = XBitSet");
		}
	}
	
	
	/*Cast the from int[] to the data structure*/
	@Override
	XBitSet cast(int[] set) {		
		XBitSet result = new XBitSet(g.n);
		if (set != null) {
			for(int i = 0; i < set.length; i++)
				result.set(set[i]);
		}
		return result;
	}
	
	/*marks the separator with -1*/
	@Override
	int[] markSeparator(int[] marked, XBitSet sep) {
		for (int w = sep.nextSetBit(0); w >= 0; w = sep.nextSetBit(w + 1)) {
			marked[w] = -1;
		}
		return marked;
	}
	
	/*mark an entire component with DFS*/
	@Override
	void mark(int v, int[] marked, int nc) {
    if (marked[v] != 0) return;
    marked[v] = nc; 
    for (int w = nb[v].nextSetBit(0); w >= 0; w = nb[v].nextSetBit(w + 1)) {
    	mark(w, marked, nc);
    }
	}
	
	void markBFS(int v, int[] marked, int nc) {
		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = nc; 
    queue.add(v);
    
    while (queue.size() != 0) { 
        // Dequeue a vertex from queue and print it 
        v = queue.poll();  
        
        for(int w = nb[v].nextSetBit(0); w >= 0; w = nb[v].nextSetBit(w+1)) {	
    			
    			if ((marked[w] == 0)) { 
            marked[w] = nc; 
            queue.add(w);   
    			}
    		}
    }	
	}
	
	
	/*Add all marked components to a result*/
	@Override
	ArrayList<XBitSet> addToResult(int[] mark, int nc) {
		ArrayList<XBitSet> result = new ArrayList<XBitSet>();
		
    for (int c = 1; c <= nc; c++) {
      result.add(new XBitSet(g.n));
    }

    for (int v = 0; v < g.n; v++) {
      int c = mark[v];
      if (c >= 1) {
        result.get(c - 1).set(v);
      }
    }
    
    return result;
	}
	
	@Override
	ArrayList<XBitSet> compsDFS_parallel(XBitSet separator){
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    XBitSet rest = g.all.subtract(separator);
    
    for (int v = rest.nextSetBit(0); v >= 0;
        v = rest.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) nb[v].clone();
      XBitSet toBeScanned = c.subtract(separator);

      c.set(v);      
      
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
            w = toBeScanned.nextSetBit(w + 1)) {
          c.or(nb[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
        
      }
      result.add(c.subtract(separator));
      rest.andNot(c);
      
    }
    return result;
	}
	
	ArrayList<XBitSet> cloneArrayList(ArrayList<XBitSet> list){
		ArrayList<XBitSet>  newList = new ArrayList<XBitSet>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((XBitSet) list.get(i).clone());
		}		
		return newList;
	}


	@Override
	long calculateMemory(XBitSet vertexSet) {
		//store the bits, as a long[]
		//long array has its size and memory for array
		//constants: 4 ints, 2 longs, 1 boolean
		
		long memory = (long) Math.ceil(vertexSet.size() / 64.) * 8;
		
		return memory;
	}
	
	@Override
	XBitSet cloneBuiltIn(XBitSet set) {
		return (XBitSet) set.clone();
	}
	
	@Override
	XBitSet cloneManually(XBitSet set) {
		XBitSet result = new XBitSet(g.n);				
		for (int w = set.nextSetBit(0); w >= 0; w = set.nextSetBit(w+1)) {
			result.set(w);
		}
		return result;
	}


	@Override
	void AnalyseTwoAlgorithms(ArrayList<XBitSet> comps2, ArrayList<XBitSet> comps22) {
		// TODO Auto-generated method stub
		
	}
	
}








