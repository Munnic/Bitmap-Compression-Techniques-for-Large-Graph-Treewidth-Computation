package tw.experiment1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import tw.common.XBitSet;
import org.roaringbitmap.*;

import com.googlecode.javaewah.EWAHCompressedBitmap;

import tw.common.XBitSet;

public class TestRoaring {

	public static void main(String args[]) {
		
		
		/*In ArrayContainer (and perhaps elsewhere) do we still need to look into INITIAL_CAPACITY * containerSize,
		 * which could now be indicated with always 64????? */
		
		/*Also look into Util.toIntUnsigned*/
				
		
		
		int containerSize = 12;
	
		RoaringBitmap.containerSize = containerSize;
		BitmapContainer.MAX_CAPACITY =  (int) Math.pow(2, containerSize);
		ArrayContainer.MAX_CONTAINER_SIZE = containerSize;
		ArrayContainer.DEFAULT_MAX_SIZE = (int) Math.pow(2, containerSize - 4);
		ArrayContainer.ARRAY_LAZY_LOWERBOUND = ArrayContainer.DEFAULT_MAX_SIZE/4;
		
		
		
		/*Check Roaring 8 for large numbers, does it function correctly??*/
		/**
		int[] set1 = getInts(100, 7000, 4);
		Arrays.sort(set1);
		
		System.out.println(Arrays.toString(set1));
		RoaringBitmap roar1 = RoaringBitmap.bitmapOf(containerSize, set1);
		
		System.out.println(roar1);
		System.out.println("\nHighlowcontainer.values: " + Arrays.toString(roar1.highLowContainer.values));
		System.out.println("Highlowcontainer.keys: " + Arrays.toString(roar1.highLowContainer.keys));
		System.out.println("amount of containers = " + roar1.highLowContainer.size);
			
		System.out.println(70000 >>> 8);*/
		
		
		
		/*Do binary operations function properly?*/
		
		for (int i = 0; i < 1000; i++) {
			
			int n = 10000;
			int f = 4;
		
			int[] set1 = getInts(n, f, i);
			int[] set2 = getInts(n, f, i+1);
			Arrays.sort(set1);
			Arrays.sort(set2);
			
			
			EWAHCompressedBitmap ewah1 = EWAHCompressedBitmap.bitmapOf(set1);
			EWAHCompressedBitmap ewah2 = EWAHCompressedBitmap.bitmapOf(set2);
			
			RoaringBitmap roar1 = RoaringBitmap.bitmapOf(containerSize, set1);
			RoaringBitmap roar2 = RoaringBitmap.bitmapOf(containerSize, set2);
			
			XBitSet xbit1 = new XBitSet(n*f, set1);
			XBitSet xbit2 = new XBitSet(n*f, set2);
			
			EWAHCompressedBitmap ewah3 = ewah1.and(ewah2);
			EWAHCompressedBitmap ewah4 = ewah1.andNot(ewah2);
			EWAHCompressedBitmap ewah5 = ewah1.or(ewah2);
			
			RoaringBitmap roar3 = RoaringBitmap.and(roar1, roar2);
			RoaringBitmap roar4 = RoaringBitmap.andNot(roar1, roar2);
			RoaringBitmap roar5 = RoaringBitmap.or(roar1, roar2);
			
			XBitSet xbit3 = xbit1.intersectWith(xbit2);
			XBitSet xbit4 = xbit1.subtract(xbit2);
			XBitSet xbit5 = xbit1.unionWith(xbit2);
			
			/**
			System.out.println(Arrays.toString(roar2.highLowContainer.values));
			System.out.println(roar2);
			System.out.println(ewah2);
			System.exit(1);
			*/
			
			/**
			boolean test1 = equalsRoarEWAH(roar1, ewah1, 1);
			if (!test1) { 
				System.out.println("roar1 == ewah1 = " + test1);
				System.exit(1);
			}
			
			//System.out.println("set2 = " + Arrays.toString(set2));
			boolean test2 = equalsRoarEWAH(roar2, ewah2, 2);
			if (!test2) { 
				System.out.println("roar2 == ewah2 = " + test2);
				System.exit(1);
			}
			boolean test3 = equalsRoarEWAH(roar3, ewah3, 3);
			if (!test3) { 
				System.out.println("and equals     = " + test3);
				System.exit(1);
			}
			boolean test4 = equalsRoarEWAH(roar4, ewah4, 4);
			if (!test4) { 
				System.out.println("andNot equals  = " + test4);
				System.exit(1);
			}
			boolean test5 = equalsRoarEWAH(roar5, ewah5, 5);
			if (!test5) { 
				System.out.println("or equals      = " + test5);
				System.exit(1);
			}
			*/
			
			
			boolean test1 = equalsXbitEWAH(xbit1, ewah1, 1);
			if (!test1) { 
				System.out.println("xbit1 == ewah1 = " + test1);
				System.exit(1);
			}
			
			//System.out.println("set2 = " + Arrays.toString(set2));
			boolean test2 = equalsXbitEWAH(xbit2, ewah2, 2);
			if (!test2) { 
				System.out.println("xbit2 == ewah2 = " + test2);
				System.exit(1);
			}
			boolean test3 = equalsXbitEWAH(xbit3, ewah3, 3);
			if (!test3) { 
				System.out.println("and equals     = " + test3);
				System.exit(1);
			}
			boolean test4 = equalsXbitEWAH(xbit4, ewah4, 4);
			if (!test4) { 
				System.out.println("andNot equals  = " + test4);
				System.exit(1);
			}
			boolean test5 = equalsXbitEWAH(xbit5, ewah5, 5);
			if (!test5) { 
				System.out.println("or equals      = " + test5);
				System.exit(1);
			}
		
		}
		
		
		/*Show the amount of container for a bitmap*/
		/**
		for (int i = 1000; i <= 1000; i*= 10) {
			int[] set1 = getInts(i, 2, 1);
			int[] set2 = getInts(i, 2, 3);
			Arrays.sort(set1);
			Arrays.sort(set2);
			System.out.println("\nset.length = " + set1.length);
			
			System.out.println(Arrays.toString(set1));
			RoaringBitmap roar1 = RoaringBitmap.bitmapOf(containerSize, set1);
			RoaringBitmap roar2 = RoaringBitmap.bitmapOf(containerSize, set2);
			System.out.println("amount of containers = " + roar1.highLowContainer.size);
			
			XBitSet xbit1 = new XBitSet(set1);
			XBitSet xbit2 = new XBitSet(set2);			
			
			
			xbit1.andNot(xbit2);
			int[] xbitArray = xbit1.toArray();
			System.out.println("\nXBitSet = " + Arrays.toString(xbitArray));
			
			roar1.andNot(roar2);
			int[] roarArray = roar1.toArray();
			System.out.println("Roaring = " + Arrays.toString(roarArray));
			
			
			System.out.print("\nThe arrays are the same. ");
			for(int j = 0; j < xbitArray.length; j++) {
				if(xbitArray[j] != roarArray[j]) {
					System.out.println("FALSE!!!");
					break;
				}
			}
			
			
			

		}*/
		
		System.out.println("\nFinito!!");
		

		
		/*Is clone correct?*/
		/**
		for (int i = 1000; i <= 1000000; i*= 10) {
			int[] set = getInts(i, 2);
			
			long memory1 = measureMemory();
			ArrayList<RoaringBitmap> list1 = new ArrayList<RoaringBitmap>();
			list1.add(RoaringBitmap.bitmapOf(set));
			long memoryOriginal = measureMemory() - memory1;
			
			memory1 = measureMemory();
			ArrayList<RoaringBitmap> list2 = cloneArrayList(list1);
			long memoryCopy = measureMemory() - memory1;

			
			System.out.println("\nmemoryOriginal = " + memoryOriginal + ", memoryCopy = " + memoryCopy + ", difference = " + (memoryOriginal - memoryCopy));
		}*/
		
		/*How to iterate over a list?*/
		/**
		int[] set = getInts(10000, 2);
		
		long time1 = System.currentTimeMillis();
		PeekableIntIterator iter = result.getIntIterator();
		while (iter.hasNext()) {
			int x = 0;
			iter.next();
		}
		long iteratorTime = System.currentTimeMillis() - time1;
		
		
		time1 = System.currentTimeMillis();
		result.forEach(new IntConsumer() {		 
			public void accept(int value) {
				int x = 0;		       
			}});			    		
		long forEachTime = System.currentTimeMillis() - time1;
		
		
		//System.out.println(result);
		time1 = System.currentTimeMillis();
		for(int w = (int) result.nextValue(0); w >= 0; w = (int) result.nextValue(w+1)){ 
			 int x = 0;
		}
		long timeFor = System.currentTimeMillis() - time1;
		
		time1 = System.currentTimeMillis();
		while (!result.isEmpty()) {
			int x = 0;
			result.remove(result.first());
		}
		long timeFirst = System.currentTimeMillis() - time1;
		
		
		System.out.println("\nTime iterator = " + iteratorTime + ", time forEach = " + forEachTime + ", timeFor = " + timeFor + ", time timeFirst = " + timeFirst);
		*/

	}
	
	
	public static int[] getInts(int size, int factor, int seed) {
		int[] set = new int[size];
		Random random = new Random(seed);
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		return set;
		
	}
	
	public static long measureMemory() {
		Runtime runtime = Runtime.getRuntime();
		runtime.gc(); 
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	
	
	static ArrayList<RoaringBitmap> cloneArrayList(ArrayList<RoaringBitmap> list){
		ArrayList<RoaringBitmap>  newList = new ArrayList<RoaringBitmap>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((RoaringBitmap) list.get(i).clone());
		}		
		return newList;
	}
	
	public static boolean equalsRoarEWAH(RoaringBitmap roar, EWAHCompressedBitmap ewah, int i) {
		
		String r = roar.toString();
		String e = ewah.toString();
		
		boolean eq = r.equals(e);
		
		if (eq == false) {
			System.out.println("test" + i + " roar: " + r);
			System.out.println("test" + i + " ewah: " + e);
			System.exit(1);
		}

			
		return eq;
	}
	
	
	public static boolean equalsXbitEWAH(XBitSet xbit, EWAHCompressedBitmap ewah, int i) {
		
		String r = xbit.toString().replaceAll("\\s+","");;
		String e = ewah.toString();
		
		boolean eq = r.equals(e);
		
		if (eq == false) {
			System.out.println("test" + i + " xbit: " + r);
			System.out.println("test" + i + " ewah: " + e);
			System.exit(1);
		}

			
		return eq;
	}
	

}








