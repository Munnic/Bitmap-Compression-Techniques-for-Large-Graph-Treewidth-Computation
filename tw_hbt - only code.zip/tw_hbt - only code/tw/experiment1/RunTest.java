package tw.experiment1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;

public class RunTest {
	
	static int lengthSepList = 20;
	static int numberOfRuns  = 5;
	static int run = 0;
//	static String typeOfMeasurement = "timePKT";
	
	/*--------Zorg dat aan het file geappendeerd wordt!!!------------*/
	
	static boolean runPace = false;
	static boolean runPKT  = true;
	
	
	/*which data structures and algorithms do we measure?*/
	static boolean expIntsBFS 			= false;
	static boolean expXBitBFS 			= false;
	static boolean expEWAHBFS 			= true;
	static boolean expRoaring8BFS 	= false;
	static boolean expRoaring10BFS  = false;
	static boolean expRoaring12BFS  = false;
	static boolean expRoaring14BFS  = false;
	static boolean expRoaring16BFS  = true;
	
	static boolean expIntsPAR 			= false;
	static boolean expXBitPAR 			= false;
	static boolean expEWAHPAR 			= false;
	static boolean expRoaring8PAR 	= false;
	static boolean expRoaring10PAR  = false;
	static boolean expRoaring12PAR  = false;
	static boolean expRoaring14PAR  = false;
	static boolean expRoaring16PAR  = false;	
	
	static boolean useRun8      = false;
	static boolean useRun10     = false; //do we make use of runOptimize? (true for comparison!!)
	static boolean useRun12     = false;
	static boolean useRun14     = false;
	static boolean useRun16     = false;
	static boolean withoutRun = true;  //do make use of Roaring without runOptimize?
	
	/*For experiment these should be true*/
	static boolean startNewFile = false; //Create a new file or append to afalsed one?
	static boolean writeToFile = false;
	static boolean analyzeCompsDistribution = false;
	static boolean analyseRunOpt  = false;
	
	/*For experiment these should be false*/
	static boolean traceDataStructures = true;
	static boolean traceMemoryAndTime = true;
	
	static int edges;
	


	public static void main (String args[]) {
		
			if (runPKT)  runPKT (lengthSepList);
	}
		
	
	static void runPKT(int lengthSepList) {
				
		int nStart = 1000;
		int nEnd = 4817330;
		double nFactor = 1.1; //Every time * nFactor
		
		for (int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * nFactor) * nFactor) * nFactor) * nFactor)) {
			
			/*adjust for skip in graphs*/
			if (n == 1097) {
				n = 1100;
			}
	      		   		
  		String graphName = "pkt_n" + n + "_k40_p0.075_seed1";
  		String path = "instance/pkt";
  		String separators = "separators/" + graphName;
  		String graph      = "graphs/" + graphName;
  		
  		String filePath   = "log/benchmark/ThirdResults/MemoryAndTime";
  		String filePath2   = "log/benchmark/ThirdResults/CompsDistribution";
  		String filePath3   = "log/benchmark/ThirdResults/RoarAnalyse";
  		
  		
  		/*Read graph and tree decomposition*/
  		Graph_NR g              = Graph_NR.readGraph(path, graph);
  		TreeDecomposition_NR td = TreeDecomposition_NR.readDecomposition(path, separators, g);
  		
  		long reached = 0;
  		long gn2 = (long) g.n * g.n;
  		
  		for (int i = 0; i < g.n; i++) {
  			int length = g.neighbor[i].length;
  			reached += g.neighbor[i][length - 1];
  			
  		}
  		
  		
  		double percentage = ((double) reached / gn2) * 100;  
  		System.out.println("g.n = " + g.n + ", gn2 = " + gn2 + ", reached = " + reached + ", percentage = " + percentage);
  		
  		
  		/*Delete the first element of td.bags, because it is null. 
  		int[][] td2 = new int[td.bags.length - 1][];
  		System.arraycopy(td.bags, 1, td2, 0, td.bags.length - 1);
  		td.bags = td2;	
  		
  		System.out.println("\nRun: " + run + ", Graph: pkt_" + n + ", n = " + g.n + ", nBags = " + td.bags.length);
  		
  		for (int i = 0; i < g.n; i++) {
  			edges += g.neighbor[i].length;
  		}
  		edges = edges / 2;
  		
  		performExperiments(g, td, filePath, filePath2, filePath3, graphName);*/
	      		
		}
	}
	
	
 
	static void performExperiments(Graph_NR g, TreeDecomposition_NR td, String filePath, String filePath2, String filePath3, String graphName) {
		
		/* --------  Test  ---------*/
		
		int nRounds = 2;
		for (int i = 0; i < nRounds; i ++) {
			run = i;
				
			if (expEWAHBFS) {
	  		Exp_EWAH_Test exp3 = new Exp_EWAH_Test(g, td, lengthSepList, true, false);
				exp3.runExperiment();
				if (run == 0)
					System.out.println("EWAH intIterator  " + exp3.timeComponentsBFS/1000000 + " ms");
				if (run == 1)
					System.out.println("EWAH a : b        " + exp3.timeComponentsBFS/1000000 + " ms");
	
			}
		}
		
		nRounds = 5;
		for (int i = 0; i < nRounds; i ++) {
			run = i;
				
  		if (expRoaring16BFS) {
	  		Exp_Roaring_Test exp8 = new Exp_Roaring_Test(g, td, lengthSepList, 16, true, false, false);
  			exp8.runExperiment();
				if (run == 0)
					System.out.println("Roaring PeekableIterator  " + exp8.timeComponentsBFS/1000000 + " ms");
				if (run == 1)
					System.out.println("Roaring a: b              " + exp8.timeComponentsBFS/1000000 + " ms");
				if (run == 2)
					System.out.println("Roaring IntIterator       " + exp8.timeComponentsBFS/1000000 + " ms");
				if (run == 3)
					System.out.println("Roaring forEach           " + exp8.timeComponentsBFS/1000000 + " ms");
				if (run == 4)
					System.out.println("Roaring firstSetBit       " + exp8.timeComponentsBFS/1000000 + " ms");
  		}
		}
		
		
		
		
		
		
		if(true)
			return;
		
		
		
		/*------------------------------*/
		/*------------- BFS ------------*/
		/*------------------------------*/
		
		if (expXBitBFS && (g.n <= 310000)) {
  		Exp_XBitSet exp2 = new Exp_XBitSet(g, td, lengthSepList, true, false);
  		String fileName = filePath + "/BFS/XBitSet/BFS_xbit_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp2.runExperiment();
  		if (writeToFile)
  			exp2.writeToFile(fileName);
		}		
		
		if (expIntsBFS) {
  		Exp_Ints exp1 = new Exp_Ints(g, td, lengthSepList, true, false);
  		String fileName = filePath + "/BFS/Ints/BFS_ints_" + graphName + ".csv" ;	      		
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp1.runExperiment();
  		if (writeToFile)
  			exp1.writeToFile(fileName);
		}
		
		if (expEWAHBFS) {
  		Exp_EWAH exp3 = new Exp_EWAH(g, td, lengthSepList, true, false);
  		String fileName = filePath + "/BFS/EWAH/BFS_EWAH_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp3.runExperiment();
  		if (writeToFile)
  			exp3.writeToFile(fileName);
		}
		
		if (withoutRun) {
			if (expRoaring8BFS && g.n <= 65536) {
	  		Exp_Roaring exp4 = new Exp_Roaring(g, td, lengthSepList, 8, true, false, false);
	  		String fileName = filePath + "/BFS/Roaring8/BFS_Roaring8_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp4.runExperiment();
    		if (writeToFile)
    			exp4.writeToFile(fileName);
    		if (analyzeCompsDistribution && writeToFile) {
    			String fileName2 = filePath2 + "/Roaring8/BFS_Roaring8_" + graphName + ".csv";
    			exp4.writeCompsDistribution(fileName2);
    		}
  		}
  		
  		if (expRoaring10BFS && g.n <= 1048576) {
	  		Exp_Roaring exp5 = new Exp_Roaring(g, td, lengthSepList, 10, true, false, false);
	  		String fileName = filePath + "/BFS/Roaring10/BFS_Roaring10_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp5.runExperiment();
    		if (writeToFile)
    			exp5.writeToFile(fileName);	  		
    		if (analyzeCompsDistribution  && writeToFile) {
    			String fileName2 = filePath2 + "/Roaring10/BFS_Roaring10_" + graphName + ".csv";
    			exp5.writeCompsDistribution(fileName2);
    		}
  		}
			
  		if (expRoaring12BFS) {
	  		Exp_Roaring exp6 = new Exp_Roaring(g, td, lengthSepList, 12, true, false, false);
	  		String fileName = filePath + "/BFS/Roaring12/BFS_Roaring12_"  + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp6.runExperiment();
    		if (writeToFile)
    			exp6.writeToFile(fileName);
    		if (analyzeCompsDistribution  && writeToFile) {
    			String fileName2 = filePath2 + "/Roaring12/BFS_Roaring12_" + graphName + ".csv";
    			exp6.writeCompsDistribution(fileName2);
    		}
  		}
  		
  		if (expRoaring14BFS) {
	  		Exp_Roaring exp7 = new Exp_Roaring(g, td, lengthSepList, 14, true, false, false);
	  		String fileName = filePath + "/BFS/Roaring14/BFS_Roaring14_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp7.runExperiment();
    		if (writeToFile)
    			exp7.writeToFile(fileName);
    		if (analyzeCompsDistribution  && writeToFile) {
    			String fileName2 = filePath2 + "/Roaring14/BFS_Roaring14_" + graphName + ".csv";
    			exp7.writeCompsDistribution(fileName2);
    		}
  		}
  		
  		
  		if (expRoaring16BFS) {
	  		Exp_Roaring exp8 = new Exp_Roaring(g, td, lengthSepList, 16, true, false, false);
	  		String fileName = filePath + "/BFS/Roaring16/BFS_Roaring16_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp8.runExperiment();
    		if (writeToFile)
    			exp8.writeToFile(fileName);
    		if (analyzeCompsDistribution  && writeToFile) {
    			String fileName2 = filePath2 + "/Roaring16/BFS_Roaring16_" + graphName + ".csv";
    			exp8.writeCompsDistribution(fileName2);
    		}    		
  		}		
		}
		

		if (useRun8 && expRoaring8BFS && g.n <= 65536) {
  		Exp_Roaring exp4 = new Exp_Roaring(g, td, lengthSepList, 8, true, false, true);
  		String fileName = filePath + "/BFS/RoaringRun8/BFS_Roaring8_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp4.runExperiment();
  		if (writeToFile)
  			exp4.writeToFile(fileName);
  		if (analyseRunOpt  && writeToFile) {
  			String fileName3 = filePath3 + "/RoaringRun8/BFS_Roaring8_" + graphName + ".csv";
  			exp4.writeAnalyseRunOpt(fileName3);
  		}
		}
		
		if (useRun10 && expRoaring10BFS && g.n <= 1048576) {
  		Exp_Roaring exp5 = new Exp_Roaring(g, td, lengthSepList, 10, true, false, true);
  		String fileName = filePath + "/BFS/RoaringRun10/BFS_Roaring10_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp5.runExperiment();
  		if (writeToFile)
  			exp5.writeToFile(fileName);
  		if (analyseRunOpt  && writeToFile) {
  			String fileName3 = filePath3 + "/RoaringRun10/BFS_Roaring10_" + graphName + ".csv";
  			exp5.writeAnalyseRunOpt(fileName3);
  		}
		}
		
		if (useRun12 && expRoaring12BFS) {
  		Exp_Roaring exp6 = new Exp_Roaring(g, td, lengthSepList, 12, true, false, true);
  		String fileName = filePath + "/BFS/RoaringRun12/BFS_Roaring12_"  + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp6.runExperiment();
  		if (writeToFile)
  			exp6.writeToFile(fileName);
  		if (analyseRunOpt  && writeToFile) {
  			String fileName3 = filePath3 + "/RoaringRun12/BFS_Roaring12_" + graphName + ".csv";
  			exp6.writeAnalyseRunOpt(fileName3);
  		}
		}
		
		if (useRun14 && expRoaring14BFS) {
  		Exp_Roaring exp7 = new Exp_Roaring(g, td, lengthSepList, 14, true, false, true);
  		String fileName = filePath + "/BFS/RoaringRun14/BFS_Roaring14_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp7.runExperiment();
  		if (writeToFile)
  			exp7.writeToFile(fileName);
  		if (analyseRunOpt  && writeToFile) {
  			String fileName3 = filePath3 + "/RoaringRun14/BFS_Roaring14_" + graphName + ".csv";
  			exp7.writeAnalyseRunOpt(fileName3);
  		}
		}
		
		
		if (useRun16 && expRoaring16BFS) {
  		Exp_Roaring exp8 = new Exp_Roaring(g, td, lengthSepList, 16, true, false, true);
  		String fileName = filePath + "/BFS/RoaringRun16/BFS_Roaring16_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp8.runExperiment();
  		if (writeToFile)
  			exp8.writeToFile(fileName);
  		if (analyseRunOpt  && writeToFile) {
  			String fileName3 = filePath3 + "/RoaringRun16/BFS_Roaring16_" + graphName + ".csv";
  			exp8.writeAnalyseRunOpt(fileName3);
  		}
		}		
		
		
		/*--------------------------*/
		/*-------Parallel!!--------*/
		/*-------------------------*/
		
		if (expXBitPAR && (g.n <= 310000)) {
  		Exp_XBitSet exp2 = new Exp_XBitSet(g, td, lengthSepList, false, true);
  		String fileName = filePath + "/PAR/XBitSet/PAR_xbit_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp2.runExperiment();
  		if (writeToFile)
  			exp2.writeToFile(fileName);
		}
		
		//System.exit(1);
		
		if (expIntsPAR && (g.n <= 20000)) {
  		Exp_Ints exp1 = new Exp_Ints(g, td, lengthSepList, false, true);
  		String fileName = filePath + "/PAR/Ints/PAR_ints_" + graphName + ".csv" ;	      		
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp1.runExperiment();
  		if (writeToFile)
  			exp1.writeToFile(fileName);
		}
		
		if (expEWAHPAR && (g.n <= 310000)) {
  		Exp_EWAH exp3 = new Exp_EWAH(g, td, lengthSepList, false, true);
  		String fileName = filePath + "/PAR/EWAH/PAR_EWAH_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp3.runExperiment();
  		if (writeToFile)
  			exp3.writeToFile(fileName);
		}
		
		if (withoutRun) {
			if (expRoaring8PAR && g.n <= 65536) {
	  		Exp_Roaring exp4 = new Exp_Roaring(g, td, lengthSepList, 8, false, true, false);
	  		String fileName = filePath + "/PAR/Roaring8/PAR_Roaring8_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp4.runExperiment();
    		if (writeToFile)
    			exp4.writeToFile(fileName);
  		}
  		
  		if (expRoaring10PAR && g.n <= 1048576) {
	  		Exp_Roaring exp5 = new Exp_Roaring(g, td, lengthSepList, 10, false, true, false);
	  		String fileName = filePath + "/PAR/Roaring10/PAR_Roaring10_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp5.runExperiment();
    		if (writeToFile)
    			exp5.writeToFile(fileName);
  		}
			
  		if (expRoaring12PAR) {
	  		Exp_Roaring exp6 = new Exp_Roaring(g, td, lengthSepList, 12, false, true, false);
	  		String fileName = filePath + "/PAR/Roaring12/PAR_Roaring12_"  + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp6.runExperiment();
    		if (writeToFile)
    			exp6.writeToFile(fileName);
  		}
  		
  		if (expRoaring14PAR) {
	  		Exp_Roaring exp7 = new Exp_Roaring(g, td, lengthSepList, 14, false, true, false);
	  		String fileName = filePath + "/PAR/Roaring14/PAR_Roaring14_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp7.runExperiment();
    		if (writeToFile)
    			exp7.writeToFile(fileName);
  		}
  		
  		
  		if (expRoaring16PAR) {
	  		Exp_Roaring exp8 = new Exp_Roaring(g, td, lengthSepList, 16, false, true, false);
	  		String fileName = filePath + "/PAR/Roaring16/PAR_Roaring16_" + graphName + ".csv" ;	
	  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
  			exp8.runExperiment();
    		if (writeToFile)
    			exp8.writeToFile(fileName);
  		}		
		}
		

		if (useRun8 && expRoaring8PAR && g.n <= 65536) {
  		Exp_Roaring exp4 = new Exp_Roaring(g, td, lengthSepList, 8, false, true, true);
  		String fileName = filePath + "/PAR/RoaringRun8/PAR_Roaring8_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp4.runExperiment();
  		if (writeToFile)
  			exp4.writeToFile(fileName);
		}
		
		if (useRun10 && expRoaring10PAR && g.n <= 1048576) {
  		Exp_Roaring exp5 = new Exp_Roaring(g, td, lengthSepList, 10, false, true, true);
  		String fileName = filePath + "/PAR/RoaringRun10/PAR_Roaring10_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp5.runExperiment();
  		if (writeToFile)
  			exp5.writeToFile(fileName);
		}
		
		if (useRun12 && expRoaring12PAR) {
  		Exp_Roaring exp6 = new Exp_Roaring(g, td, lengthSepList, 12, false, true, true);
  		String fileName = filePath + "/PAR/RoaringRun12/PAR_Roaring12_"  + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp6.runExperiment();
  		if (writeToFile)
  			exp6.writeToFile(fileName);
		}
		
		if (useRun14 && expRoaring14PAR) {
  		Exp_Roaring exp7 = new Exp_Roaring(g, td, lengthSepList, 14, false, true, true);
  		String fileName = filePath + "/PAR/RoaringRun14/PAR_Roaring14_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp7.runExperiment();
  		if (writeToFile)
  			exp7.writeToFile(fileName);
		}
		
		
		if (useRun16 && expRoaring16PAR) {
  		Exp_Roaring exp8 = new Exp_Roaring(g, td, lengthSepList, 16, false, true, true);
  		String fileName = filePath + "/PAR/RoaringRun16/PAR_Roaring16_" + graphName + ".csv" ;	
  		if (writeToFile && run == 0) createNewFile(fileName, g.n, edges);
			exp8.runExperiment();
  		if (writeToFile)
  			exp8.writeToFile(fileName);
		}		
	}	
	
	
	
	
	private static void createNewFile(String fileName, int gn, int edges) {
		if (startNewFile) {
			File fileOld = new File(fileName);		
			fileOld.delete();
		}
		File fileNew = new File(fileName);
		
		try {
			FileWriter ps = new FileWriter(fileNew);		
			ps.write("neighbors(B), separators(B), nSeparatedComps, "
    			+ "components (B), timeComponents(micro s), g.n, g.e, nSeps, nRuns\n");
			ps.write(gn + ", " + edges + ", " + lengthSepList + ", " + numberOfRuns);
			ps.close();
		}
		catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}







