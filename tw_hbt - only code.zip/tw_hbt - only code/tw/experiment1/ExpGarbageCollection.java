package tw.experiment1;

import java.lang.ref.WeakReference;
import java.util.Random;


public class ExpGarbageCollection {
	static Runtime runtime;
	
	public static void main(String args[]) {
		runtime = Runtime.getRuntime();
		
		long memory0 = 0;
		long memory1 = 0;
		long memory2 = 0;
		long memory3 = 0;
		long memory4 = 0;
		long memory5 = 0;
		long memory6 = 0;
		String notGarbage;
		long[] usedMemory = new long[1];
		
		long memory4a = 0;
		long memory1a = 0;
		
		
		/*These parameters can be adjusted. garbageSize has effect on how forceGC operates.*/
		int garbageSize = 10000000;
		long max = 1000000000;
		
		for (int i = 1; i < max; i *= 10) {
			usedMemory = new long[i];
			usedMemory[0] = 199;
			
					
			for (int j = 1; j < max; j *= 10) {
				memory1 = measureMemoryForceGC(garbageSize);
				
				long[] garbage = new long[j];				
				garbage = null;
				
				memory2 = runtime.totalMemory() - runtime.freeMemory();
				memory4 = measureMemoryForceGC(garbageSize);
				
				int[] getI = getInts(j, 5); 		
				getI = null;
				
				memory5 = runtime.totalMemory() - runtime.freeMemory();
				memory6 = measureMemoryForceGC(garbageSize);
				
				
				System.out.println("\ni = " + i + ", j = " + j);
				System.out.println("Before (GC)        = " + memory1);
				System.out.println("Before             = " + memory1);
				System.out.println("After long[]       = " + memory2);
				System.out.println("After long[]  (GC) = " + memory4);
				System.out.println("After getInts      = " + memory5);
				System.out.println("After getInts (GC) = " + memory6);
				
				if (memory4 != memory1) {
					System.out.println("--------- Error: before long[] and after not the same --------------");
				}
				
				if (memory4 != memory6) {
					System.out.println("--------- Error: before getInts and after not the same --------------");
				}
			}
		}		
		/*To make sure that the following variables don't get garbage collected.*/
		notGarbage = usedMemory.toString();
	}




	public static long measureMemoryForceGC(int garbageSize) {
		
		WeakReference<long[]> garbage = new WeakReference <long[]> (new long[garbageSize] );
		garbage.get()[100] = 100;
	
		runtime.gc();
		
		if(garbage.get() != null){
			System.out.println("Error: garbage not collected");
			System.exit(1);
		}
					
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	
	public static int[] getInts(int size, int factor) {
		int[] set = new int[size];
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		return set;
	}
}







