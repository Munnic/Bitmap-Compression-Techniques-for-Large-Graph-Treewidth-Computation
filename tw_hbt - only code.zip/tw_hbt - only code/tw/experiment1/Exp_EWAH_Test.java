package tw.experiment1;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import org.roaringbitmap.PeekableIntIterator;
import org.roaringbitmap.RoaringBitmap;

import tw.common.XBitSet;
import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;

import com.googlecode.javaewah.*;


/**Important note:
 * To do: For XBitSet we can have 2 algorithms to construct the components.*/
public class Exp_EWAH_Test extends AbstractExperiment <EWAHCompressedBitmap> {
	
	Graph_NR g;
	TreeDecomposition_NR td;
	EWAHCompressedBitmap all;

	
	Exp_EWAH_Test (Graph_NR g, TreeDecomposition_NR td, int lengthSepList, boolean BFS, boolean parallel){		
		super(g, td, lengthSepList, BFS, parallel);
		this.g = g;
		this.nb = new EWAHCompressedBitmap[g.n];
		
		int[] rangeOfInts = new int[g.n];
		for (int i = 0; i < g.n; i++) {
			rangeOfInts[i] = i;
		}
		all = EWAHCompressedBitmap.bitmapOf(rangeOfInts);
		
		if (Run.traceDataStructures) {
			System.out.println("Data structure = EWAH");
		}
	}
	
	
	/*Cast the from int[] to the data structure*/
	@Override
	EWAHCompressedBitmap cast(int[] set) {		
		EWAHCompressedBitmap result = EWAHCompressedBitmap.bitmapOf(set);
		return result;
	}
	
	/*marks the separator with -1*/
	@Override
	int[] markSeparator(int[] marked, EWAHCompressedBitmap sep) {		
		IntIteratorImpl iter = new IntIteratorImpl(sep.getEWAHIterator());
		while(iter.hasNext()) {
			marked[iter.next()] = -1;
		}
		return marked;
	}
	
	/*mark an entire component with DFS*/
	@Override
	void mark(int v, int[] marked, int nc) {
    if (marked[v] != 0) return;
    marked[v] = nc; 
    
    IntIterator iter = nb[v].intIterator();
    while (iter.hasNext()) {
    	mark(iter.next(), marked, nc);
    }
	}
	
	void markBFS(int v, int[] marked, int nc) {
		
		if (RunTest.run == 0) {
		
			LinkedList<Integer> queue = new LinkedList<Integer>();
			marked[v] = nc; 
	    queue.add(v);
	    
	    while (queue.size() != 0) { 
        // Dequeue a vertex from queue and print it 
        v = queue.poll();  
        
        IntIterator iter = nb[v].intIterator();
    		while (iter.hasNext()) {
    			int w = iter.next();		
    			
    			if ((marked[w] == 0)) { 
            marked[w] = nc; 
            queue.add(w);   
    			}
    		}
	    }	
		}
		
		if (RunTest.run == 1) {
			LinkedList<Integer> queue = new LinkedList<Integer>();
			marked[v] = nc; 
	    queue.add(v);
	    
	    while (queue.size() != 0) { 
        // Dequeue a vertex from queue and print it 
        v = queue.poll();  
        
        for (int w : nb[v]) {   			
    			if ((marked[w] == 0)) { 
            marked[w] = nc; 
            queue.add(w);   
    			}
    		}
	    }	
		}		
	}
	
	/*Add all marked components to a result*/
	@Override
	ArrayList<EWAHCompressedBitmap> addToResult(int[] mark, int nc) {
		ArrayList<EWAHCompressedBitmap> result = new ArrayList<EWAHCompressedBitmap>();
		
    for (int c = 1; c <= nc; c++) {
      result.add(new EWAHCompressedBitmap());
    }
    

    for (int v = 0; v < g.n; v++) {
      int c = mark[v];
      if (c >= 1) {
        result.get(c - 1).set(v);
      }
    }
    
    return result;
	}
	
	/**use this: 
	 * getFirstSetBit()*/
	@Override
	ArrayList<EWAHCompressedBitmap> compsDFS_parallel(EWAHCompressedBitmap separator){
    ArrayList<EWAHCompressedBitmap> result = new ArrayList<EWAHCompressedBitmap>();
    EWAHCompressedBitmap rest = all.andNot(separator);
    
    for (int v = rest.getFirstSetBit(); v >= 0;	v = rest.getFirstSetBit()) {
    	EWAHCompressedBitmap c = (EWAHCompressedBitmap) nb[v].clone();
    	EWAHCompressedBitmap toBeScanned = c.andNot(separator);
      c.set(v);
      
      while (!toBeScanned.isEmpty()) {
      	EWAHCompressedBitmap save = (EWAHCompressedBitmap) c.clone();
      	
        for (int w = toBeScanned.getFirstSetBit(); w >= 0; w = toBeScanned.getFirstSetBit()) {
          c = c.or(nb[w]);
          toBeScanned.set(w, false);
        }
        toBeScanned = c.andNot(save);
        toBeScanned = toBeScanned.andNot(separator);        
      }
      result.add(c.andNot(separator));
      rest = rest.andNot(c);
      //rest.set(v,false);
    }
    return result;
	}
	
	ArrayList<EWAHCompressedBitmap> cloneArrayList(ArrayList<EWAHCompressedBitmap> list){
		ArrayList<EWAHCompressedBitmap>  newList = new ArrayList<EWAHCompressedBitmap>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((EWAHCompressedBitmap) list.get(i).clone());
		}		
		return newList;
	}


	@Override
	long calculateMemory(EWAHCompressedBitmap vertexSet) {
		// TODO Auto-generated method stub
		return 0;
	}
	
	@Override
	EWAHCompressedBitmap cloneBuiltIn(EWAHCompressedBitmap set) {
		return set.clone();
	}
	
	@Override
	EWAHCompressedBitmap cloneManually(EWAHCompressedBitmap set) {
		EWAHCompressedBitmap result = new EWAHCompressedBitmap();		
		
    IntIterator iter = set.intIterator();
    while (iter.hasNext()) {
    	result.set(iter.next());
    }

    iter = null;
		return result;
	}


	@Override
	void AnalyseTwoAlgorithms(ArrayList<EWAHCompressedBitmap> comps2, ArrayList<EWAHCompressedBitmap> comps225) {
		// TODO Auto-generated method stub
		
	}
	
}








