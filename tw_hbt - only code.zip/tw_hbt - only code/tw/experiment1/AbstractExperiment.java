package tw.experiment1;


import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Random;

import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;

abstract public class AbstractExperiment<T> {
	Graph_NR g;
	TreeDecomposition_NR td;
	public T[] nb;
	boolean parallel;
	boolean BFS;
	boolean DFS;
	Runtime runtime;
	
	static int[] compSizes;
	
	boolean runGC = true;
	
	int seed;
	int lengthSepList;
	int[] selected;
	T[] seps;
		
	boolean traceComponents = false;
	
	boolean compareAlgs = false;
	

	long memory1;
	long memory2;
	long memoryNeighbors;
	long memorySeparators;
	
	long memoryComponentsDFS = 0;
	long memoryComponentsParallel = 0;
	long memoryComponentsBFS = 0;
	
	long timeComponentsDFS = 0;
	long timeComponentsParallel = 0;
	long timeComponentsBFS;
	
	int countComps = 0;
	
	public AbstractExperiment(Graph_NR g, TreeDecomposition_NR td, int lengthSepList, boolean BFS, boolean parallel) {
		this.g = g;
		this.td = td;
		this.nb = (T[]) new Object[g.n];
		this.DFS = DFS;
		this.parallel = parallel;
		this.BFS = BFS;
		this.lengthSepList = lengthSepList; //How many separators do we use? td.bags.length is maximal.
		seed = 1;		
		runtime = Runtime.getRuntime();
				
	}
	
	
	/*To implement for each data structure*/
	abstract <T> T cast(int[] set); /*Cast the from int[] to the data structure*/
	abstract void mark(int v, int[] mark,  int nc); /*mark an entire component with DFS*/
	abstract ArrayList<T> addToResult(int[] mark, int nc); 	/*Add all marked components to a result*/
	abstract int[] markSeparator(int[] marked, T separator); /*marks the separator with -1*/
	abstract ArrayList<T> compsDFS_parallel(T separator); /*parallel DFS*/
	abstract ArrayList<T> cloneArrayList(ArrayList<T> arraylist);
	abstract void markBFS(int v, int[] marked, int nc);
	abstract long calculateMemory(T vertexSet);
	
	abstract T cloneBuiltIn(T set);
	abstract T cloneManually(T set);
	
	abstract void AnalyseTwoAlgorithms(ArrayList<T> comps2, ArrayList<T> comps3);

	
	/**Weak References!!
	abstract WeakReference<int[]> markSeparator_Ref(WeakReference<int[]> marked, T separator);
	abstract void mark_Ref(int v, WeakReference <int[]> mark,  int nc);
	abstract ArrayList<T> addToResult_Ref(WeakReference <int[]> mark, int nc); 	/*Add all marked components to a result*/
	
	
	public void runExperiment() {
		
		boolean testCloningNeighbors = false;
		boolean testCloningComps = true;
		boolean compareRoaring = false;
		
		
		memoryComponentsParallel = 0;
		memoryComponentsBFS = 0;
		timeComponentsParallel = 0;
		timeComponentsBFS = 0;
		countComps = 0;

		
		if(testCloningNeighbors) {
			testForMeasures();
			return;
		}
			
		/*Create the neighborhood. Measure the memory this requires.*/
	  memory1 = measureMemoryForceGC();	
	  T[] nbMeasure = (T[]) new Object[g.n];
		for (int v = 0; v < g.n; v ++) {
			nb[v] = cast(g.neighbor[v]);
		}
		memoryNeighbors = measureMemoryForceGC() - memory1;


		/*Select the separators and cast them to data type*/
		selected = selectSeps(lengthSepList);	
		
		
		memory1 = measureMemoryForceGC();
		seps = (T[]) new Object[selected.length];			
		for (int b = 0; b < selected.length; b++) {
			seps[b] = cast(td.bags[selected[b]]);
		}
		memorySeparators = measureMemoryForceGC() - memory1;
		
			
		if(testCloningComps) {
			testForMeasuresComps(seps);
			return;
		}
		
		if(compareAlgs) {
			compareTwoAlgorithms(seps);
			return;
		}
		
		
		/*Compute the separated components for each bag*/
		/*Use one or two methods.*/
		/*Measure the memory and time requirements*/				
		long time0 = 0;
		for (int s = 0; s < seps.length; s++) {
			
			if(BFS) {
				memory1 = measureMemoryForceGC();
				time0 = System.nanoTime();
				
				ArrayList<T> comps2 = compsBFS(seps[s]);		
				
				timeComponentsBFS += System.nanoTime() - time0;
				memory2 = measureMemoryForceGC() - memory1;	
				memoryComponentsBFS += memory2;		
				countComps += comps2.size();
				
				if (memory2 == 0) {
					System.out.println("component of size zero");
					System.exit(1);
				}
				String noGarbage2 = comps2.toString();
			}

	
			/*if parallel also do the other one*/
			if(parallel) {
				memory1 = measureMemoryForceGC();
				time0 = System.nanoTime();
				
				ArrayList<T> comps2 = compsDFS_parallel(seps[s]);
				
				timeComponentsParallel += System.nanoTime() - time0;	
				memory2 = measureMemoryForceGC() - memory1;	
				memoryComponentsParallel += memory2;	
				countComps += comps2.size();
				
				if (memory2 == 0) {
					System.out.println("component of size zero");
					System.exit(1);
				}
				String noGarbage2 = comps2.toString();
			}			
			
		}
		seps = null;
		
		if (Run.traceMemoryAndTime) printStats();
	}
	
	
  /* Compute connected components of this target graph after
   * the removal of the vertices in the given separator,
   * using Depth-First Search
   * @param separator set of vertices to be removed
   * @return the arrayList of connected components,
   * the vertex set of each component represented by a {@code XBitSet}
   */
	ArrayList<T> compsBFS(T separator) {
		
		compSizes = new int[20];
    int[] marked = new int[g.n];    
    
    /*Mark the separator*/
    marked = markSeparator(marked, separator);
    
    /*number of components*/
    int nc = 0;

    /*mark all the components one by one with DFS*/
    for (int v = 0; v < g.n; v++) {
      if (marked[v] == 0) {
        nc++;
        if (DFS) {
        	mark(v,marked,nc);}
        else
        	markBFS(v, marked, nc);
      }
    }
    
    ArrayList<T> result;
    
    /*add the components to result*/
    result = addToResult(marked, nc);
    
    return result;
    
  }

	/*Select at most lengthSepList separators*/
	/*If the amount of bags is below lengthSepList, we take all the bags*/
	/*Else we take a random sample of length lengthSepList, with repetition*/
	public int[] selectSeps(int lengthSepList) {
		int[] sepInts;

		if (td.bags.length < lengthSepList) {
			lengthSepList = td.bags.length;
			sepInts = new int[lengthSepList];
			for (int i = 0; i < lengthSepList; i++) {
				sepInts[i] = i;
			}
		}
		else {
			sepInts = randomList(lengthSepList, td.neighbor.length - 1, Run.run);
		}
		
		return sepInts;
	}
	
	
	/*Creates a random list of integers of length `length`,
	 * in range between 0 and n, without duplicates */
	public int[] randomList(int length, int n, int seed) {
		Random random = new Random(seed);
		int[] list = new int[length];
		for (int i = 0; i < length; i++) {
			list[i] = -2; //This way the 0th bag has equal chance of being selected.			
			while (true) {
				int bag = random.nextInt(n);
				int index = indexOf(bag,list);
				if (index < 0) {
					list[i] = bag;
					break;
				}				
			}
		}		
		return list;
	}
	
	public int indexOf(int x, int a[]) {
    if (a == null) {
      return -1;
    }
    for (int i = 0; i < a.length; i++) {
      if (x == a[i]) {
        return i;
      }
    }
    return -1;
  }
	
	
	public long measureMemory() {
		if(runGC == true) 
			runtime.gc(); 
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	void printStats() {
		if (DFS) {
			System.out.println("   Memory for components DFS          = " + memoryComponentsDFS + " B.");
			System.out.println("   Time   for components DFS          = " + timeComponentsDFS/1000000 + " ms");
		}
		if (BFS) {
			System.out.println("   Memory for components BFS          = " + memoryComponentsBFS + " B.");
			System.out.println("   Time   for components BFS          = " + timeComponentsBFS/1000000 + " ms");
		}
		if (parallel) {
			System.out.println("   Memory for components DFS parallel = " + memoryComponentsParallel + " B.");
			System.out.println("   Time   for components DFS parallel = " + timeComponentsParallel/1000000 + " ms");
		}
		
	}
		
	
	
	void writeToFile(String fileName) {		
		File file = new File(fileName);		
   	
    try {
    	FileWriter ps = new FileWriter(file, true);

    	if (BFS) ps.write("\n" + memoryNeighbors + ", " + memorySeparators + ", " + countComps + ", "
      			+ memoryComponentsBFS + ", " + timeComponentsBFS/(1000));
    	
    	if (parallel) ps.write("\n" + memoryNeighbors + ", " + memorySeparators + ", " + countComps + ", "
    			+ memoryComponentsParallel + ", " + timeComponentsParallel/(1000));

      ps.close();
    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	
	
	
	public void getInts(int size, int factor) {
		int[] set = new int[size];
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		
	}
	
	
	public long measureMemoryForceGC() {
		
		WeakReference<long[]> garbage = new WeakReference <long[]> (new long[10000000] );
		garbage.get()[100] = 100;
		
		runtime.gc();
		
		if (garbage.get() != null) {
			System.out.println("GC failed...");
			System.exit(1);
		}
			
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	
	
	
	void testForMeasures() {
		
		boolean trace = false;
		long memory1;
		
		/*Create neighborhood again in the same way*/
		memory1 = measureMemoryForceGC();
		if (trace)
			System.out.println("\nmemory1               = " + memory1);
		T[] nb2 = (T[]) new Object[g.n];						
		for (int v = 0; v < g.n; v ++) {
			nb2[v] = cast(g.neighbor[v]);
		}		
		if (trace)
			System.out.println("used memory before GC = " + (runtime.totalMemory() - runtime.freeMemory()));
		long memoryExactCopy = measureMemoryForceGC() - memory1;
		if (trace)
			System.out.println("used memory after GC  = " + (runtime.totalMemory() - runtime.freeMemory()));
		
		
		/*And again: Create neighborhood again in the same way*/
		memory1 = measureMemoryForceGC();
		if (trace)
			System.out.println("memory1 = " + memory1);
		T[] nb3 = (T[]) new Object[g.n];			
		
		for (int v = 0; v < g.n; v ++) {
			nb3[v] = cast(g.neighbor[v]);
		}		
		long memoryExactCopy2 = measureMemoryForceGC() - memory1;
		
		
		/*Copy Built-in */
		memory1 = measureMemoryForceGC();	
		if (trace)
			System.out.println("memory1 = " + memory1);
		T[] nb4 = (T[]) new Object[g.n];					
		for (int v = 0; v < g.n; v ++) {
			nb4[v] = cloneBuiltIn(nb2[v]);
		}		
		long memoryCloneBuiltin = measureMemoryForceGC() - memory1;
		
		
		/*Copy manually */
		memory1 = measureMemoryForceGC();	
		if (trace)
			System.out.println("\nmemory1               = " + memory1);
		T[] nb5 = (T[]) new Object[g.n];					
		for (int v = 0; v < g.n; v ++) {
			nb5[v] = cloneManually(nb2[v]);
		}		
		if (trace)
			System.out.println("used memory before GC = " + (runtime.totalMemory() - runtime.freeMemory()));
		long memoryCloneManually = measureMemoryForceGC() - memory1;
		if (trace)			
			System.out.println("used memory after GC  = " + (runtime.totalMemory() - runtime.freeMemory()));
		
		
		
		String needed = nb2.toString() + nb3.toString() + nb4.toString() + nb5.toString();
		
		
		System.out.println("Cast 1         = " + memoryExactCopy);
		System.out.println("Cast 2         = " + memoryExactCopy2);
		System.out.println("Clone built-in = " + memoryCloneBuiltin);
		System.out.println("Clone manually = " + memoryCloneManually + "\n");
		

	}
	
	void testForMeasuresComps(T[] seps) {
		
			/*a indicates which algorithm to use
			 *a = 1 -> DFS
			 *a = 2 -> BFS
			 *a = 3 -> DFS_parallel*/
			int a = 3;
			
			boolean trace = false;
			long memory1;
			
			long memoryAlgorithm1 = 0;
			long memoryAlgorithm2 = 0;
			long memoryCloneBuiltin = 0;
			long memoryCloneManually = 0;
			
			
			for (int s = 0; s < seps.length; s++) {
					
				/*Construct the separated components*/				
				memory1 = measureMemoryForceGC();
				ArrayList<T> comps2 = new ArrayList<T>();
				if (a == 2) {
					comps2 = compsBFS(seps[s]);
				}
				if (a == 3) {
					comps2 = compsDFS_parallel(seps[s]);
				}
				memoryAlgorithm1 += measureMemoryForceGC() - memory1;
	
		
				/*And again: construct the separated components*/
				memory1 = measureMemoryForceGC();		
				ArrayList<T> comps3 = new ArrayList<T>(); 
				if (a == 2) {
					comps3 = compsBFS(seps[s]);
				}
				if (a == 3) {
					comps3 = compsDFS_parallel(seps[s]);
				}		
				memoryAlgorithm2 += measureMemoryForceGC() - memory1;
				
				
				
				/*Copy the components with Built-in functions*/
				memory1 = measureMemoryForceGC();				
				ArrayList<T> comps4 = new ArrayList<T> ();			
				for (int i = 0; i < comps2.size(); i++) {
					comps4.add(cloneBuiltIn(comps2.get(i)));
				}
				memoryCloneBuiltin += measureMemoryForceGC() - memory1;
				
				
				
				/*Copy the components manually, by iterating over the sets */
				memory1 = measureMemoryForceGC();				
				ArrayList<T> comps5 = new ArrayList<T> ();			
				for (int i = 0; i < comps2.size(); i++) {
					comps5.add(cloneManually(comps2.get(i)));
				}
				memoryCloneManually += measureMemoryForceGC() - memory1;
				
				/*This is needed to make sure that the components are garbage collected and measured properly*/
				String needed = comps2.toString() + comps3.toString() + comps4.toString() + comps5.toString();
				comps2 = null; comps3 = null; comps4 = null; comps5 = null; 
			}
				
			String alg;
			if(a == 1) { alg = "DFS";}
			else if (a == 2) {alg = "BFS";}
			else {alg = "DFS_parallel";		}
			
			
			System.out.println("Algorithm " + alg + "\n");
			System.out.println("Algorithm first time  = " + memoryAlgorithm1);
			System.out.println("Algorithm second time = " + memoryAlgorithm2);
			System.out.println("Clone built-in        = " + memoryCloneBuiltin);
			System.out.println("Clone manually        = " + memoryCloneManually + "\n");
				
	}
	
	
	/*Compare using different algorithm*/
	void compareTwoAlgorithms(T[] seps) {
		
		boolean BFS = true;
		boolean DFS_P = true;

		for (int s = 0; s < seps.length; s++) {
				
			/*Construct the separated components*/				
			ArrayList<T> comps2 = new ArrayList<T>();
			ArrayList<T> comps3 = new ArrayList<T>();
			if (BFS) {
				comps2 = compsBFS(seps[s]);
			}
			if (DFS_P) {
				comps3 = compsDFS_parallel(seps[s]);
			}


			AnalyseTwoAlgorithms (comps2, comps3);
		}
			

			
	}



}
	
