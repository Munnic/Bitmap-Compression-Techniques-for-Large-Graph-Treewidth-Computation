package tw.experiment1;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import tw.common.XBitSet;
import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;

import org.roaringbitmap.*;
import org.roaringbitmap.BitmapAnalyser;
import org.roaringbitmap.BitmapStatistics;

import com.googlecode.javaewah.EWAHCompressedBitmap;
import com.googlecode.javaewah.IntIteratorImpl;



/**Important note:
 * To do: For XBitSet we can have 2 algorithms to construct the components.*/
public class Exp_Roaring extends AbstractExperiment <RoaringBitmap> {
	
	Graph_NR g;
	TreeDecomposition_NR td;
	RoaringBitmap all;
	int containerSize;
	boolean useRun;
	
	int expectedAmountContainters;
	int acCountBefore;
	int bcCountBefore;
	int rcCountBefore;
	int acCountAfter ;
	int bcCountAfter ;
	int rcCountAfter ;
	int emptyCountBefore;
	int emptyCountAfter;
	
	int[] compsDistribution;
	int[] containerDistribution;
	int nFull;
	int nEmpty;

	
	Exp_Roaring (Graph_NR g, TreeDecomposition_NR td, int lengthSepList, int containerSize, boolean BFS, boolean parallel, boolean useRun){		
		super(g, td, lengthSepList, BFS, parallel);
		this.g = g;
		this.nb = new RoaringBitmap[g.n];
		this.containerSize = containerSize;
		this.useRun = useRun;
		
		acCountBefore = 0;
		bcCountBefore = 0;
		rcCountBefore = 0;
		acCountAfter  = 0;
		bcCountAfter  = 0;
		rcCountAfter  = 0;
		emptyCountBefore = 0;
		emptyCountAfter  = 0;
		
		expectedAmountContainters = (int) Math.ceil((float) g.n / Math.pow(2, containerSize));
		
		compsDistribution = new int[100];
		containerDistribution = new int[100];
		nFull = 0;
		nEmpty = 0;

		/*Update all constants*/
		RoaringBitmap.containerSize = containerSize;
		BitmapContainer.MAX_CAPACITY =  (int) Math.pow(2, containerSize);
		BitmapContainer.BLOCKSIZE = BitmapContainer.MAX_CAPACITY / 64;
		ArrayContainer.MAX_CONTAINER_SIZE = containerSize;
		ArrayContainer.DEFAULT_MAX_SIZE = (int) Math.pow(2, containerSize - 4);
		ArrayContainer.ARRAY_LAZY_LOWERBOUND = ArrayContainer.DEFAULT_MAX_SIZE/4;
		
		
		int[] rangeOfInts = new int[g.n];
		for (int i = 0; i < g.n; i++) {
			rangeOfInts[i] = i;
		}
		all = RoaringBitmap.bitmapOf(containerSize, rangeOfInts);
		
		if (Run.traceDataStructures) {
			if (useRun) 
				System.out.println("Data structure = RoaringRun " + containerSize);
			else
				System.out.println("Data structure = Roaring " + containerSize);
		}
	}
	
	
	/*Cast the from int[] to the data structure*/
	@Override
	RoaringBitmap cast(int[] set) {	
		//System.out.println("in cast = " + Arrays.toString(set));
		RoaringBitmap result = RoaringBitmap.bitmapOf(containerSize, set);
		//System.out.println(result);
		if (useRun)
			result.runOptimize();
		return result;
	}
	
	/*marks the separator with -1*/
	@Override
	int[] markSeparator(int[] marked, RoaringBitmap sep) {
		PeekableIntIterator iter = sep.getIntIterator();
		while (iter.hasNext()) {
			marked[iter.next()] = -1;
		}
		return marked;
	}
	
	/*mark an entire component with DFS*/
	@Override
	void mark(int v, int[] marked, int nc) {
    if (marked[v] != 0) return;
    marked[v] = nc;  
    PeekableIntIterator iter = nb[v].getIntIterator();
		while (iter.hasNext()) {
			int c = iter.next();
			mark(c, marked, nc);			
			
		}
		iter = null;
	}

	
	void markBFS(int v, int[] marked, int nc) {
		
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = nc; 
    queue.add(v);
    
    while (queue.size() != 0) { 
        // Dequeue a vertex from queue and print it 
        v = queue.poll();  
        
        PeekableIntIterator iter = nb[v].getIntIterator();
    		while (iter.hasNext()) {
    			int w = iter.next();		
    			
    			if ((marked[w] == 0)) { 
            marked[w] = nc; 
            queue.add(w);   
    			}
    		}
    }	
	}
	
	/*Add all marked components to a result*/
	@Override
	ArrayList<RoaringBitmap> addToResult(int[] mark, int nc) {
		ArrayList<RoaringBitmap> result = new ArrayList<RoaringBitmap>();		
    for (int c = 1; c <= nc; c++) {
      result.add(new RoaringBitmap());
    } 
    
    for (int v = 0; v < g.n; v++) {
      if (mark[v] >= 1) {
        result.get(mark[v] - 1).add(v);
      }
    } 
    
    if (Run.analyzeCompsDistribution) {
    	for (int i = 0; i < result.size(); i++) {
    		countComps(result.get(i));
    	}
    }
    
    
    if (useRun) {
	    for(int j = 0; j < result.size(); j++) {
	    	
	    	long acBefore = 0;
	    	long acAfter = 0;
	    	long bcBefore = 0;
	    	long bcAfter = 0;
	    	long rcBefore = 0;
	    	long rcAfter = 0;
	    	long emptyBefore = 0;
	    	long emptyAfter = 0;

	    	if (Run.analyseRunOpt) {
		    	BitmapStatistics stats = BitmapAnalyser.analyse(result.get(j));
		    	acCountBefore += stats.getArrayContainerCount();
		    	bcCountBefore += stats.getBitmapContainerCount();
		    	rcCountBefore += stats.getRunContainerCount();
		    	emptyCountBefore += expectedAmountContainters - (stats.getArrayContainerCount() + stats.getBitmapContainerCount() + stats.getRunContainerCount());
		    	
		    	acBefore = stats.getArrayContainerCount();
		    	bcBefore = stats.getBitmapContainerCount();
		    	rcBefore = stats.getRunContainerCount();
		    	emptyBefore = expectedAmountContainters - (stats.getArrayContainerCount() + stats.getBitmapContainerCount() + stats.getRunContainerCount());
	    	}
	    	
	    	result.get(j).runOptimize();
	    	
	    	if (Run.analyseRunOpt) {
	    		BitmapStatistics stats = BitmapAnalyser.analyse(result.get(j));
		    	acCountAfter += stats.getArrayContainerCount();
		    	bcCountAfter += stats.getBitmapContainerCount();
		    	rcCountAfter += stats.getRunContainerCount();
		    	emptyCountAfter += expectedAmountContainters - (stats.getArrayContainerCount() + stats.getBitmapContainerCount() + stats.getRunContainerCount());
		    	
		    	acAfter = stats.getArrayContainerCount();
		    	bcAfter = stats.getBitmapContainerCount();
		    	rcAfter = stats.getRunContainerCount();
		    	emptyAfter = expectedAmountContainters - (stats.getArrayContainerCount() + stats.getBitmapContainerCount() + stats.getRunContainerCount());
	    	}
	    	
	    	if (emptyBefore != emptyAfter) {
	    		System.out.println("\nnot equal!!");
	    		System.out.println("acBefore: " + acBefore + ", bcBefore: " + bcBefore + ", rcBefore: " + rcBefore + "emptyBefore: " + emptyBefore);
	    		System.out.println("acAfter: " + acAfter + ", bcAfter: " + bcAfter + ", rcAfter: " + rcAfter + "emptyAfter: " + emptyAfter);
	    		System.exit(1);
	    	}
	    }
    }  
	  return result;
	  
	}

	
	@Override
	ArrayList<RoaringBitmap> compsDFS_parallel(RoaringBitmap separator){
		
    ArrayList<RoaringBitmap> result = new ArrayList<RoaringBitmap>();
    RoaringBitmap rest = RoaringBitmap.andNot(all, separator);  
    
    for(int v = (int) rest.nextValue(0); v >= 0; v = (int) rest.nextValue(v+1)){		
    	RoaringBitmap c = (RoaringBitmap) nb[v].clone();
    	RoaringBitmap toBeScanned = RoaringBitmap.andNot(c, separator);
      c.add(v);
      while (!toBeScanned.isEmpty()) {
      	RoaringBitmap save = (RoaringBitmap) c.clone();      
      	
    		for(int w = (int) toBeScanned.nextValue(0); w >= 0; w = (int) toBeScanned.nextValue(w + 1)){   			
          c = RoaringBitmap.or(c, nb[w]);
        }    		
        toBeScanned = RoaringBitmap.andNot(c, save);
        toBeScanned = RoaringBitmap.andNot(toBeScanned, separator);        
      }
      result.add(RoaringBitmap.andNot(c, separator));
      rest = RoaringBitmap.andNot(rest, c);      
    }
    
    if (useRun) {
	    for(int j = 0; j < result.size(); j++) {
	    	result.get(j).runOptimize();
	    }
    }  
	  return result;
	}
	
	@Override
	ArrayList<RoaringBitmap> cloneArrayList(ArrayList<RoaringBitmap> list){
		ArrayList<RoaringBitmap>  newList = new ArrayList<RoaringBitmap>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((RoaringBitmap) list.get(i).clone());
		}		
		
		return newList;
	}
	
	@Override
	RoaringBitmap cloneBuiltIn(RoaringBitmap roar) {
		return roar.clone();
	}
	
	@Override
	RoaringBitmap cloneManually(RoaringBitmap roar) {
		RoaringBitmap result = new RoaringBitmap();		
		PeekableIntIterator iter = roar.getIntIterator();
		while (iter.hasNext()) {
			result.add(iter.next());
		}		
		iter = null;
		return result;
	}


	@Override
	long calculateMemory(RoaringBitmap vertexSet) {
		/*  
		 * general
		 * RoaringBitmap: 2 ints, 
		 * RoaringArray: Array of containers, short array of keys, 3 ints, 2 shorts, 1 long
		 * 
		 * containers
		 * Arraycontainer: 6 ints, short[] content (variable length), 1 long
		 * BitmapContainer: 2 ints, 1 long, 1 boolean,  long[] bitmap  (length MAX_CAPACITY/64)  
		 * RunContainer: 2 ints, 1 long, 1 boolean, short[] valueslength is the runlengthencoding
		 * 				e.g., 1, 10, 20,0, 31,2 would be a concise representation of 1, 2, ..., 11, 20,31, 32, 33
		*/
		return 0;
	}
	
	
	void AnalyseTwoAlgorithms(ArrayList<RoaringBitmap> comps2, ArrayList<RoaringBitmap> comps3){
		
		/*Same amount of components?*/
		boolean equalLength = comps2.size() == comps3.size();
		if (!equalLength) {
			System.out.println("comps are not equal length!");
			System.exit(1);
		}
		
		/*Each component is the same?*/
		for (int i = 0; i < comps2.size(); i++) {
			String s2 = comps2.get(i).toString();
			String s3 = comps3.get(i).toString();
			
			boolean equalStats23 = s2.equals(s3);
			if (!equalStats23) {
				System.out.println("Stats 2 and 3 are not equal");
				System.out.println(comps2.get(i).toString());
				System.out.println(comps3.get(i).toString());
				System.exit(1);
			}

			/*
			System.out.println("2 and 3 is equal = " + equalStats23);
			System.out.println("2 and 4 is equal = " + equalStats23);
			System.out.println("2 and 5 is equal = " + equalStats23);
			*/
		
		}
	}
		
		
	void AnalyseOne(ArrayList<RoaringBitmap> comps2){
	
		//getContainerPointer() does not seem to work properly!!!!!!
		
		for (int i = 0; i < comps2.size(); i++) {
			RoaringBitmap roar = comps2.get(i);
	    ContainerPointer cp = roar.getContainerPointer();
	    while (cp.getContainer() != null) {
	    		    	
	      if (cp.isBitmapContainer()) {
	      	BitmapContainer cont = (BitmapContainer) cp.getContainer();
	      	if (cont.bitmap.length * 64 > BitmapContainer.MAX_CAPACITY) {
	      		System.out.println("BitmapContainer to large");
	      		System.exit(1);
	      	}
	      } 
	      else if (cp.isRunContainer()) {
	      	RunContainer cont = (RunContainer) cp.getContainer();
	      	short[] array = cont.valueslength;      	
	      	int max = array[array.length - 2] + array[array.length - 1];
	      	
	      	if (max > BitmapContainer.MAX_CAPACITY) {
		      	System.out.println("Runcontainer = " + Arrays.toString(cont.valueslength));
		      	System.out.println("adding last two digits is larger than max size, namely " + max);
		      	System.exit(1);
	      	}
	      } 
	      else {
	      	ArrayContainer cont = (ArrayContainer) cp.getContainer();
	      	
	      	/*More than ArrayContainer.DEFAULT_MAX_SIZE elements is not allowed*/
	      	if (cont.content.length > ArrayContainer.DEFAULT_MAX_SIZE) {
	      		System.out.println("ArrayContainer to large: " + cont.content.length);
	      		System.exit(1);
	      	}
	      	
	      	/*the largest value can't be larger than BitmapContainer.MAX_CAPACITY*/
	      	int[] array = cont.toArray();
	      	int largestValue = array[array.length - 1];
	      	if (largestValue > BitmapContainer.MAX_CAPACITY) {
	      		System.out.println("largest value to large. value = " + largestValue);
	      		System.exit(1);
	      	}
	      }
	      cp.advance();
	    }			
		}
	}
	
	void writeAnalyseRunOpt(String fileName) {		
		File file = new File(fileName);		
		if (Run.startNewFile) file.delete();
   	
    try {
    	FileWriter ps = new FileWriter(file, true);
    	
    	if (Run.analyseRunOpt) {
  			ps.write("acCountBefore bcCountBefore rcCountBefore emptyCountBefore acCountAfter bcCountAfter rcCountAfter emptyCountAfter g.n g.edges");
				ps.write("\n" + g.n + ", " + Run.edges);
    		ps.write("\n" + acCountBefore + ", " + bcCountBefore + ", " + rcCountBefore + ", " +  emptyCountBefore + ", " + acCountAfter + ", " + bcCountAfter + ", " + rcCountAfter + ", " + emptyCountAfter);
    	}

      ps.close();
    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
	void countComps(RoaringBitmap roar) {
		
		int containerCounter = 0;
		
		compsDistribution[100 * roar.getCardinality() / g.n]++;
		
    ContainerPointer cp = roar.getContainerPointer();
    while (cp.getContainer() != null) {    	
    	int card = cp.getCardinality();

    	if (card == BitmapContainer.MAX_CAPACITY) {
    		containerDistribution[99]++;
    		nFull++;
    	}
    	else
    		containerDistribution[100 * card / BitmapContainer.MAX_CAPACITY]++;
    	
      cp.advance();
      containerCounter++;
    }	
    
    int emptyConts = expectedAmountContainters - containerCounter;
    nEmpty += emptyConts;
    containerDistribution[0] += emptyConts;

	}
	
	void writeCompsDistribution(String fileName) {		
		
		File file = new File(fileName);		
		if (Run.startNewFile) file.delete();
		
   	
    try {
    	FileWriter ps = new FileWriter(file, true);

    	ps.write("compsDistribution containerDistribution nEmpty nFull g.n g.edges");
    	ps.write("\n" + Arrays.toString(compsDistribution));
    	ps.write("\n" + Arrays.toString(containerDistribution));
    	ps.write("\n" + nEmpty + ", " + nFull);
			ps.write("\n" + g.n + ", " + Run.edges);

      ps.close();
    } catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	
}








