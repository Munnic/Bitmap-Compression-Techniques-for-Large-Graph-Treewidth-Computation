package tw.experiment1;

import java.lang.instrument.Instrumentation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;

import org.roaringbitmap.PeekableIntIterator;
import org.roaringbitmap.RoaringBitmap;

import tw.common.XBitSet;
import tw.constructbenchmark.Graph_NR;
import tw.constructbenchmark.TreeDecomposition_NR;



public class Exp_Ints extends AbstractExperiment <int[]> {
	
	Graph_NR g;
	TreeDecomposition_NR td;
	static int[] all;
	
	Exp_Ints (Graph_NR g, TreeDecomposition_NR td, int lengthSepList, boolean BFS, boolean parallel){		
		super(g, td, lengthSepList, BFS, parallel);
		this.g = g;
		this.nb = new int[g.n][];
		
		all = new int[g.n];
		for (int i = 0; i < g.n; i++) {
			all[i] = i;
		}
		
		if (Run.traceDataStructures) {
			System.out.println("Data structure = int[]");
		}
	}
	
	
	/*Cast the from int[] to the data structure*/
	@Override
	int[] cast(int[] set) {		
		int[] result = set.clone();
		return result;
	}
	
	/*marks the separator with -1*/
	@Override
	int[] markSeparator(int[] marked, int[] sep) {
		for(int i = 0; i < sep.length; i++) {
			marked[sep[i]] = -1;
		}
		return marked;
	}
	
	/*mark an entire component with DFS*/
	@Override
	void mark(int v, int[] marked, int nc) {
		
    if (marked[v] != 0) return;
    marked[v] = nc; 
    
    
    if (nc > AbstractExperiment.compSizes.length - 1)
    	AbstractExperiment.compSizes = doubleLength(AbstractExperiment.compSizes);   
    AbstractExperiment.compSizes[nc]++;    
    
    for (int w = 0; w < nb[v].length; w++) {
    	mark(nb[v][w], marked, nc);
    }
	}
	
	void markBFS(int v, int[] marked, int nc) {
				
		LinkedList<Integer> queue = new LinkedList<Integer>();
		marked[v] = nc; 
			
		if (nc > AbstractExperiment.compSizes.length - 1)
    	AbstractExperiment.compSizes = doubleLength(AbstractExperiment.compSizes);   
    AbstractExperiment.compSizes[nc]++; 
		
    queue.add(v);
      
    while (queue.size() != 0) { 
        // Dequeue a vertex from queue and print it 
        v = queue.poll();  
        
        for (int i = 0; i < nb[v].length; i++) {
        	int w = nb[v][i];	
    			
    			if ((marked[w] == 0)) { 
            marked[w] = nc; 
            queue.add(w);   

            AbstractExperiment.compSizes[nc]++;
    			}
    		}
    }	
	}
	
	/*Add all marked components to a result*/
	@Override
	ArrayList<int[]> addToResult(int[] marked, int nc) {
		ArrayList<int[]> result = new ArrayList<int[]>();

		/*create new arrays for components*/
    for (int c = 1; c <= nc; c++) {
      result.add(new int[AbstractExperiment.compSizes[c]]);
    }

    /*add marked vertex to corresponding array*/
    int[] cComps = new int[nc + 1];
    
    for (int v = 0; v < g.n; v++) {
    	int markV = marked[v];

      if (markV >= 1) {
        result.get(markV - 1)[cComps[markV]] = v;
        cComps[markV]++;
      }
    }
    
    return result;
	}
	
	int[] doubleLength(int[] array){
		int[] newArray = Arrays.copyOf(array, (array.length * 2));
		return newArray;
	}
	
	@Override
	ArrayList<int[]> compsDFS_parallel(int[] separator){
		
		ArrayList<int[]> result = new ArrayList<int[]>();		
		int[] rest = Graph_NR.subtract(separator, all);  
		
		//System.out.println("separator = " + Arrays.toString(separator));
		//System.out.println("rest = " + Arrays.toString(rest));
		
		while (rest.length != 0) {
			int v = rest[0];
	
    	int[] c = nb[v].clone();
    	int[] toBeScanned = Graph_NR.subtract(separator, c);
    	
    	//System.out.println("toBeScanned1 = " + Arrays.toString(toBeScanned));
  	
      c = Graph_NR.add(c, v);
      
      while (toBeScanned.length > 0) {
      	int[] save = c.clone();      
      	
      	for (int j = 0; j < toBeScanned.length; j++) {
      		c = Graph_NR.getUnion(c, nb[toBeScanned[j]]);
      	}
    		
        toBeScanned = Graph_NR.subtract(save, c);
        toBeScanned = Graph_NR.subtract(separator, toBeScanned); 
        
        //System.out.println("toBeScanned2 = " + Arrays.toString(toBeScanned));
        
      }
      result.add(Graph_NR.subtract(separator, c));
      rest = Graph_NR.subtract(c, rest);   
      //System.out.println("rest = " + Arrays.toString(rest));
    }

	  return result;
	}
	
	ArrayList<int[]> cloneArrayList(ArrayList<int[]> list){
		ArrayList<int[]>  newList = new ArrayList<int[]>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((int[]) list.get(i).clone());
		}		
		return newList;
	}


	@Override
	long calculateMemory(int[] vertexSet) {
		//an integer is 4 bytes.
		//the array itself has to be stored, which is 12 bytes, 8 bytes header and 4 bytes array length
		
		return vertexSet.length * 4 + 12;

	}
	
	@Override
	int[] cloneBuiltIn(int[] set) {
		return set.clone();
	}
	
	@Override
	int[] cloneManually(int[] set) {
		int[] result = new int[set.length];		

		for (int i = 0; i < set.length; i ++) {
			result[i] = set[i];
		}	
	
		return result;
	}


	@Override
	void AnalyseTwoAlgorithms(ArrayList<int[]> comps2, ArrayList<int[]> comps3) {
			
			/*Same amount of components?*/
			boolean equalLength = comps2.size() == comps3.size();
			if (!equalLength) {
				System.out.println("\ncomps are not equal length!");
				
				System.out.println("comps2:");
				for (int i = 0; i < comps2.size(); i++) {
					System.out.println(Arrays.toString(comps2.get(i)));
				}
				System.out.println("comps3:");
				for (int i = 0; i < comps3.size(); i++) {
					System.out.println(Arrays.toString(comps3.get(i)));
				}
				
				System.exit(1);
			}
			
			
			
			/*Each component is the same?*/
			for (int i = 0; i < comps2.size(); i++) {
				
				if (comps2.get(i) == all) {
					System.out.println("comps2 equals all");
					System.exit(1);
				}
				if (comps3.get(i) == all) {
					System.out.println("comps3 equals all");
					System.exit(1);
				}
				
				boolean equalStats23 = Arrays.equals(comps2.get(i), comps3.get(i));
				if (!equalStats23) {
					System.out.println("\nStats 2 and 3 are not equal");
					System.out.println("Comps2: " + Arrays.toString(comps2.get(i)));
					System.out.println("Comps3: " + Arrays.toString(comps3.get(i)));

					System.exit(1);
				}

			
			}
		}
	
}








