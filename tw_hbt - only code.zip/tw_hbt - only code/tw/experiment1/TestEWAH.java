

package tw.experiment1;

import java.util.ArrayList;
import java.util.Random;

import org.roaringbitmap.RoaringBitmap;

import com.googlecode.javaewah.*;

import tw.common.XBitSet;

public class TestEWAH {

	public static void main(String args[]) {
		

				
		//Is clone correct?
		/*for (int i = 1000; i <= 1000000; i*= 10) {
			int[] set = getInts(i, 2);
			long memory1 = measureMemory();
			ArrayList<EWAHCompressedBitmap> list1 = new ArrayList<EWAHCompressedBitmap>();
			list1.add(EWAHCompressedBitmap.bitmapOf(set));
			long memoryOriginal = measureMemory() - memory1;
			
			memory1 = measureMemory();
			ArrayList<EWAHCompressedBitmap> list2 = cloneArrayList(list1);
			long memoryCopy = measureMemory() - memory1;
			
			System.out.println("\nmemoryOriginal = " + memoryOriginal + ", memoryCopy = " + memoryCopy + ", difference = " + (memoryOriginal - memoryCopy));
		}
		
		for (int i = 1000; i <= 1000000; i*= 10) {
			int[] set = getInts(i, 2);
		
		for (int v = result2.getFirstSetBit(); v >= 0; v = result2.getFirstSetBit()) {
			System.out.println(v);
			result2.set(v, false);
		}
	
		
		//System.out.println(result2);
		
		//EWAHIterator it = new EWAHIterator.getEWAHIterator(result2);
		//EWAHIterator it = result2.getEWAHIterator();
				
		
		long time1 = System.currentTimeMillis();
		IntIteratorImpl iter = new IntIteratorImpl(result2.getEWAHIterator());
		while(iter.hasNext()) {
			int x = iter.next();
		}
		long twoStep = System.currentTimeMillis() - time1;
		
		System.out.println("Time twoStep = ");
		
		long time2 = System.currentTimeMillis();
		IntIterator it = result2.intIterator();
		while(it.hasNext()) {
			int x = it.next();
		}
		long oneStep = System.currentTimeMillis() - time2;
		
		long time0 = System.currentTimeMillis();
		for (int v = result2.getFirstSetBit(); v >= 0; v = result2.getFirstSetBit()) {
			result2.set(v, false);
			int x = v;
		}
		long firstBit = System.currentTimeMillis() - time0;
		
		
		System.out.println("Time twoStep = " + twoStep + ", time oneStep = " + oneStep + ", time firstSetBit = " + firstBit);
		*/
	}
	
	
	public static int[] getInts(int size, int factor) {
		int[] set = new int[size];
		Random random = new Random();
		for (int i = 0; i < size; i++) {
			set[i] = random.nextInt(factor * size);
		}
		return set;
		
	}
	
	public static long measureMemory() {
		Runtime runtime = Runtime.getRuntime();
		runtime.gc(); 
		long memory = runtime.totalMemory() - runtime.freeMemory();
		return memory;
	}
	
	static ArrayList<EWAHCompressedBitmap> cloneArrayList(ArrayList<EWAHCompressedBitmap> list){
		ArrayList<EWAHCompressedBitmap>  newList = new ArrayList<EWAHCompressedBitmap>();
		for (int i = 0; i < list.size(); i++) {
			newList.add((EWAHCompressedBitmap) list.get(i).clone());
		}		
		return newList;
	}
	
}

