package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class TestBenchmark {
	
	
  public static void main(String args[]) {

  	String path = "/testmap";
  	String nameGraph = "test.txt";
          
  	File fileGraph = new File(nameGraph);
    try {
    	PrintStream ps = new PrintStream(new FileOutputStream(fileGraph));
      ps.println("Hello World!");
      ps.close();
      } catch (FileNotFoundException e) {
      	e.printStackTrace();
      }

  }            	

}

