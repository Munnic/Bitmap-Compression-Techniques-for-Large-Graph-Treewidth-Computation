/*
 * Copyright (c) 2016, 2019 Hisao Tamaki
 */
package tw.constructbenchmark;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

import tw.common.XBitSet;

/**
 * This class provides a representation of undirected simple graphs.
 * The vertices are identified by non-negative integers
 * smaller than {@code n} where {@code n} is the number
 * of vertices of the graph.
 * The degree (the number of adjacent vertices) of each vertex
 * is stored in an array {@code degree} indexed by the vertex number.
 * The adjacency lists of each vertex
 * is also referenced from an array {@code neighbor} indexed by
 * the vertex number. These arrays as well as the int variable {@code n}
 * are public to allow easy access to the graph content.
 * Reading from and writing to files as well as some basic
 * graph algorithms, such as decomposition into connected components,
 * are provided.
 * 
 * {@code isInbound} method added 12 March, 2019
 * {@code getComponent} method added 22 October, 2019
 * major refactoring November 2019:
 *   some methods are renamed to be more consistent with common terminology
 *   several methods are moved from Util class
 * 
 * @author  Hisao Tamaki
 */
public class Graph_NR {
  /**
   * number of vertices
   */
  public int n;

  /**
   * array of vertex degrees
   */
  public int[] degree;

  /**
   * array of adjacency lists each represented by an integer array
   */
  public int[][] neighbor;


  /**
   * the set of all vertices, represented as an all-one
   * bit vector
   */
  public XBitSet all;

  /*
   * variables used in the DFS aglgorithms for
   * connected components and
   * biconnected components.
   */
  private int nc;
  private int mark[];
  private int dfn[];
  private int low[];
  private int dfCount;
  private XBitSet articulationSet;
  
  static boolean visited[];
  static int[][] minSeps;
  static int counter = 0;
  static XBitSet deleteElements;
  static int nDeleted = 0;
  boolean doing2 = false;

  /**
   * Construct a graph with the specified number of
   * vertices and no edges.  Edges will be added by
   * the {@code addEdge} method
   * @param n the number of vertices
   */
  public Graph_NR(int n) {
    this.n = n;
    this.degree = new int[n];
    this.neighbor = new int[n][];
    this.all = new XBitSet(n);
    for (int i = 0; i < n; i++) {
      all.set(i);
    }
  }

  /**
   * Add an edge between two specified vertices.
   * This is done by adding each vertex to the adjacent list
   * of the other.
   * No effect if the specified edge is already present.
   * @param u vertex (one end of the edge)
   * @param v vertex (the other end of the edge)
   */
  public void addEdge(int u, int v) {
    addToNeighbors(u, v);
    addToNeighbors(v, u);
  }

  /**
   * Add vertex {@code v} to the adjacency list of {@code u}
   * @param u vertex number
   * @param v vertex number
   */
  private void addToNeighbors(int u, int v) {
    if (indexOf(v, neighbor[u]) >= 0) {
      return;
    }
    
    degree[u]++;
    if (neighbor[u] == null) {
      neighbor[u] = new int[] {v};
    }
    else {
      neighbor[u] = Arrays.copyOf(neighbor[u], degree[u]);
      neighbor[u][degree[u] - 1] = v;
    }
  }

  /**
   * Returns the number of edges of this graph
   * @return the number of edges
   */
  public int numberOfEdges() {
    int count = 0;
    for (int i = 0; i < n; i++) {
      count += degree[i];
    }
    return count / 2;
  }

  /**
   * Create a conversion table for the given vertex set that maps
   * the vertex of the target graph into the local index of the vertex
   * in the given set of vertices.
   * @param vertices a vertex set of the target graph
   * @return an {@code int} array {@code conv} such that if {@code v} is in 
   * {@code vertices} and has {@code k} smaller vertices 
   * in {@code vertices} then {@code conv[v]} = {@code k}; 
   * if {@code v} is not in given vertex set, {@code conv[v]} = -1;  
   */
  public int[] conversion(XBitSet vertices) {
    int[] conv = new int[n];
    int k = 0;
    for (int v = 0; v < n; v++) {
      if (vertices.get(v)) {
        conv[v] = k++;
      }
      else {
        conv[v] = -1;
      }
    }
    return conv;
  }
  
  /**
   * Create the inversion table for the given conversion table
   * @param conv an {@code int} array of length {@code n} 
   * where {@code n} is the number of vertices of the target graph
   * @param k a positive integer less than or equal to {@code n}: 
   * assume that {@code -1 <= conv[i] < k} holds for each {@code i} 
   * with {@code 0 <= i < n} and, for each {@code j} with {@code 0 <= j < k}, 
   * the index {@code i} such that 
   * {@code conv[i] = j} is unique.
   * @return an {@code int} array {@code inv} of length {@code k} 
   * such that {@code conv[inv[j]] = j} for each {@code j} with {@code 0 <= j < k}. 
   */
  public int[] inversion(int[] conv, int k) {
    int[] inv = new int[k];
    for (int v = 0; v < n; v++) {
      if (conv[v] >= 0) {
        inv[conv[v]] = v;
      }
    }
    return inv;
  }
  /**
   * Inherit edges of the given graph into this graph,
   * according to the conversion tables for vertex numbers.
   * @param g graph
   * @param conv vertex conversion table from the given graph to
   * this graph: if {@code v} is a vertex of graph {@code g}, then
   * {@code conv[v]} is the corresponding vertex in this graph;
   * {@code conv[v] = -1} if {@code v} does not have a corresponding vertex
   * in this graph
   * @param inv vertex conversion table from this graph to
   * the argument graph: if {@code v} is a vertex of this graph,
   * then {@code inv[v]} is the corresponding vertex in graph {@code g};
   * it is assumed that {@code v} always have a corresponding vertex in
   * graph g.
   *
   */
  public void inheritEdges(Graph_NR g, int conv[], int inv[]) {
    for (int v = 0; v < n; v++) {
      int x = inv[v];
      for (int i = 0; i < g.degree[x]; i++) {
        int y = g.neighbor[x][i];
        int u = conv[y];
        if (u >= 0) {
            addEdge(u,  v);
        }
      }
    }
  }

  /**
   * Read a graph from the specified file in {@code dgf} format and
   * return the resulting {@code Graph} object.
   * @param path the path of the directory containing the file
   * @param name the file name without the extension ".dgf"
   * @return the resulting {@code Graph} object; null if the reading fails
   */
  public static Graph_NR readGraphDgf(String path, String name) {
    File file = new File(path + "/" + name + ".dgf");
    return readGraphDgf(file);
  }

  /**
   * Read a graph from the specified file in {@code dgf} format and
   * return the resulting {@code Graph} object.
   * @param file file from which to read
   * @return the resulting {@code Graph} object; null if the reading fails
   */
  public static Graph_NR readGraphDgf(File file) {

    try {
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = br.readLine();
      while (line.startsWith("c")) {
        line = br.readLine();
      }
      if (line.startsWith("p")) {
        String s[] = line.split(" ");
        int n = Integer.parseInt(s[2]);
        // m is twice the number of edges explicitly listed
        int m = Integer.parseInt(s[3]);
        Graph_NR g = new Graph_NR(n);

        for (int i = 0; i < m; i++) {
          line = br.readLine();
          while (!line.startsWith("e")) {
            line = br.readLine();
          }
          s = line.split(" ");
          int u = Integer.parseInt(s[1]) - 1;
          int v = Integer.parseInt(s[2]) - 1;
          g.addEdge(u, v);
        }
        return g;
      }
      else {
        throw new RuntimeException("!!No problem descrioption");
      }

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Read a graph from the specified file in {@code col} format and
   * return the resulting {@code Graph} object.
   * @param path the path of the directory containing the file
   * @param name the file name without the extension ".col"
   * @return the resulting {@code Graph} object; null if the reading fails
   */
  public static Graph_NR readGraphCol(String path, String name) {
    File file = new File(path + "/" + name + ".col");
    try {
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = br.readLine();
      while (line.startsWith("c")) {
        line = br.readLine();
      }
      if (line.startsWith("p")) {
        String s[] = line.split(" ");
        int n = Integer.parseInt(s[2]);
        // m is twice the number of edges in this format
        int m = Integer.parseInt(s[3]);
        Graph_NR g = new Graph_NR(n);

        for (int i = 0; i < m; i++) {
          line = br.readLine();
          while (line != null && !line.startsWith("e")) {
            line = br.readLine();
          }
          if (line == null) {
            break;
          }
          s = line.split(" ");
          int u = Integer.parseInt(s[1]);
          int v = Integer.parseInt(s[2]);
          g.addEdge(u - 1, v - 1);
        }
        return g;
      }
      else {
        throw new RuntimeException("!!No problem descrioption");
      }

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * Read a graph from the specified file in {@code gr} format and
   * return the resulting {@code Graph} object.
   * The vertex numbers 1~n in the gr file format are
   * converted to 0~n-1 in the internal representation.
   * @param file graph file in {@code gr} format
   * @return the resulting {@code Graph} object; null if the reading fails
   */
  public static Graph_NR readGraph(String path, String name) {
    File file = new File(path + "/" + name + ".gr");
    return readGraph(file);
  }

  /**
   * Read a graph from the specified file in {@code gr} format and
   * return the resulting {@code Graph} object.
   * The vertex numbers 1~n in the gr file format are
   * converted to 0~n-1 in the internal representation.
   * @param path the path of the directory containing the file
   * @param name the file name without the extension ".gr"
   * @return the resulting {@code Graph} object; null if the reading fails
   */
  public static Graph_NR readGraph(File file) {
    try {
      BufferedReader br = new BufferedReader(new FileReader(file));
      String line = br.readLine();
      while (line.startsWith("c")) {
        line = br.readLine();
      }
      if (line.startsWith("p")) {
        String s[] = line.split(" ");
        if (!s[1].equals("tw")) {
          throw new RuntimeException("!!Not treewidth instance");
        }
        int n = Integer.parseInt(s[2]);
        int m = Integer.parseInt(s[3]);
        Graph_NR g = new Graph_NR(n);
        for (int i = 0; i < m; i++) {
          line = br.readLine();
          while (line.startsWith("c")) {
            line = br.readLine();
          }
          s = line.split(" ");
          int u = Integer.parseInt(s[0]);
          int v = Integer.parseInt(s[1]);
          g.addEdge(u - 1, v - 1);
        }
        return g;
      }
      else {
        throw new RuntimeException("!!No problem description");
      }

    } catch (FileNotFoundException e) {
      e.printStackTrace();
    } catch (IOException e) {
      e.printStackTrace();
    }
    return null;
  }

  /**
   * finds the first occurrence of the
   * given integer in the given int array
   * @param x value to be searched
   * @param a array
   * @return the smallest {@code i} such that
   * {@code a[i]} = {@code x};
   * -1 if no such {@code i} exists
   */
  public static int indexOf(int x, int a[]) {
    if (a == null) {
      return -1;
    }
    for (int i = 0; i < a.length; i++) {
      if (x == a[i]) {
        return i;
      }
    }
    return -1;
  }

  /**
   * returns true if two vertices are adjacent to each other
   * in this target graph
   * @param u a vertex
   * @param v another vertex
   * @return {@code true} if {@code u} is adjcent to {@code v};
   * {@code false} otherwise
   */
  public boolean areAdjacent(int u, int v) {
    return indexOf(v, neighbor[u]) >= 0;
  }

  /**
   * returns the minimum degree, the smallest d such that
   * there is some vertex {@code v} with {@code degree[v]} = d,
   * of this target graph
   * @return the minimum degree
   */
  public int minDegree() {
    if (n == 0) {
      return 0;
    }
    int min = degree[0];
    for (int v = 0; v < n; v++) {
      if (degree[v] < min) min = degree[v];
    }
    return min;
  }
  
  public int maxDegree() {
	    if (n == 0) {
	      return 0;
	    }
	    int max = degree[0];
	    for (int v = 0; v < n; v++) {
	      if (degree[v] > max) max = degree[v];
	    }
	    return max;
	  }

  /**
   * Computes the neighbor set for a given set of vertices
   * @param set set of vertices
   * @return an {@code XBitSet} representing the neighbor set of
   * the given vertex set
   */

  /**public XBitSet neighborSet(XBitSet set) {
    XBitSet result = new XBitSet(n);
    for (int v = set.nextSetBit(0); v >= 0; v = set.nextSetBit(v + 1)) {
      result.or(neighborSet[v]);
    }
    result.andNot(set);
    return result;
  }*/

  /**
   * Computes the closed neighbor set for a given set of vertices
   * @param set set of vertices
   * @return an {@code XBitSet} reprenting the closed neighbor set of
   * the given vertex set
   */
  /**public XBitSet closedNeighborSet(XBitSet set) {
    XBitSet result = (XBitSet) set.clone();
    for (int v = set.nextSetBit(0); v >= 0;
        v = set.nextSetBit(v + 1)) {
      result.or(neighborSet[v]);
    }
    return result;
  }*/

  /**
   * Compute connected components of this target graph after
   * the removal of the vertices in the given separator,
   * using Depth-First Search
   * @param separator set of vertices to be removed
   * @return the arrayList of connected components,
   * the vertex set of each component represented by a {@code XBitSet}
   */
  public ArrayList<XBitSet> getComponentsDFS(XBitSet separator) {
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    mark = new int[n];
    for (int v = 0; v < n; v++) {
      if (separator.get(v)) {
        mark[v] = -1;
      }
    }

    nc = 0;

    for (int v = 0; v < n; v++) {
      if (mark[v] == 0) {
        nc++;
        markFrom(v);
      }
    }

    for (int c = 1; c <= nc; c++) {
      result.add(new XBitSet(n));
    }

    for (int v = 0; v < n; v++) {
      int c = mark[v];
      if (c >= 1) {
        result.get(c - 1).set(v);
      }
    }
    return result;
  }

  /**
   * Recursive method for depth-first search
   * vertices reachable from the given vertex,
   * passing through only unmarked vertices (vertices
   * with the mark[] value being 0 or -1),
   * are marked by the value of {@code nc} which
   * is a positive integer
   * @param v vertex to be visited
   */
  private void markFrom(int v) {
    if (mark[v] != 0) return;
    mark[v] = nc;
    for (int i = 0; i < degree[v]; i++) {
      int w = neighbor[v][i];
      markFrom(w);
    }
  }

  /**
   * Compute the connected component of this target graph after
   * the removal of the vertices in the given separator,
   * to which the given vertex belongs
   * Renamed from {@code getComponent}: Nov 18, 2019 by Hisao Tamaki
   * @param separator set of vertices to be removed
   * @v vertex for which the component belongs to
   * @return the connected component represented by a {@code XBitSet}
   */
  /**public XBitSet separatedComponent(XBitSet separator, int v) {
    assert !separator.get(v);

    XBitSet c = (XBitSet) neighborSet[v].clone();
    XBitSet toBeScanned = c.subtract(separator);
    c.set(v);
    while (!toBeScanned.isEmpty()) {
      XBitSet save = (XBitSet) c.clone();
      for (int w = toBeScanned.nextSetBit(0); w >= 0;
          w = toBeScanned.nextSetBit(w + 1)) {
        c.or(neighborSet[w]);
      }
      toBeScanned = c.subtract(save);
      toBeScanned.andNot(separator);
    }
    return c.subtract(separator);
  }*/ 
  
 

  /**
   * Compute connected components of the subgraph of this target
   * induced by the given vertex set
   * by means of iterated bit operations
   * Introduced: Nov 18, 2019 by Hisao Tamaki
   * @param vs the vertex set
   * @return the arrayList of connected components,
   * the vertex set of each component represented by a {@code XBitSet}
   */
  /**public ArrayList<XBitSet> componentsOf(XBitSet vs) {
    ArrayList<XBitSet> result = new ArrayList<>();

    for (int v = vs.nextSetBit(0); v >= 0;
        v = vs.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) neighborSet[v].clone();
      XBitSet toBeScanned = c.intersectWith(vs);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
            w = toBeScanned.nextSetBit(w + 1)) {
          c.or(neighborSet[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.and(vs);
      }
      result.add(c.intersectWith(vs));
      vs.andNot(c);
    }

    return result;
  }*/

  /**
   * Compute connected components of this target graph after
   * the removal of the vertices in the given separator,
   * by means of iterated bit operations
   * Renamed from {@code getComponents}: Nov 18, 2019 by Hisao Tamaki
   * @param separator set of vertices to be removed
   * @return the arrayList of connected components,
   * the vertex set of each component represented by a {@code XBitSet}
   */
  /**public ArrayList<XBitSet> separatedComponents(XBitSet separator) {
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    XBitSet rest = all.subtract(separator);
    for (int v = rest.nextSetBit(0); v >= 0;
        v = rest.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) neighborSet[v].clone();
      XBitSet toBeScanned = c.subtract(separator);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
            w = toBeScanned.nextSetBit(w + 1)) {
          c.or(neighborSet[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
      }
      result.add(c.subtract(separator));
      rest.andNot(c);
    }
    return result;
  }*/
  
  public ArrayList<XBitSet> separatedComponents(int[] bag) {
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    XBitSet separator = new XBitSet(n);
    for (int i = 0; i < bag.length; i++) {
    	separator.set(bag[i]);
    }    
    XBitSet rest = all.subtract(separator);
    for (int v = rest.nextSetBit(0); v >= 0; v = rest.nextSetBit(v + 1)) {    	
    	XBitSet c = new XBitSet(n);
    	for(int i = 0; i < neighbor[v].length; i++) {
    		c.set(neighbor[v][i]);
    	}    			
    	
      XBitSet toBeScanned = c.subtract(separator);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0; w = toBeScanned.nextSetBit(w + 1)) {
        	XBitSet neighborSetW = new XBitSet(n);
        	for(int i = 0; i < neighbor[w].length; i++) {
        		neighborSetW.set(neighbor[w][i]);
        	} 
          c.or(neighborSetW);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
      }
      result.add(c.subtract(separator));
      rest.andNot(c);
    }
    return result;
  }
  
  public static int[][] toIntArray(ArrayList<XBitSet> input) {
  	int[][] result = new int[input.size()][];
  	for(int i = 0; i < input.size(); i++) {
  		result[i] = new int[input.get(i).cardinality()];
  		int j = 0;
  		for(int w = input.get(i).nextSetBit(0); w >= 0; w = input.get(i).nextSetBit(w + 1)) {
    		result[i][j] = w;
    		j++;
  		}
  	}
  	return result;
  }
  
  public int[] neighborSet(int[] set) {
  	int[] result = new int[] {};
  	for (int i = 0; i < set.length; i++) {
  		result = getUnion(result, neighbor[set[i]]);
  	}
  	result = subtract(set, result);
  	return result;
  }
  
  /*Gives the neighborhood of each separated components of a bag, which are always minimal separators.*/
  public int[][] getMinSeps(int[] bag) {
  	ArrayList<XBitSet> xBitComponents = separatedComponents(bag);
  	int[][] components = toIntArray(xBitComponents);  	
  	int[][] minSeps = new int[components.length][];
  	for (int comp = 0; comp < components.length; comp++) {
      minSeps[comp] = neighborSet(components[comp]); 
  	}
  	return minSeps;
  }

  
  public int[][] getMinSeps2(int[] bag){
  	int[] nbsBag = neighborSet(bag);
  	minSeps = new int[nbsBag.length][];  	
  	visited = new boolean [nbsBag.length]; 
  	
  	//System.out.println(Arrays.toString(bag));
  	//System.out.println(Arrays.toString(visited));
  	
  	int nSeps = 0; 	
  	for (int nb = 0; nb < nbsBag.length; nb++) {
        if (visited[nb] == false) {   
        	System.out.println("\nNEW SEPARATOR!!");
        	minSeps[nSeps] = new int[] {nbsBag[nb]};
          DFS(nb, nbsBag, nSeps); 
          nSeps++;
        }
  	}
  	return minSeps;
  }
  
  public void DFS(int nb, int[] nbsBag, int nSeps) { 
  	//System.out.println(Arrays.deepToString(minSeps));
  	//System.out.println(nb);
  	  	
    // Mark the current node as visited 
    visited[nb] = true; 
    
    //counter++;
    //if(counter == 20) System.exit(0);

    //Find the set of all neighbors of nb that neighbor the bag, and add them to the separator
    int[] nextNbs = getIntersection(nbsBag, neighbor[nbsBag[nb]]);
    
    //System.out.println("\nNeighbor in question: " + nbsBag[nb]);
    //System.out.println("NextNbs = " + Arrays.toString(nextNbs));
    //System.out.println("minSeps[nSeps] = " + Arrays.toString(minSeps[nSeps]));
    
    minSeps[nSeps] = getUnion(minSeps[nSeps], nextNbs);
    
    //System.out.println("minSeps[nSeps] = " + Arrays.toString(minSeps[nSeps]));
      
    //For each of these nextNbs recurse
    for (int i = 0; i < nextNbs.length; i++) {
    	int pos = Arrays.binarySearch(nbsBag, nextNbs[i]);
    	if (visited[pos] == false) {
    		DFS(pos, nbsBag, nSeps);
    	}
    }
    
  }

  /**
   * Compute the full components associated with the given separator,
   * by means of iterated bit operations
   * @param separator set of vertices to be removed
   * @return the arrayList of full components,
   * the vertex set of each component represented by a {@code XBitSet}
   */
  /**public ArrayList<XBitSet> fullComponents(XBitSet separator) {
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    XBitSet rest = all.subtract(separator);
    for (int v = rest.nextSetBit(0); v >= 0;
        v = rest.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) neighborSet[v].clone();
      XBitSet toBeScanned = c.subtract(separator);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
          w = toBeScanned.nextSetBit(w + 1)) {
          c.or(neighborSet[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
      }
      if (separator.isSubset(c)) {
        result.add(c.subtract(separator));
      }
      rest.andNot(c);
    }
    return result;
  }*/
  
  /**
   * Find a full component associated with the given separator
   * @param separator set of vertices to be removed
   * @return a full components associated with the separator; 
   * {@code null} if none is found 
   */
  /**public XBitSet aFullComponent(XBitSet separator) {
    XBitSet rest = all.subtract(separator);
    for (int v = rest.nextSetBit(0); v >= 0;
        v = rest.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) neighborSet[v].clone();
      XBitSet toBeScanned = c.subtract(separator);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
          w = toBeScanned.nextSetBit(w + 1)) {
          c.or(neighborSet[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
      }
      if (separator.isSubset(c)) {
        return c.subtract(separator);
      }
      rest.andNot(c);
    }
    return null;
  }*/

  /**
   * Decides if the given vertex set is a minimal separator of
   * this target graph
   * Added: Nov 18, 2019 by Hisao Tamaki
   * @param vs the vertex set
   * @return {@cod true} if the vertex set is a minimal separator
   * {@code false} otherwise
   *    */
  /**boolean isMinimalSeparator(XBitSet vs) {
    return fullComponents(vs).size() >= 2;
  }*/  
  
  /**
   * Decides if the given connected vertex set is minimally separated, i.e.
   * its neighborhood is a minimal separator
   * Added: Nov 18, 2019 by Hisao Tamaki
   * @param connected the connected vertex set
   * @return {@cod true} if the vertex set is minimally separated
   * {@code false} otherwise
   *    */
  /**boolean isMinimallySeparated(XBitSet connected) {
    assert isConnected(connected);
    XBitSet separator = neighborSet(connected);
    XBitSet rest = all.subtract(connected);
    rest.andNot(separator);
    ArrayList<XBitSet> components = componentsOf(rest);
    for (XBitSet compo: components) {
      if (isFullComponent(compo, separator)) {
        return true;
      }
    }
    return false;
  }*/
  
  /**
   * Decides if the given vertex set is a separator free of full components
   * Added: Nov 18, 2019 by Hisao Tamaki
   * @param separator vertex set to be examined
   * @return {@cod true} if the vertex set is full component free
   * {@code false} otherwise
   *    */
  /**public boolean isFullComponentFree(XBitSet separator) {
    ArrayList<XBitSet> result = new ArrayList<XBitSet>();
    XBitSet rest = all.subtract(separator);
    for (int v = rest.nextSetBit(0); v >= 0;
        v = rest.nextSetBit(v + 1)) {
      XBitSet c = (XBitSet) neighborSet[v].clone();
      XBitSet toBeScanned = c.subtract(separator);
      c.set(v);
      while (!toBeScanned.isEmpty()) {
        XBitSet save = (XBitSet) c.clone();
        for (int w = toBeScanned.nextSetBit(0); w >= 0;
          w = toBeScanned.nextSetBit(w + 1)) {
          c.or(neighborSet[w]);
        }
        toBeScanned = c.subtract(save);
        toBeScanned.andNot(separator);
      }
      if (separator.isSubset(c)) {
        return true;
      }
      rest.andNot(c);
    }
    return false;
  }*/
  
  /**
   *  Decides if a connected vertex set {@code component} is a full component
   *  associated with the given {@code separator}.
   *  @param component the connected set of vertices to be examined
   *  @param separator the separator
   */
  /**public boolean isFullComponent(XBitSet component, XBitSet separator) {
    for (int v = separator.nextSetBit(0); v >= 0; 
          v = separator.nextSetBit(v + 1)) {
      if (component.isDisjoint(neighborSet[v])) {
        return false;
      }
    }
    return true;
  }*/
  
  /**
   *  Decides if a connected vertex set {@code component} is inbound, given all the full compoents
   *  of the neighborSet of {@code component}
   *  @param component the connected set of vertices to be examined
   *  @param fullComponents the list of full components associated with the neighborhood of {@code component}
   */
   public boolean isInbound(XBitSet component, ArrayList<XBitSet> fullComponents) {
     int v0 = component.nextSetBit(0);
     for (XBitSet full: fullComponents) {
       if (full.nextSetBit(0) < v0) {
         return true;
       }
     }
     return false;
   }
  /**
   * Checks if the given induced subgraph of this target graph is connected.
   * @param vertices the set of vertices inducing the subraph
   * @return {@code true} if the subgrpah is connected; {@code false} otherwise
   */

  /**public boolean isConnected(XBitSet vertices) {
    int v = vertices.nextSetBit(0);
    if (v < 0) {
      return true;
    }

    XBitSet c = (XBitSet) neighborSet[v].clone();
    XBitSet toScan = c.intersectWith(vertices);
    c.set(v);
    while (!toScan.isEmpty()) {
      XBitSet save = (XBitSet) c.clone();
      for (int w = toScan.nextSetBit(0); w >= 0;
        w = toScan.nextSetBit(w + 1)) {
        c.or(neighborSet[w]);
      }
      toScan = c.subtract(save);
      toScan.and(vertices);
    }
    return vertices.isSubset(c);
  }*/

  /**
   * Checks if the given induced subgraph of this target graph is biconnected.
   * @param vertices the set of vertices inducing the subraph
   * @return {@code true} if the subgrpah is biconnected; {@code false} otherwise
   */
  /**public boolean isBiconnected(BitSet vertices) {
//    if (!isConnected(vertices)) {
//      return false;
//    }
    dfCount = 1;
    dfn = new int[n];
    low = new int[n];

    for (int v = 0; v < n; v++) {
      if (!vertices.get(v)) {
        dfn[v] = -1;
      }
    }

    int s = vertices.nextSetBit(0);
    dfn[s] = dfCount++;
    low[s] = dfn[s];

    boolean first = true;
    for (int i = 0; i < degree[s]; i++) {
      int v = neighbor[s][i];
      if (dfn[v] != 0) {
        continue;
      }
      if (!first) {
        return false;
      }
      boolean b = dfsForBiconnectedness(v);
      if (!b) return false;
      else {
        first = false;
      }
    }
    return true;
  }*/

  /**
   * Depth-first search for deciding biconnectivigy.
   * @param v vertex to be visited
   * @return {@code true} if articulation point is found
   * in the search starting from {@cod v}, {@false} otherwise
   */
  /**private boolean dfsForBiconnectedness(int v) {
    dfn[v] = dfCount++;
    low[v] = dfn[v];
    for (int i = 0; i < degree[v]; i++) {
      int w = neighbor[v][i];
      if (dfn[w] > 0 && dfn[w] < low[v]) {
        low[v] = dfn[w];
      }
      else if (dfn[w] == 0) {
        boolean b = dfsForBiconnectedness(w);
        if (!b) {
          return false;
        }
        if (low[w] >= dfn[v]) {
          return false;
        }
        if (low[w] < low[v]) {
          low[v] = low[w];
        }
      }
    }
    return true;
  }*/


  /**
   * Checks if the given induced subgraph of this target graph is triconnected.
   * This implementation is naive and call isBiconnected n times, where n is
   * the number of vertices
   * @param vertices the set of vertices inducing the subraph
   * @return {@code true} if the subgrpah is triconnected; {@code false} otherwise
   */
  /**public boolean isTriconnected(BitSet vertices) {
    if (!isBiconnected(vertices)) {
      return false;
    }

    BitSet work = (BitSet) vertices.clone();
    int prev = -1;
    for (int v = vertices.nextSetBit(0); v >= 0;
        v = vertices.nextSetBit(v + 1)) {
      if (prev >= 0) {
        work.set(prev);
      }
      prev = v;
      work.clear(v);
      if (!isBiconnected(work)) {
        return false;
      }
    }
    return true;
  }*/

  /**
   * Compute articulation vertices of the subgraph of this
   * target graph induced by the given set of vertices
   * Assumes this subgraph is connected; otherwise, only
   * those articulation vertices in the first connected component
   * are obtained.
   *
   * @param vertices the set of vertices of the subgraph
   * @return the set of articulation vertices
   */
  /**public XBitSet articulations(BitSet vertices) {
    articulationSet = new XBitSet(n);
    dfCount = 1;
    dfn = new int[n];
    low = new int[n];

    for (int v = 0; v < n; v++) {
      if (!vertices.get(v)) {
        dfn[v] = -1;
      }
    }

    depthFirst(vertices.nextSetBit(0));
    return articulationSet;
  }*/

  /**
   * Depth-first search for listing articulation vertices.
   * The articulations found in the search are
   * added to the {@code XBitSet articulationSet}.
   * @param v vertex to be visited
   */
  /**private void depthFirst(int v) {
    dfn[v] = dfCount++;
    low[v] = dfn[v];
    for (int i = 0; i < degree[v]; i++) {
      int w = neighbor[v][i];
      if (dfn[w] > 0) {
        low[v] = Math.min(low[v], dfn[w]);
      }
      else if (dfn[w] == 0) {
        depthFirst(w);
        if (low[w] >= dfn[v] &&
            (dfn[v] > 1 || !lastNeighborIndex(v, i))){
          articulationSet.set(v);
        }
        low[v] = Math.min(low[v], low[w]);
      }
    }
  }*/

  /**
   * Decides if the given index is the effectively
   * last index of the neighbor array of the given vertex,
   * ignoring vertices not in the current subgraph
   * considered, which is known by their dfn being -1.
   * @param v the vertex in question
   * @param i the index in question
   * @return {@code true} if {@code i} is effectively
   * the last index of the neighbor array of vertex {@code v};
   * {@code false} otherwise.
   */

  /**private boolean lastNeighborIndex(int v, int i) {
    for (int j = i + 1; j < degree[v]; j++) {
      int w = neighbor[v][j];
      if (dfn[w] == 0) {
        return false;
      }
    }
    return true;
  }*/

  /**
   * Decides if the given vertex set is independent in this target graph.
   * @param vs the vertex set
   * @return {@code true} if {@code vs} is an independent set, 
   * {@code false} otherwise.
   */

  /**public boolean isIndependent(XBitSet vs) {
    for (int v = vs.nextSetBit(0); v >= 0; v = vs.nextSetBit(v + 1)) {
      if (vs.intersects(neighborSet[v])) {
        return false;
      }
    }
    return true;
  }*/

  /**
   * Decides if the given vertex set is a clique of this target graph.
   * @param vs the vertex set
   * @return {@code true} if {@code vs} is a clique
   * {@code false} otherwise.
   */

  /**public boolean isClique(XBitSet vs) {
    for (int v = vs.nextSetBit(0); v >= 0; v = vs.nextSetBit(v + 1)) {
      XBitSet nb = (XBitSet) neighborSet[v].clone();
      nb.set(v);
      if (!vs.isSubset(nb)) {
        return false;
      }
    }
    return true;
  }*/

  /**
   * Decides if the given vertex set is a cliquish in this target graph, 
   * in the sense that filling the neighborhood of each component separated
   * by this vertex set makes the vertex set into a clique.
   * @param vs the vertex set
   * @return {@code true} if {@code vs} is cliquish
   * {@code false} otherwise.
   */

  /**public boolean isCliquish(XBitSet vs) {
    ArrayList<XBitSet> components = separatedComponents(vs);
    XBitSet[] neighborhoods = new XBitSet[components.size()];
    for (int i = 0; i < components.size(); i++) {
      neighborhoods[i] = neighborSet(components.get(i));
    }
        
    for (int v = vs.nextSetBit(0); v >= 0; v = vs.nextSetBit(v + 1)) {
      XBitSet na = vs.subtract(neighborSet[v]);
      na.clear(v);
      for (int w = na.nextSetBit(0); w >= 0; w = na.nextSetBit(w + 1)) {
        boolean covered = false;
        for (XBitSet nb: neighborhoods) {
          if (nb.get(v) && nb.get(w)) {
            covered = true;
          }
        }
        if (!covered) {
          return false;
        }
      }
    }
    return true;
  }*/

  /** 
   * fill the specified vertex set into a clique
   * bug fixed March 17, 2019: was adding self loops
   * @param vertexSet vertex set to be filled 
   */
  /**public void fill(XBitSet vertexSet) {
    for (int v = vertexSet.nextSetBit(0); v >= 0;
        v = vertexSet.nextSetBit(v + 1)) {
      XBitSet missing = vertexSet.subtract(neighborSet[v]);
      missing.clear(v);
      for (int w = missing.nextSetBit(v + 1); w >= 0;
          w = missing.nextSetBit(w + 1)) {
        addEdge(v, w);
      }
    }
  }*/
  
  /** 
   * count the number of missing edges in the given vertex set
   * @param vertexSet vertex set for which the missing edges are counted
   * @return the number of missing edges
   */
  /**public int fillCount(XBitSet vertexSet) {
    int count = 0;
    for (int v = vertexSet.nextSetBit(0); v >= 0;
        v = vertexSet.nextSetBit(v + 1)) {
      XBitSet missing = vertexSet.subtract(neighborSet[v]);
      count += missing.cardinality() - 1;
    }
    return count / 2;
  }*/
  
  /** 
   * fill the specified vertex set into a clique
   * @param vertices int array listing the vertices in the set
   */
  /**public void fill(int[] vertices) {
    for (int i = 0; i < vertices.length; i++) {
      for (int j = i + 1; j < vertices.length; j++) {
        addEdge(vertices[i], vertices[j]);
      }
    }
  }*/

  /** 
   * tests if the target graph is a minimal triangulation of the given graph
   * assumes that the target graph is chordal
   * added Dec 3, 2019, Hisao Tamaki
   * @param g the given graph  
   * @return {@code true} if the target graph is a minimal triangulation of {@code g}
   * {@code false} otherwise.
   */
  /**public boolean isMinimalTriangulationOf(Graph_NR g) {
    assert n == g.n;
    XBitSet remaining = (XBitSet) g.all.clone();
    Queue<Integer> queue = new LinkedList<>();
    for (int v= 0; v < n; v++) {
      if (isClique(neighborSet[v])) {
        queue.add(v);
      }
    }
    while (!queue.isEmpty()) {
      int v = queue.remove();
      remaining.clear(v);
      XBitSet forwardNeighbors = neighborSet[v].intersectWith(remaining);
      if (isMinimalSeparator(forwardNeighbors) &&
          !g.isMinimalSeparator(forwardNeighbors)) {
        return false;
      }
      for (int w = forwardNeighbors.nextSetBit(0); w >= 0;
          w = forwardNeighbors.nextSetBit(w + 1)) {
        if (isClique(neighborSet[w].intersectWith(remaining))) {
          queue.add(w);
        }
      }
    }
    assert remaining.isEmpty(): "the target graph is not chordal";
    return true;
  }8?

  /** 
   * tests if the target graph is chordal
   * added Dec 3, 2019, Hisao Tamaki
   * @return {@code true} if the target graph is chordal
   * {@code false} otherwise.
   */
  /**public boolean isChordal() {  
    for (int v = 0; v < n; v++) {
      if (!isLBSimplicial(v)) {
        return false;
      }
    }
    return true;
  }/*
  
  /** 
  * tests if the given vertex is LB-Simplicial in the target graph
  * added Dec 3, 2019, Hisao Tamaki
  * @param v the vertex for which the test is performed
  * @return {@code true} if v is LB-simplicial in the target graph, 
  * {@code false} otherwise.
  */
  /**public boolean isLBSimplicial(int v) {
    XBitSet closure = (XBitSet) neighborSet[v].clone();
    closure.set(v);
    ArrayList<XBitSet> components = separatedComponents(neighborSet[v]);
    for (XBitSet compo: components) {
      if (!isClique(neighborSet(compo))) {
        return false;
      }
    }
    return true;
  }*/
  
  /** list all maximal cliques of this graph
   * Naive implementation, should be replaced by a better one
   * @return
   */
  /**public ArrayList<XBitSet> listMaximalCliques() {
    ArrayList<XBitSet> list = new ArrayList<>();
    XBitSet subg = new XBitSet(n);
    XBitSet cand = new XBitSet(n);
    XBitSet qlique = new XBitSet(n);
    subg.set(0,n);
    cand.set(0,n);
    listMaximalCliques(subg, cand, qlique, list);
    return list;
  }*/

  /**
   * Auxiliary recursive method for listing maximal cliques
   * Adds to {@code list} all maximal cliques
   * @param subg
   * @param cand
   * @param clique
   * @param list
   */
  /**private void listMaximalCliques(XBitSet subg, XBitSet cand,
      XBitSet qlique, ArrayList<XBitSet> list) {
      if(subg.isEmpty()){
        list.add((XBitSet)qlique.clone());
        return;
      }
      int max = -1;
      XBitSet u = new XBitSet(n);
      for(int i=subg.nextSetBit(0);i>=0;i=subg.nextSetBit(i+1)){
        XBitSet tmp = new XBitSet(n);
        tmp.set(i);
        tmp = neighborSet(tmp);
        tmp.and(cand);
        if(tmp.cardinality() > max){
          max = tmp.cardinality();
          u = tmp;
        }
      }
      XBitSet candu = (XBitSet) cand.clone();
      candu.andNot(u);
      while(!candu.isEmpty()){
        int i = candu.nextSetBit(0);
        XBitSet tmp = new XBitSet(n);
        tmp.set(i);
        qlique.set(i);
        XBitSet subgq = (XBitSet) subg.clone();
        subgq.and(neighborSet(tmp));
        XBitSet candq = (XBitSet) cand.clone();
        candq.and(neighborSet(tmp));
        listMaximalCliques(subgq,candq,qlique,list);
        cand.clear(i);
        candu.clear(i);
        qlique.clear(i);
      }
  }*/

  /**
   * Saves this target graph in the file specified by a path string,
   * in .gr format.
   * A stack trace will be printed if the file is not available for writing
   * @param path the path-string
   */
  public void save(String path) {
    File outFile = new File(path);
    PrintStream ps;
    try {
      ps = new PrintStream(new FileOutputStream(outFile));
      writeTo(ps);
      ps.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
  }
  /**
   * Write this target graph in .gr format to the given
   * print stream.
   * @param ps print stream
   */
  public void writeTo(PrintStream ps) {
    int m = 0;
    for (int i = 0; i < n; i++) {
      m += degree[i];
    }
    m = m / 2;
    ps.println("p tw " + n + " " + m);
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < degree[i]; j++) {
        int k = neighbor[i][j];
        if (i < k) {
          ps.println((i + 1) + " " + (k + 1));
        }
      }
    }
  }

  /**
   * Create a copy of this target graph
   * @return the copy of this graph
   */
  public Graph_NR copy() {
    Graph_NR tmp = new Graph_NR(n);
    for (int v = 0; v < n; v++) {
      for (int j = 0; j < degree[v]; j++) {
        int w = neighbor[v][j];
        tmp.addEdge(v, w);
      }
    }
    return tmp;
  }

  /**
   * Check consistency of this graph
   * 
   */
  /**public void checkConsistency() throws RuntimeException {
    for (int v = 0; v < n; v++) {
      for (int w = 0; w < n; w++) {
        if (v == w) continue;
        if (indexOf(v, neighbor[w]) >= 0 && 
            indexOf(w, neighbor[v]) < 0) {
          throw new RuntimeException("adjacency lists inconsistent " + v + ", " + w);
        }
        if (neighborSet[v].get(w) &&
            !neighborSet[w].get(v)) {
          throw new RuntimeException("neighborSets inconsistent " + v + ", " + w);
        }
      }
    }
  }*/
  /**
   * Create a random graph with the given number of vertices and
   * the given number of edges
   * @param n the number of vertices
   * @param m the number of edges
   * @param seed the seed for the pseudo random number generation
   * @return {@code Graph} instance constructed
   */
  public static Graph_NR randomGraph(int n, double p) {
    Random random = new Random(1);
    Graph_NR g = new Graph_NR(n);

    for (int v = 0; v < n; v++) {
      for (int w = v + 1; w < n; w++) {
        if (random.nextDouble() < p) {
          g.addEdge(v, w);
          g.addEdge(w, v);
        }
      }
    }
    return g;
  }
  
  //Get union of two sorted arrays
  public static int[] getUnion(int arr1[], int arr2[]) { 
    int i = 0, j = 0; 
    int m = arr1.length;
    int n = arr2.length;
    
    int[] union = new int[m + n];
    int degree = 0;
    
    //Choose the smallest value of both arrays, add it to the new array. If they are the same, choose one.
    while (i < m && j < n) { 
      degree++;
      if (arr1[i] < arr2[j])     	  
    	  union[degree - 1] = arr1[i++]; 
      else if (arr2[j] < arr1[i]) 
    	  union[degree - 1] = arr2[j++]; 
      else { 
    	  union[degree - 1] = arr2[j++];
          i++; 
      } 
    } 
         
    /* Print remaining elements of  
       the larger array */
    while(i < m) {
        degree++;
    	union[degree - 1] = arr1[i++];
    }
    while(j < n) {
        degree++;
        union[degree - 1] = arr2[j++];
    } 
    
    /*Return the elements that are non-zero in a new array*/   
    return Arrays.copyOfRange(union, 0, degree);    
  } 
  
  
  //Add int v to array arr
  public static int[] add(int arr[], int v) { 
  	int m = arr.length;
  	
    int[] result = new int[m + 1];
    int placeOfV = -1;
    
    for (int i = 0; i < m; i++) {
    	if (arr[i] == v) {
    		return arr;
    	}
    	if (arr[i] > v) {
    		result[i] = v;
    		placeOfV = i;
    		break;
    	}
    	result[i] = arr[i];
    }
    
    if (placeOfV == -1)
    	result[m] = v;
    else
    	System.arraycopy(arr, placeOfV, result, placeOfV + 1, m - placeOfV);
         
    return result;
  } 
  
  //Intersection of two sorted arrays
  public int[] getIntersection(int arr1[], int arr2[]) { 
	    int i = 0, j = 0; 
	    int m = arr1.length;
	    int n = arr2.length;
	    
	    int[] intersection = new int[]{};
	    int degree = 0;
	    
	    //Increment the smallest counter. If two values are the same, add it to the new array.
	    while (i < m && j < n) { 
	      if (arr1[i] < arr2[j])     	  
	    	  i++; 
	      else if (arr2[j] < arr1[i]) 
	    	  j++; 
	      else { 
	    	  degree++;
		      intersection = Arrays.copyOf(intersection, degree);	    	  
	    	  intersection[degree - 1] = arr2[j++];
	          i++; 
	      } 
	    } 
	    return intersection;    
  }   
  
  //Subtract array 2 from array 1.
  public static int[] subtract(int arr2[], int arr1[]) { 

  	//if (arr1.length == 0) return arr1;
  	
    int i = 0, j = 0; 
    int m = arr1.length;
    int n = arr2.length;
    
    int[] newArray = new int[]{};
    int degree = 0;
    
    //Iterate over array 2. Collect the elements in array 1 that are not in array 2.
    while (i < m && j < n) { 
    	
    	if (arr1[i] < arr2[j]) {
    		
    		degree++;
  	        newArray = Arrays.copyOf(newArray, degree);
  	        newArray[degree - 1] = arr1[i++];
    	}
    	else if (arr2[j] < arr1[i])
    		j++;
    	else {
    		i++;
    		j++;
    	}
    }
     
    /* Collect remaining elements of array one*/
    while(i < m) {
        degree++;
        newArray = Arrays.copyOf(newArray, degree);
        newArray[degree - 1] = arr1[i++];
    } 
    return newArray;    
  } 
  
  
  /* Add element to sorted array. Adjust the array.*/
  public static void addSorted(int arr[], int v){ 
      int i; 
      for (i = arr.length - 1; (i >= 0 && arr[i] > v); i--) 
          arr[i + 1] = arr[i]; 
      arr[i + 1] = v; 
  } 
  
  
  
  
  public void cleanUp() {
  	boolean trace = false;
  	boolean traceDegrees = false;

  	/*Sort the neighborhoods*/
  	for(int v = 0; v < n; v++) {
  		if (neighbor[v] != null)
  			Arrays.sort(neighbor[v]);
  	}

    deleteElements = new XBitSet(n);
    

  	/*Delete vertices without neighbors*/
  	deleteDegree0(); 	
  	
  	if (trace) {
  		System.out.println("\nAfter deleteDegree0");
  		writeTo(System.out);
  	}
  	
  	
  	/*Delete vertices with degree 1*/
  	deleteDegree1(); 	
  	
  	if (trace) {
	  	System.out.println("\nAfter deleteDegree1");
	  	writeTo(System.out);	
  	}
  	
  	deleteDegree2();
  	
  	if (trace) {
	  	System.out.println("\nGraph after deleteDegree2");
	  	writeTo(System.out); 
  	}
  	
  	
  	keepLargestComponent();
  	
  	if (trace) {
	  	System.out.println("\nGraph after keeping the largest component");
	  	writeTo(System.out); 
  	}
  	
  	if (traceDegrees) {
  		int maxD = maxDegree();
  		int[] degreeDist = new int[maxD + 1];
  		for (int v = 0; v < n; v++) {
  			if(degree[v] == 1){
  				System.out.println("Degree 1: " + v);
  			}
  			degreeDist[degree[v]]++;
  		}
  		System.out.println("Degree distribution = " + Arrays.toString(degreeDist));
  	}
  	
  	
  	//deleteDegree1();
  	//updateVertices();
  	
  	//contractEdges();
  	//largestComponent();
  }
  
  
  public void deleteDegree0() {
  	deleteElements = new XBitSet(n);
  	nDeleted = 0;
  	for (int v = 0; v < n; v++) {
  		if (degree[v] == 0) {
  			if(!deleteElements.get(v)) {
  				nDeleted++;
  				deleteElements.set(v);
  			}
  		}
  	}
  	updateVertices();
  }
   
  public void deleteDegree1() {
  	deleteElements = new XBitSet(n);
  	nDeleted = 0;
  	for (int v = 0; v < n; v++) {
  		//System.out.println("\nv = " + v + ", degree = " + degree[v] + ", N = " + Arrays.toString(neighbor[v]));  		
  		if (degree[v] == 1) {
  			delete1degree(v);
  		}
  	}   	  	
  	updateVertices();
  }
  
  /*If the vertex isn't removed yet, remove it*/
  public void delete1degree(int v) {
  	
  	/*Check if the vertex is already removed*/
  	if(!deleteElements.get(v)) {
			nDeleted++;
			deleteElements.set(v);
		
    	/*If the neighbor of effected is not already being removed, delete the edge connecting them*/
    	int NV = neighbor[v][0];
    	if(!deleteElements.get(NV))
    		deleteEdge(v, NV);		
  	}
  }
  
  /*Delete each vertices with degree two which neighbors do not neighbor each other*/
  public void deleteDegree2() {
  	deleteElements = new XBitSet(n);
  	nDeleted = 0;
  	doing2 = true;
  	for (int v = 0; v < n; v++) {
  		//System.out.println("\nv = " + v + ", degree = " + degree[v] + ", N = " + Arrays.toString(neighbor[v]));  		
  		if (degree[v] == 2) {
  			need2delete(v); 				 
  		}
  	}   	  	
  	updateVertices();
  }
  
  /*Delete a vertex of degree two if its neighbors do not neighbor each other*/
  public void need2delete(int v) {
  	boolean trace = false;
  	
  	if (trace)
  		System.out.println("Do we delete vertex " + v + " with N = " + Arrays.toString(neighbor[v]));
  	
  	/*Check if the vertex is already removed*/
  	if(!deleteElements.get(v)) {
	  	/*Check if the neighbors neighbor each other*/
	  	int n1 = neighbor[v][0];
			int n2 = neighbor[v][1];
			int pos = Arrays.binarySearch(neighbor[n1], n2);
			
			/*If this is the case, delete their edges to v and connect them to each other (if they aren't in deleteElements)*/
			if(pos < 0) {
				if (trace)
					System.out.println("Yes we do!");
				if(!deleteElements.get(v)) {
					nDeleted++;
					deleteElements.set(v);
				}
				
				if (!deleteElements.get(n1))
					deleteEdge(v, n1);
				if (!deleteElements.get(n2))
					deleteEdge(v, n2);
				if (!deleteElements.get(n1) && !deleteElements.get(n2)) {
					addEdge(n1,n2);
					Arrays.sort(neighbor[n1]);
					Arrays.sort(neighbor[n2]);
				}
				
				
				if (trace) {
					System.out.println("N(" + n1 + ") = " + Arrays.toString(neighbor[n1]));
					System.out.println("N(" + n2 + ") = " + Arrays.toString(neighbor[n2]));
				}
			}  		
  	}
  }
  
  /*Returns the largest connected component of the graph*/
  public void keepLargestComponent() {
  	
  	/*Reset the value of all*/
  	all = new XBitSet(n);
    for (int i = 0; i < n; i++) {
      all.set(i);
    }
  	
  	XBitSet rest = (XBitSet) all.clone();
  	XBitSet best = new XBitSet();
  	int maxSize = 0;
  	
  	for (int v = rest.nextSetBit(0); v >= 0; v = rest.nextSetBit(v + 1)) {
  		
  		XBitSet comp = getComponent(v);
  		
  		rest = rest.subtract(comp);
  		int compSize = comp.cardinality();
  		
  		if (compSize > maxSize){
  			maxSize = compSize;
  			best = comp;
  		}
  		  		
  		if (maxSize > rest.cardinality()) {
  			break;
  		}
  	} 
  	
  	/*Remove all the vertices that are not in the largest component*/
  	deleteElements = all.subtract(best);
  	nDeleted = deleteElements.cardinality();
  	updateVertices(); 	
  }
  
  /*Get the component of the graph of which start is a part of. */
  public XBitSet getComponent(int start) {
 	
    XBitSet result = new XBitSet(n);
    XBitSet toBeScanned = new XBitSet(n);
    toBeScanned.set(start);
    XBitSet rest = (XBitSet) all.clone();
    rest.clear(start);
    
    if(degree[start] == 0) {  
    	result.set(start);
    	return result;
    }
    
    /*As long as toBeScanned is not empty*/
    while (!toBeScanned.isEmpty()) {
    	int v = toBeScanned.nextSetBit(0);
    	toBeScanned.clear(v);
    	result.set(v);
    	
    	/*For each neighbor of v, 
    	 * if it is not yet in result add it to toBeScanned */
    	for(int i = 0; i < neighbor[v].length; i++) {
    		int w = neighbor[v][i];
    		if (!result.get(w)) {
    			toBeScanned.set(w);
    		}
    	}     	
    }
    return result;
  }
  
  /*Delete the edges of the vertices that we want to remove
   *v is being removed, affected is the other end of the edge*/
  public void deleteEdge(int v, int affected) {
  	boolean trace = false;

  	int posVinAffected = Arrays.binarySearch(neighbor[affected], v);
  	
  	if (trace) {
  		System.out.println("\nDelete edge: (" + v + ", " + affected + ")");
	  	System.out.println("Vertex v :       " + v + ", neighbors = " + Arrays.toString(neighbor[v]));
	  	System.out.println("Vertex affected: " + affected + ", neighbors = " + Arrays.toString(neighbor[affected]));
	  	System.out.println("Is affected to be deleted? " + deleteElements.get(affected));
	  	System.out.println("posVinAffected = " + posVinAffected);
  	}
  	
  	if (posVinAffected < 0) {
  		System.out.println("Trying to delete an edge that doesn't exist");
      System.exit(0);
    }
  	
  	degree[v]--;
  	degree[affected]--;
  	//System.out.println("degree affected = " + degree[affected] + ", deleted? " + deleteElements.get(affected));
  	
    /*Construct a new neighborhood array without the deleted edge, if the vertex is not already set to be deleted*/ 
  	//if(!deleteElements.get(affected)) {
	  int[] newNAffected = new int[degree[affected]];
	  if(posVinAffected == 0) {
	   	System.arraycopy(neighbor[affected], 1, newNAffected, 0, degree[affected]);
	  }
	  else {
	    System.arraycopy(neighbor[affected], 0, newNAffected, 0, posVinAffected);
	    System.arraycopy(neighbor[affected], posVinAffected + 1,newNAffected, posVinAffected, degree[affected] - posVinAffected);
	  }
    neighbor[affected] = newNAffected;  
  	//}
  	
  	if (trace) {
	    System.out.println("New neighbors of v" + v + ": " + Arrays.toString(neighbor[v]));
	  	System.out.println("New neighbors of w" + affected + ": " + Arrays.toString(neighbor[affected]));
    }
    
  	/*If the affected vertex needs to be removed, do that.*/
    if (degree[affected] == 0) {
    	if(!deleteElements.get(affected)) {
				nDeleted++;
				deleteElements.set(affected);
			}
    }
    
    if(degree[affected] == 1) {
    	delete1degree(affected);
    }
    
    if(doing2 && degree[affected] == 2) {
    	need2delete(affected);
    }
  }
  
  
  /*Delete the vertices that need to be removed, 
   * after the edges have already been removed*/
  public void updateVertices() {

  	int newSize = n - nDeleted;
  	Graph_NR newG = new Graph_NR(newSize);
  	
  	//System.out.println("\n" + Arrays.deepToString(neighbor));
  	//System.out.println("deleteElements = " + deleteElements + ", old size = " + n + ", new size = " + newSize);
  	
  	/*Copy the neighborhoods of only those vertices we are keeping*/
  	int nManaged = 0;
  	for (int v = 0; v < n; v++) {
  		if(deleteElements.get(v)) {
  			nManaged++;
  			continue;
  		}
  		//System.out.println("\nnewG = " + Arrays.toString(newG.neighbor));
  		//System.out.println(Arrays.toString(neighbor[v]));
  		
  		//System.out.println("n = " + n + ", nManaged = " + nManaged + ", v = " + v);
  		
  		newG.neighbor[v - nManaged] = neighbor[v];
  		newG.degree[v - nManaged] = degree[v];
  	}  	
  	
  	
  	/*Update the labeling of the neighbors,
  	 * such that all the neighbors are numbered correctly*/  	
  	for(int w = 0; w < newSize; w++) {
  		int nextDel = deleteElements.nextSetBit(0);
  		int countDel = 0;  		
  		for(int n = 0; n < newG.degree[w]; n ++) { 			
  			while (newG.neighbor[w][n] > nextDel) {
  				if(nextDel < 0)
  					break;
  				nextDel = deleteElements.nextSetBit(nextDel + 1);
  				countDel++;
  			}
  			newG.neighbor[w][n] -= countDel;
  		}
  	}
  	
  	this.n = newSize;
  	this.degree = newG.degree;
  	this.neighbor = newG.neighbor;
  	this.all = newG.all;
  	deleteElements = new XBitSet(newSize);
  }
  

  public static void main(String args[]) {
    // an example of the use of random graph generation
    for (int n = 10; n <= 25; n += 5) {
      for (int m = 3 * n; m <= 5 * n; m += n) {
        Graph_NR g = randomGraph(n, m);
        String ns = Integer.toString(n);
        ns = "000".substring(ns.length()) + ns;
        String ms = Integer.toString(m);
        ms = "000".substring(ms.length()) + ms;
        g.save("instance/random/gnm_" + ns + "_" + ms + "_1.gr");
      }
    }
  }
}
