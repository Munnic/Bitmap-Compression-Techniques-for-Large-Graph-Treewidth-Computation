package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;


public class TestTime {
	public static void main(String args[]) {
		//read the graph
		int nStart = 4817330;
		int nEnd = 4817330;
		double nFactor = 1.1;
		
		for (int n = nStart; n <= nEnd; n = (int) ((int) ((int) ((int) (n * nFactor) * nFactor) * nFactor) * nFactor)) {
			
			/*adjust for skip in graphs*/
			if (n == 1097) {
				n = 1100;
			}
	      		   		
			String graphName = "pkt_n" + n + "_k40_p0.075_seed1";
			String path = "instance/pkt";
			String graph      = "graphs/" + graphName;
		
			
			/*Read graph*/
			Graph_NR g              = Graph_NR.readGraph(path, graph);		
      System.out.println("\nGraph of size " + g.n);			
			
			//Construct TD
			long time1 = System.currentTimeMillis();
      MinDegree_NRNR md = new MinDegree_NRNR(g);
      TreeDecomposition_NR td = md.decompose();
      
      System.out.println("Tree decomposition generated, width = " + td.width);
      
      long time2 = System.currentTimeMillis();
			System.out.println("Time: " + (time2 - time1)/1000 + " s");
			
			
			//Output time it took 
		}
	}

} 
