package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import tw.common.XBitSet;
import tw.constructbenchmark.MinDegree_NRNR;
import tw.constructbenchmark.PKT;

import java.util.BitSet;

public class ConstructBenchmark {
  //private static Graph_NR g;
  //private static TreeDecomposition_NR td;
	
	
  public static void main(String args[]) {
  	boolean traceTime = true;
  	boolean traceMemory = true;
  	long time0 = System.currentTimeMillis();
  	
  	getPKT();  		
  	//getRandomGraph();          
  	
  	
  	if(traceTime) {
	    long time4 = System.currentTimeMillis();
			System.out.println("Total time: " + (time4 - time0) / 1000 + "s");
	  }
	  
	  if(traceMemory){
	  	 System.gc();
	     // Calculate the used memory
	     long memory = Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
	     System.out.println("Memory used = " + memory / 1048576 + "MB");
	  }
	}
  
  public static void getPKT(){
  	int nMin = 1000; //each round *1.1
  	int nMax = 1000000;
  	int kMin = 10; //doubles each time
  	int kMax = 10;
  	int pStep = 3; //Factor of edges with respect to n. (it goes pStep, ) -> at the start this has to be 2!!
  	int pCountMax = 1; //Number of steps for p to take, each step p += 2. (set to 3!!)
  	int sMin = 1; //Seed
  	int sMax = 1;
  	
  	/*Create the graphs*/
  	PKT.generateFiles(nMin, nMax, kMin, kMax, pStep, pCountMax, sMin, sMax);
  	
  }
  
  public static void getRandomGraph() {
  	
  	int nMin = 1000;
  	int nMax = 32000;
  	int nStep = 2; //Each next round n * nStep

  	for (int n = nMin; n <= nMax; n *= nStep) {		
			/*Compute the probability of an edge*/
			double p = (double) 4 / n;			
				
			long time1 = System.currentTimeMillis();
			
			/*Generate graph*/
			System.out.println("\nGenerating graph. n = " + n + ", p = " + p + "");
			Graph_NR g = Graph_NR.randomGraph(n, p);
      
      /*Clean the graph*/
      g.cleanUp();
      
			int m = 0;
      for (int i = 0; i < g.n; i++) {
        m += g.degree[i];
      }
      m = m / 2;	           
      System.out.println("Graph generated and cleaned, n = " + g.n + ", nEdges = " + m);       
      long time2 = System.currentTimeMillis();
			System.out.println("Time: " + (time2 - time1) / 1000 + "s");

			
      /*Compute the tree decomposition*/
      MinDegree_NRNR md = new MinDegree_NRNR(g);
      TreeDecomposition_NR td = md.decompose();
      
      System.out.println("Tree decomposition generated, width = " + td.width);
      
      long time3 = System.currentTimeMillis();
			System.out.println("Time: " + (time3 - time2) / 1000 + "s");
			

      /*Write the graph and the bags of the tree decomposition to files*/
      String path = "instance/random/";
      String nameGraph = "graphs/random" + "_n" + n + "_p" + p + ".gr";
      String nameSeps = "separators/random" + "_n" + n + "_p" + p + ".gr";
      
      File fileGraph = new File(path + nameGraph);
      try {
        PrintStream ps = new PrintStream(new FileOutputStream(fileGraph));
        g.writeTo(ps);
        ps.close();
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      }
      
      
      File fileSeps = new File(path + nameSeps);
      try {
        PrintStream ps = new PrintStream(new FileOutputStream(fileSeps));
        //ps.println("c partial k tree: n = " + n + 
        		//", k = " + k + ", edge probability = " + p + "/100, seed = " + s);
        td.writeTo(ps);
        ps.close();
      } catch (FileNotFoundException e) {
        e.printStackTrace();
      }
  	}
  }



}

