package tw.constructbenchmark;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import tw.common.XBitSet;

public class MinDegree_NR {
  static boolean TRACE = true;
  static boolean TRACE_PROGRESS = true;
  static boolean TRACE_TIME = true;

  Graph_NR g;
  int[] pos; // pos[v] is the position of v in the constructed ordering
  static int[] dominator; //If a vertex is dominated by another vertex, it will be included in its bag in the TD.
  int[][] nb; //List of neighbor sets for all the vertices
  XBitSet[] byDegree; //Sorted vertices by their degree
  int byDegreeSize;
  Vertex[] vertex;
  XBitSet remaining; //Vertices that are not eliminated yet
  int nRanked;
  int minDegree;
  int maxDegree;
  int[] bagIndex;
  TreeDecomposition_NR td;
  long fillTime;
  long deleteElementTime;
  long updateRankTime;
  int counter;

  
  public MinDegree_NR(Graph_NR g) {  	
    this.g = g;
    nb = g.neighbor.clone();    
    vertex = new Vertex[g.n];
    for (int v = 0; v < g.n; v++) {
      vertex[v] = new Vertex(v);
    }
  }
  
  public TreeDecomposition_NR decompose() {
	long t0 = System.currentTimeMillis();
	
    order();
    
    long t1 = System.currentTimeMillis() - t0;
    if (TRACE_TIME) 
    	System.out.println("Time for order = " + t1 + " millisecs");
    
    constructTD();
    
    return td;
  }
  

  public void order() {
  	maxDegree = g.maxDegree(); 	
  	byDegreeSize = maxDegree * 4; 	
  	
  	counter = 0;
  	deleteElementTime = 0;
  	updateRankTime = 0;
  	
    byDegree = new XBitSet[byDegreeSize];
    for (int i = 0; i < byDegreeSize; i++) {
      byDegree[i] = new XBitSet(g.n);
    }
    
    nRanked = 0;
    remaining = (XBitSet) g.all.clone();
    minDegree = g.n;
    fillTime = 0;

    //Evaluate each vertex and add to the ordering
    for (int v = 0; v < g.n; v++) {
      vertex[v].evaluate();
      vertex[v].addToRanked();
    }
    assert nRanked == g.n;
    
    // pos[v] is the position of v in the constructed ordering
    pos = new int[g.n]; 
    dominator = new int[g.n];
    Arrays.fill(pos, -1);
    int count = 0;
    
    long timeTotalWhile = System.currentTimeMillis();
    long timeA; long timeA2 = 0; long timeAbis; long timeA2bis = 0; long timeB; long timeB2 = 0; long timeC; long timeC2 = 0;
    long timeRemoveSelf = 0; long timeRemoveSelfA; long timeUpdateRank = 0; long timeUpdateRankA; 
        
    while (!remaining.isEmpty()) {
      assert nRanked == remaining.cardinality();
      
      if(TRACE_PROGRESS && (g.n - nRanked) / 100 > count) {
      	count++;
      	int eliminated = g.n - remaining.cardinality();
      	System.out.println("n = " + g.n  + "     nElimated: " + eliminated +  "     minDegree = " + minDegree + "     maxDegree = " + maxDegree);      	
      }

       //Take first ranked vertex
      timeA = System.currentTimeMillis();
      Vertex vert = firstRanked();
      timeA2 += System.currentTimeMillis() - timeA;
      
      int v = vert.id;     
      pos[v] = g.n - nRanked;
      dominator[v] = v;
      
      timeAbis = System.currentTimeMillis();
      vert.removeSelf(); 
      timeA2bis += System.currentTimeMillis() - timeAbis;
       

      timeB = System.currentTimeMillis(); 
      vert.fillNeighborhood();     
      timeB2 += System.currentTimeMillis() - timeB;     
      
      // update the rankings of the affected vertices
      timeC = System.currentTimeMillis();
      for (int k = 0; k < nb[v].length; k++) {    	  
    	int w = nb[v][k];  
    	  
    	//If the neighborhood of w is a subset of the neighborhood of v, it can be removed. And w is dominated by v. 
        if (isSubset(nb[w],nb[v])) {
        	timeRemoveSelfA = System.currentTimeMillis();
          vertex[w].removeSelf();
          dominator[w] = v;  
          timeRemoveSelf += System.currentTimeMillis() - timeRemoveSelfA;  
        }   	          
        //Else update the ranking of w
        else {
        	timeUpdateRankA = System.currentTimeMillis();
          vertex[w].updateRank();
          timeUpdateRank += System.currentTimeMillis() - timeUpdateRankA;
        }
      }
      
      timeC2 += System.currentTimeMillis() - timeC;
      
    }
    
    long timeTotalWhileB = System.currentTimeMillis() - timeTotalWhile;
    
    if(TRACE_TIME) {
	    System.out.println("\nn = " + g.n + ", m = " + g.numberOfEdges());
	    System.out.println("Time for while loop: " + timeTotalWhileB);
	    System.out.println("   Time for firstRanked:       " + timeA2);
	    System.out.println("   Time for removeSelf:        " + timeA2bis);
	    System.out.println("   Time for fill neighborhood: " + timeB2);
	    System.out.println("   Time for for-loop:          " + timeC2);    
	    System.out.println("              Time for isSubset:   " + (timeC2 - timeUpdateRank - timeRemoveSelf)); 
	    System.out.println("              Time for removeSelf: " + timeRemoveSelf); 
	    System.out.println("              Time for updateRank: " + timeUpdateRank); 
	    System.out.println("   Time for deleteElement: " + deleteElementTime);
	    System.out.println("   Time for updateRank:    " + updateRankTime);
    }
    

    /*    if (TRACE) {
     for (int v = 0; v < g.n; v++) {
        System.out.println(v + ": pos = " + pos[v] + ", dominator = " + dominator[v]);
      }
    }*/
  }
  
  void constructTD() {
    bagIndex = new int[g.n];
    td = new TreeDecomposition_NR(0, getWidth(), g);
    for (int v = 0; v < g.n; v++) {
      if (dominator[v] == v) {    	
    	XBitSet bag = new XBitSet(g.n);
      for (int i = 0; i < nb[v].length; i++) {
      	bag.set(nb[v][i]);
      }  
      bag.set(v);
      bagIndex[v] = td.addBag(bag.toArray());
      }
    }
    for (int v = 0; v < g.n; v++) {
      if (dominator[v] == v) {
        int min = -1;
        for(int k = 0; k < nb[v].length; k++) {
          int w = nb[v][k];
          if (dominator[w] == v) {
            continue;
          }
          if (min == -1 || pos[dominator[w]] < pos[min]) {
            min = dominator[w];
          }
        }
        if (min != -1) {
          td.addEdge(bagIndex[v], bagIndex[min]);
        }
      }
    }
  }
  

  public int getWidth() {
    int width = 0;
    for (int v = 0; v < g.n; v++) {
      if (nb[v].length > width) {
        width = nb[v].length;
      }
    }
    return width;
  }


  //Determine which degree vertex we consider next, and return the vertex number with lowest degree.
  Vertex firstRanked() {
    while (byDegree[minDegree].isEmpty()) {
      minDegree++;
    }
    int id = byDegree[minDegree].nextSetBit(0);
    return vertex[id];
  }


  class Vertex implements Comparable<Vertex> {
    int id; //number to distinguish vertex
    int degree;
    
    Vertex(int id) {
      this.id = id;
      evaluate();
    }
    
    
    void fillNeighborhood() {   	
    	for(int i = 0; i < nb[id].length; i++) {    //for each neighbor v.
    		int v = nb[id][i];  
    		nb[v] = Graph_NR.getUnion(nb[v],nb[id]);
    		vertex[v].deleteElement(v);
    		vertex[v].updateRank();
    	}
    }
    
    public void removeSelf() {
    	byDegree[degree].clear(id);
    	for(int i = 0; i < nb[id].length; i++) {    //for each neighbor v.
    		int v = nb[id][i]; 
    		vertex[v].deleteElement(id);
    		vertex[v].updateRank();
    	}
    	nRanked--;
    	remaining.clear(id);
    }
    
    public void updateRank() {
    	long time1 = System.currentTimeMillis();
      int oldDegree = degree;
      evaluate();
      if (degree != oldDegree) {
        byDegree[oldDegree].clear(id);
        nRanked--;
        addToRanked();
      }
      updateRankTime += System.currentTimeMillis() - time1;
    }
    

    public void addToRanked() {       	

    	/*If the degree is larger than byDegreeSize, byDegree is enlarged to twice its size.*/
    	if(degree >= byDegreeSize) { 
    		byDegreeSize *= 2;
        XBitSet[] newByDegree = new XBitSet[byDegreeSize];       
        for (int i = 0; i < byDegreeSize/2; i++) {
          newByDegree[i] = byDegree[i];
        }
        for (int i = byDegreeSize/2; i < byDegreeSize; i++) {
        	newByDegree[i] = new XBitSet(g.n);
        }     
        byDegree = newByDegree;  
    	}
    	
      byDegree[degree].set(id);
      nRanked++;
      
      if (degree > maxDegree)
      	maxDegree = degree;
      
      if (degree < minDegree) {
          minDegree = degree;
      }
    }

    
    /* Function to delete an element from the neighborhood */
    public void deleteElement (int deleteV) { 
    	
    	long time = System.currentTimeMillis();
    	int newDegree = nb[id].length - 1;
      
      /*Find position of element to be deleted. If element not found, return*/
      int position = Arrays.binarySearch(nb[id], 0, newDegree + 1, deleteV);       
      if (position < 0) {
        return;
      } 
      
      /*Construct a new neighborhood array*/
      int[] newArray = new int[newDegree];      
      if(position == 0) {
      	System.arraycopy(nb[id], 1, newArray, 0, newDegree);
      }
      else {
	      System.arraycopy(nb[id], 0, newArray, 0, position);
	      System.arraycopy(nb[id], position + 1, newArray, position, newDegree - position);
	      //counter++;
	      //if (counter > 20) System.exit(0);
      }
      
      /**Do we need this clone()???*/
      nb[id] = newArray;
      deleteElementTime += System.currentTimeMillis() - time;
    } 
    

    //Determines the size of the average fill, needed for each vertex
    void evaluate() {
      degree = nb[id].length;
      assert degree > 0;
    }
    

    //Determines which vertex should be eliminated earlier.
    @Override
    public int compareTo(Vertex v) {
      if (degree == v.degree) {
        return id - v.id;
      }
      long diff = ((long) v.degree) - ((long) degree);
      if (diff < 0) {
        return -1;
      }
      else if (diff == 0){
        return v.degree - degree;
      }
      else {
        return 1;
      }
    }

    
    @Override
    public int hashCode() {
      return id;
    }

  }

  //Find the position of element 'key' in array 'arr'.
  /**public int binarySearch(int arr[], int low, int high, int key) 
  { 
      if (high < low) 
          return -1; 
      int mid = (low + high) / 2; 
      if (key == arr[mid]) 
          return mid; 
      if (key > arr[mid]) 
          return binarySearch(arr, (mid + 1), high, key); 
      return binarySearch(arr, low, (mid - 1), key); 
  }*/
  
  
  /* Return true if arr2[] is a subset of arr1[] */
  public boolean isSubset(int arr2[], int arr1[]) { 
      int i = 0, j = 0; 
      int m = arr1.length;
      int n = arr2.length;
      
      if(m < n) 
      return false; 

      while( i < n && j < m ) 
      { 
          if( arr1[j] < arr2[i] ) 
              j++; 
          else if( arr1[j] == arr2[i] ) 
          { 
              j++; 
              i++; 
          } 
          else if( arr1[j] > arr2[i] ) 
              return false; 
      } 
        
      if( i < n ) 
          return false; 
      else
          return true; 
  } 
 
  
  //Subtract array 2 from array 1.
  public int[] subtract(int arr1[], int arr2[]) { 
	    int i = 0, j = 0; 
	    int m = arr1.length;
	    int n = arr2.length;
	    
	    int[] newArray = new int[]{};
	    int degree = 0;
	    
	    //Iterate over array 2. Collect the elements in array 1 that are not in array 2.
	    while (i < m && j < n) { 
	    	
	    	if (arr1[i] < arr2[j]) {
	    		
	    		degree++;
	  	        newArray = Arrays.copyOf(newArray, degree);
	  	        newArray[degree - 1] = arr1[i++];
	    	}
	    	else if (arr2[j] < arr1[i])
	    		j++;
	    	else {
	    		i++;
	    		j++;
	    	}
	    }
	     
	    /* Collect remaining elements of array one*/
	    while(i < m) {
	        degree++;
	        newArray = Arrays.copyOf(newArray, degree);
	        newArray[degree - 1] = arr1[i++];
	    } 
	    return newArray;    
	  }  
  
  

  
  
  public static void test(String path, String name) throws Exception{
	  
	long t0 = System.currentTimeMillis();
	Graph_NR g = Graph_NR.readGraph("instance/" + path, name);
	
    System.out.println("\nGraph " + name + " read, n = " + 
        g.n + ", m = " + g.numberOfEdges());
    // for (int v = 0; v < g.n; v++) {
    // System.out.println(v + ": " + g.degree[v] + ", " + g.neighborSet[v]);
    // }
    
    MinDegree_NR md = new MinDegree_NR(g);

    TreeDecomposition_NR td = md.decompose();

    
    long t1 = System.currentTimeMillis();
    System.out.println("width = " + td.width + ", nBags = " + td.nb + ", in " + (t1 - t0) + " millisecs");
    
    

    //System.out.println("Graph " + name + " read, n = " + g.n + ", m = " + g.numberOfEdges());
    
    //td.validate();
    //  td.printBags();
    //  td.writeTo(System.out);
  }
  public static void main(String args[]) throws Exception {
	  
  
	  test("he2017secret", "he196");
	  
	  /**for(int i = 10; i < 100; i=i+2) {
		  String s = "he0" + Integer.toString(i);
		  test("he2017secret", s);
	  }*/
	  
  }
}
