package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import tw.common.XBitSet;
import tw.constructbenchmark.MinDegree_NRNR;
import tw.constructbenchmark.PKT;

import java.util.BitSet;

public class ConstructBenchmark2 {
  //private static Graph_NR g;
  //private static TreeDecomposition_NR td;
	
	
  public static void main(String args[]) {
  	boolean traceTime = true;
  	boolean traceMemory = true;
  	long time0 = System.currentTimeMillis();
  			
  	getPACEtds();          
  	
  	
  	if(traceTime) {
	    long time4 = System.currentTimeMillis();
			System.out.println("Total time: " + (time4 - time0) / 1000 + "s");
	  }
	  
	  if(traceMemory){
	  	 System.gc();
	     // Calculate the used memory
	     long memory = Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory();
	     System.out.println("Memory used = " + memory / 1048576 + "MB");
	  }
	}

  
  public static void getPACEtds() {

  		//for(int i = 198; i < 200; i+=2)	{	
  			
  				String graphPath = "he2017secret";
  				String graphName;
					/*if (i < 10)
  					graphName = "he00" + i;
  				else if (i < 100)
  					graphName = "he0" + i;
  				else */
  				
  				graphName = "he002";
					
					

  				Graph_NR g = Graph_NR.readGraph(graphPath, graphName);
  				
  				System.out.println("Read graph " + graphName + ", n = " + g.n);

  				
          /*Compute the tree decomposition*/
          MinDegree_NRNR md = new MinDegree_NRNR(g);
          TreeDecomposition_NR td = md.decompose();
          
          System.out.println("Tree decomposition generated, width = " + td.width);
  				

          /*Write the graph and the bags of the tree decomposition to files*/
          String path = "benchmark/pace/separators/";
          String nameSeps = "test.gr";
          //String nameSeps = graphName + ".gr";
          
          
          File fileSeps = new File(path + nameSeps);
          try {
            PrintStream ps = new PrintStream(new FileOutputStream(fileSeps));
            //ps.println("c partial k tree: n = " + n + 
            		//", k = " + k + ", edge probability = " + p + "/100, seed = " + s);
            td.writeTo(ps);
            ps.close();
          } catch (FileNotFoundException e) {
            e.printStackTrace();
          }

  		//} 	
  }



}

