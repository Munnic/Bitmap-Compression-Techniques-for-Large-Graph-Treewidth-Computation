package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import tw.constructbenchmark.MinDegree_NRNR;

public class PKT {
  private static int k;
  private static Graph_NR g;
  private static TreeDecomposition_NR td;
  
  
  /*nb is the number of k-cliques, or the number of bags of the td.
   *k is k
   *This means that g.n = nb + k
   *p is the probability (times 100) that each edge in the k-tree is present in the partial k-tree */
  private static void generatePKT(int nb, int k, double p, int seed) {
    PKT.k = k; 
    int n = nb + k;
    g = new Graph_NR(n);
    
    /**for (int v = 0; v < g.n; v++) {
      g.id[v] = v + 1;
    }*/
    
    td = new TreeDecomposition_NR(nb, k, g);

    // To form the tree of bags,
    // sample a uniform spanning tree of the complete graph 
    // using Wilson's algorithm:
	    /*"While there remain vertices not in the tree,
				the algorithm does a random walk from one such
				vertex, erasing cycles as they are created, until the
				walk encounters the current tree. Then the cycle-erased
				trajectory gets added to the current tree."*/
    
    /*First create a minimum spanning tree that covers all k-cliques.
      So basically construct a random tree decomposition*/
    ArrayList<Integer> remaining = new ArrayList<Integer>();
    for (int b = 1; b <= nb; b++) {
      remaining.add(b);
    }

    Random random = new Random(seed);
    
    /*Take a random bag as root*/
    int b0 = pick(remaining, random);
    remaining.remove(Integer.valueOf(b0));
    
    /*Loop over all other elements in remaining*/
    while (!remaining.isEmpty()) {
    	
    	/*Take a random bag from remaining and add it to the (random) walk */
      int s = pick(remaining, random);
      ArrayList<Integer> walk = new ArrayList<>();
      walk.add(s);
      while (true) {
      	/*Pick the next random bag from the tree decomposition*/
        int b = pick(random);
        if (!remaining.contains(b)) {
          int w = walk.get(0);
          /*Add the edges of the path in the td*/
          for (int i = 1; i < walk.size(); i++) {
            remaining.remove(Integer.valueOf(w));
            int w1 = walk.get(i);
            td.addEdge(w, w1);
            td.addEdge(w1, w);
            w = w1;
          }
          remaining.remove(Integer.valueOf(w));
          td.addEdge(w, b);
          td.addEdge(b, w);
          break;
        }
        int i = walk.indexOf(b);
        if (i >= 0) {
          while (walk.size() > i) {
            walk.remove(i);
          }
        }
        walk.add(b);
      }
    }
        
    // now fill the bags with vertices
    
    ArrayList<Integer> vertices = new ArrayList<>();
    for (int i = 0; i < g.n; i++) {
      vertices.add(i);
    }
    
    Collections.shuffle(vertices, random);
    
    /*Construct an initial bag of k+1 nodes*/
    int bag[] = new int[k + 1];
    for (int i = 0; i < k + 1; i++) {
      bag[i] = vertices.get(0);
      vertices.remove(0);
    }    
    td.setBag(1, bag);
    
    /*Fill the other bags with vertices*/
    fill(1, vertices, random);
    
    
    /*Add each edge with probability p. Each has has one chance to be added*/
    ArrayList<ArrayList<Integer> > edgeTried = new ArrayList<ArrayList<Integer> >(n);
    for (int i = 0; i < n; i++) {
    	edgeTried.add(new ArrayList<Integer>());
    }
    
    /*Add edges with prob p, only if edge hasn't been tried to be added before*/
    for (int b = 1; b <= td.nb; b++) {
      for (int i = 0; i < k + 1; i++) {
        int v = td.bags[b][i];       
        for (int j = 0; j < i; j++) {
          int w = td.bags[b][j];      
          
          if (w < v) {
          	if(edgeTried.get(v).contains(w))
          		continue;
          	else {
          		edgeTried.get(v).add(w);
          		if (random.nextDouble() < p) {
                g.addEdge(v, w);
                g.addEdge(w, v);
          		}          			
          	}
          }          
          else {
          	if(edgeTried.get(w).contains(v))
          		continue;
          	else {
          		edgeTried.get(w).add(v);
          		if (random.nextDouble() < p) {
                g.addEdge(v, w);
                g.addEdge(w, v);
          		}          			
          	}
          }
        }
      }
    }
    
    /*Sort all the arrays*/
    for (int v = 0; v < g.n; v++) {
    	if (g.neighbor[v] == null) {
    		g.neighbor[v] = new int[0];
    	}	
    	Arrays.sort(g.neighbor[v]);
    }
    
    /**
    /*Add all edges
    for (int b = 1; b <= td.nb; b++) {
      for (int i = 0; i < k + 1; i++) {
        int v = td.bags[b][i];       
        for (int j = 0; j < i; j++) {
          int w = td.bags[b][j];          
          g.addEdge(v, w);
          g.addEdge(w, v);
        }
      }
    }
    
    int deleted = 0;
    int tried = 0;
    
    /*Sort all the arrays
    for (int v = 0; v < g.n; v++) {
    	Arrays.sort(g.neighbor[v]);
    }
    
    /*Remove each edge with probability 1-p
    for (int v = 0; v < g.n; v++) {    	
    	//System.out.println("\nv = " + v + ", N(v) = " + Arrays.toString(g.neighbor[v]));
    	int[] oldNV = g.neighbor[v].clone();
    	for (int n = 0; n < oldNV.length; n++ ) {
    		
    		int w = oldNV[n];
    		if (w > v) {
    			break;
    		}
    		tried++;
    			
    		if (random.nextDouble() < 1 - p) {  	
    			removeEdge(v, w);    					
    			removeEdge(w, v);
    			deleted ++;
    		}
    		//else
    			//System.out.println("next = " + next + ", do not remove edge (" + v + ", " + g.neighbor[v][n] + ")");
    	}
    }
    */
    
    
    /*Use edgeList to keep track for each edge whether it has had the chance to be added*/
    /**ArrayList<ArrayList<Integer> > edgeList = new ArrayList<ArrayList<Integer>> (g.n);
    for (int i = 0; i < g.n; i ++) {
    	edgeList.add(new ArrayList<Integer>());
    }*/
        
    /*Fill all bags with edges
     *each edge has probability p/100 to exist*/
    /**for (int b = 1; b <= td.nb; b++) {
      for (int i = 0; i < k + 1; i++) {
        int v = td.bags[b][i];       
        for (int j = 0; j < i; j++) {
          int w = td.bags[b][j];          
          if (random.nextDouble() < p && !edgeList.get(v).contains(w)) {
            g.addEdge(v, w);
            g.addEdge(w, v);

          }
          edgeList.get(v).add(w);
          edgeList.get(w).add(v);
        }
      }
    }*/
  }
  
  /*Removes vertex w from the neighborhood of v*/
  public static void removeEdge(int v, int w) {
  	
  	//System.out.println("\nBefore: " + Arrays.toString(g.neighbor[v]));
  	int position = Arrays.binarySearch(g.neighbor[v], w);
  	
  	g.degree[v]--;
  	
  	int[] newNV = new int[g.degree[v]];
	  if(position == 0) {
	   	System.arraycopy(g.neighbor[v], 1, newNV, 0, g.degree[v]);
	  }
	  else {
	    System.arraycopy(g.neighbor[v], 0, newNV, 0, position);
	    System.arraycopy(g.neighbor[v], position + 1,newNV, position, g.degree[v] - position);
	  }
    g.neighbor[v] = newNV;  
    
    //System.out.println("After: " + Arrays.toString(g.neighbor[v]));
 
  }
  

  /*Pick the next random bag from the tree decomposition*/
  private static int pick(Random random) {
    return random.nextInt(td.nb) + 1;
  }

  private static int pick(ArrayList<Integer> remaining, Random random) {
    int r = random.nextInt(remaining.size());
    return remaining.get(r);
  }
  
  private static void fill(int b, ArrayList<Integer> vertices, Random random) {
  	/*For each neighboring bag*/
    for (int i = 0; i < td.degree[b]; i++) {
      int b1 = td.neighbor[b][i];
      /*If that bag is still empty*/
      if (td.bags[b1] == null) {
      	/*Leave out one of the nodes (miss)*/
        int miss = random.nextInt(k + 1);
        /*Construct a bag with all other vertices*/
        int bag[] = new int[k + 1];
        int j = 0;
        for (int h = 0; h < k + 1; h++) {
          if (h != miss) {
            bag[j++] = td.bags[b][h];
          }
        }
        /*Finally, add a new vertex*/
        int v = vertices.get(0);
        vertices.remove(0);
        bag[k] = v;
        
        td.setBag(b1, bag);
        
        /*Recurse on the neighbors of the bag*/
        fill(b1, vertices, random);
      }
    }
  }
  
  /*n is the number of nodes
   * kMin and kMax are k
   * pMin and pMax are the probability * 100k that edges are present */
  public static void generateFiles(int nMin, int nMax, int kMin, int kMax, int pStep, int pCountMax, int sMin, int sMax) {  	
 	  	
    String path = "benchmark/pktContinuous/";
    for (int n = nMin; n <= nMax; n *= 2) {
	    for (int k = kMin; k <= kMax; k = k * 2) {
	    	int nb = n - k;
	      for (int pCount = 1; pCount <= pCountMax; pCount++) {
	      	double p = (double) pStep * pCount / k;
	      	for (int s = sMin; s <= sMax; s++) {
		      	assert p <= 100;
		      	assert p > 0;
		      	
		      	System.out.println("\nGenerate PKT\nn = " + n + 
		      			", k = " + k + ", p = " + p + ", seed = " + s);
		
		          generatePKT(nb, k, p, s);	  
		          
		          int m = 0;
		          for (int i = 0; i < g.n; i++) {
		            m += g.degree[i];
		          }
		          m = m / 2;	 
		          
		          System.out.println("Graph generated, n = " + g.n + ", nEdges = " + m);
		          //g.writeTo(System.out); 
		          
		          g.cleanUp();
		          
		          m = 0;
		          for (int i = 0; i < g.n; i++) {
		            m += g.degree[i];
		          }
		          m = m / 2;	 	          
		          System.out.println("Graph cleaned, n = " + g.n + ", nEdges = " + m);

		          
		          MinDegree_NRNR md = new MinDegree_NRNR(g);
		          TreeDecomposition_NR td = md.decompose();
		          
		          System.out.println("Tree decomposition generated. Width = " + td.width);
		          	          	          
		          /**int m = 0;
		          for (int i = 0; i < g.n; i++) {
		            m += g.degree[i];
		          }
		          m = m / 2;	          
		          int predNoP = ( k * (n - k - 1) + k * (k + 1) / 2);
		          double pred = p * predNoP;
		          System.out.println("Predicted edges: " + pred );
		          System.out.println("Predicted edges without p: " + predNoP);
		          System.out.println("nEdges = " + m + "\n");
		          
		          String nameGraph = "graphs/pkt" + "_n" + n + "_k" +
		          k + "_p" + p + "_seed" + s + ".gr";
		          String nameSeps = "separators/pkt" + "_n" + n + "_k" +
				          k + "_p" + p + "_seed" + s + ".gr";
		          
		          File fileGraph = new File(path + nameGraph);
		          try {
		            PrintStream ps = new PrintStream(new FileOutputStream(fileGraph));
		            //ps.println("c partial k tree: n = " + n + 
		            		//", k = " + k + ", edge probability = " + p + "/100, seed = " + s);
		            g.writeTo(ps);
		            ps.close();
		          } catch (FileNotFoundException e) {
		            e.printStackTrace();
		          }
		          
		          File fileSeps = new File(path + nameSeps);
		          try {
		            PrintStream ps = new PrintStream(new FileOutputStream(fileSeps));
		            //ps.println("c partial k tree: n = " + n + 
		            		//", k = " + k + ", edge probability = " + p + "/100, seed = " + s);
		            td.writeTo(ps);
		            ps.close();
		          } catch (FileNotFoundException e) {
		            e.printStackTrace();
		          }*/
	      	}
	      }
	    }
    }
  }
  
  private static void singleTest() {
  	
  	int nb = 10; 
  	int k = 2;
  	int p = 100; //probability times 100 that an edge is present
  	int seed = 2;
  	
  	System.out.println("nb = " + nb + ", k = " + k + ", p = " + p + ", seed = " + seed);
    //generatePKT(5, 3, 100, 1);
    generatePKT(nb, k, p, seed);
    //  generatePKT(20, 5, 100, 1);
    //  generatePKT(20, 6, 50, 1);
    td.writeTo(System.out);
    System.out.println();
    //g.writeTo(System.out);
    td.validate();
  }
  
  public static void main(String args[]) {
  	//singleTest();
  	int nMin = 1000;
  	int nMax = 10000;
  	int kMin = 10;
  	int kMax = 80;
  	int pStep = 2; //Step size for the probability of an edge divided by k
  	int pCountMax = 3; //Number of steps for p to take
  	int sMin = 1;
  	int sMax = 3;
  	
    generateFiles(nMin, nMax, kMin, kMax, pStep, pCountMax, sMin, sMax);
//    generateFiles(40, 10, 10, 20);
//    generateFiles(100, 3, 15, 20);
//    generateFiles(200, 3, 15, 20);
//    generateFiles(1000, 2, 6, 70);
//    generateFiles(3000, 2, 3, 70);
  }
}
