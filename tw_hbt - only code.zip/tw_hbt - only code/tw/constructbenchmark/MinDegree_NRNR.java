package tw.constructbenchmark;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import tw.common.XBitSet;

public class MinDegree_NRNR {
  static boolean TRACE = false;
  static boolean TRACE_PROGRESS = false;
  static boolean TRACE_TIME = false;

  Graph_NR g;
  int[] pos; // pos[v] is the position of v in the constructed ordering
  static int[] dominator; //If a vertex is dominated by another vertex, it will be included in its bag in the TD.
  int[][] nb; //List of neighbor sets for all the vertices
  int[][] byDegree; //Sorted vertices by their degree
  int byDegreeSize;
  Vertex[] vertex;
  XBitSet remaining; //Vertices that are not eliminated yet
  int nRanked;
  int minDegree;
  int maxDegree;
  int[] bagIndex;
  TreeDecomposition_NR td;
  long fillTime;
  long deleteElementTime;
  long updateRankTime;
  int counter;

  
  public MinDegree_NRNR(Graph_NR g) {  	
    this.g = g;
    nb = g.neighbor.clone();    
    vertex = new Vertex[g.n];
    
    for (int v = 0; v < g.n; v++) {
      vertex[v] = new Vertex(v);
    }
  }
  
  public TreeDecomposition_NR decompose() {
  	long t0 = System.currentTimeMillis();
	
    order();
    
    long t1 = System.currentTimeMillis() - t0;
    if (TRACE_TIME) 
    	System.out.println("Time for order = " + t1 + " millisecs");
    
    constructTD();
    
    return td;
  }
  
  /**Worst case running time of O(n^3)
   * O(n) times:
   * O(m) for removeSelf
   * O(n^2) for fillNeighborhood
   * 
   * The difficulty comes from the fact that for very large */
  public void order() {
  	maxDegree = g.maxDegree(); 	
  	byDegreeSize = maxDegree + 1;
  	int[] initDegrees = new int [byDegreeSize];
  	int[] trackDegrees = new int[byDegreeSize];
  	counter = 0;
  	deleteElementTime = 0;
  	updateRankTime = 0;
  	
    nRanked = 0;
    remaining = (XBitSet) g.all.clone();
    minDegree = g.n;
  	
  	for (int v = 0; v < g.n; v++) {
  		initDegrees[vertex[v].degree]++;
  		if (vertex[v].degree < minDegree)
  			minDegree = vertex[v].degree;
  	}
  	
    byDegree = new int[byDegreeSize][];
    for (int i = 0; i < byDegreeSize; i++) {
      byDegree[i] = new int[initDegrees[i]];
    }
    
    for (int v = 0; v < g.n; v++) {
    	int deg = vertex[v].degree;
    	byDegree[deg][trackDegrees[deg]++] = v;
    }
    
    assert nRanked == g.n;
    
    // pos[v] is the position of v in the constructed ordering
    pos = new int[g.n]; 
    dominator = new int[g.n];
    Arrays.fill(pos, -1);
    int count = 0;
    
    long timeTotalWhile = System.currentTimeMillis();
    long timeA; long timeA2 = 0; long timeAbis; long timeA2bis = 0; long timeB; long timeB2 = 0; long timeC; long timeC2 = 0;
    long timeRemoveSelf = 0; long timeRemoveSelfA; long timeUpdateRank = 0; long timeUpdateRankA; 
    
        
    /**O(n) times:
     * O(m) for removeSelf
     * O(n^2) for fillNeighborhood*/
    while (!remaining.isEmpty()) {
      assert nRanked == remaining.cardinality();
      
      if(TRACE_PROGRESS && (g.n - nRanked) / 1000 > count) {
      	count++;
      	int eliminated = g.n - remaining.cardinality();
      	System.out.println("n = " + g.n  + "     nElimated: " + eliminated +  "     minDegree = " + minDegree + "     maxDegree = " + maxDegree);      	
      }

       //Take first ranked vertex
      timeA = System.currentTimeMillis();
      Vertex vert = firstRanked();
      timeA2 += System.currentTimeMillis() - timeA;
      
      int v = vert.id;     
      pos[v] = g.n - nRanked;
      dominator[v] = v;
      
      timeAbis = System.currentTimeMillis();
      vert.removeSelf(); 
      timeA2bis += System.currentTimeMillis() - timeAbis;
       

      timeB = System.currentTimeMillis(); 
      vert.fillNeighborhood();     
      timeB2 += System.currentTimeMillis() - timeB;     
      
      // update the rankings of the affected vertices
      /**This is not relevant for worst case running time, 
       * because the vertices that need to be removed 
       * are already calculated in remaining*/
      timeC = System.currentTimeMillis();
      for (int k = 0; k < nb[v].length; k++) {    	  
    	int w = nb[v][k];  
    	  
    	//If the neighborhood of w is a subset of the neighborhood of v, it can be removed. And w is dominated by v. 
        if (isSubset(nb[w],nb[v])) {
        	timeRemoveSelfA = System.currentTimeMillis();
          vertex[w].removeSelf();
          dominator[w] = v;  
          timeRemoveSelf += System.currentTimeMillis() - timeRemoveSelfA;  
        }   	          
        //Else update the ranking of w
        else {
        	timeUpdateRankA = System.currentTimeMillis();
          vertex[w].updateRank();
          timeUpdateRank += System.currentTimeMillis() - timeUpdateRankA;
        }
      }
      
      timeC2 += System.currentTimeMillis() - timeC;
      
    }
    
    long timeTotalWhileB = System.currentTimeMillis() - timeTotalWhile;
    
    if(TRACE_TIME) {
	    System.out.println("\nn = " + g.n + ", m = " + g.numberOfEdges());
	    System.out.println("Time for while loop: " + timeTotalWhileB);
	    System.out.println("   Time for firstRanked:       " + timeA2);
	    System.out.println("   Time for removeSelf:        " + timeA2bis);
	    System.out.println("   Time for fill neighborhood: " + timeB2);
	    System.out.println("   Time for for-loop:          " + timeC2);    
	    System.out.println("              Time for isSubset:   " + (timeC2 - timeUpdateRank - timeRemoveSelf)); 
	    System.out.println("              Time for removeSelf: " + timeRemoveSelf); 
	    System.out.println("              Time for updateRank: " + timeUpdateRank); 
	    System.out.println("   Time for deleteElement: " + deleteElementTime);
	    System.out.println("   Time for updateRank:    " + updateRankTime);
    }
    

    /*    if (TRACE) {
     for (int v = 0; v < g.n; v++) {
        System.out.println(v + ": pos = " + pos[v] + ", dominator = " + dominator[v]);
      }
    }*/
  }
  
  void constructTD() {
    bagIndex = new int[g.n];
    td = new TreeDecomposition_NR(0, getWidth(), g);
    for (int v = 0; v < g.n; v++) {
      if (dominator[v] == v) {    	
    	XBitSet bag = new XBitSet(g.n);
      for (int i = 0; i < nb[v].length; i++) {
      	bag.set(nb[v][i]);
      }  
      bag.set(v);
      bagIndex[v] = td.addBag(bag.toArray());
      }
    }
    for (int v = 0; v < g.n; v++) {
      if (dominator[v] == v) {
        int min = -1;
        for(int k = 0; k < nb[v].length; k++) {
          int w = nb[v][k];
          if (dominator[w] == v) {
            continue;
          }
          if (min == -1 || pos[dominator[w]] < pos[min]) {
            min = dominator[w];
          }
        }
        if (min != -1) {
          td.addEdge(bagIndex[v], bagIndex[min]);
        }
      }
    }
  }
  

  public int getWidth() {
    int width = 0;
    for (int v = 0; v < g.n; v++) {
      if (nb[v].length > width) {
        width = nb[v].length;
      }
    }
    return width;
  }


  //Determine which degree vertex we consider next, and return the vertex number with lowest degree.
  Vertex firstRanked() {
    while (byDegree[minDegree].length == 0) {
      minDegree++;
    }
    int id = byDegree[minDegree][0];
    return vertex[id];
  }


  class Vertex implements Comparable<Vertex> {
    int id; //number to distinguish vertex
    int degree;
    
    Vertex(int id) {
      this.id = id;
      evaluate();
    }
    
    /**worst case O(n^2)*/
    void fillNeighborhood() {   	
    	for(int i = 0; i < nb[id].length; i++) {    //for each neighbor v.
    		int v = nb[id][i];  
    		nb[v] = Graph_NR.getUnion(nb[v],nb[id]); /**O(degree1 + degree2)*/
    		vertex[v].deleteElement(v);
    		vertex[v].updateRank();
    	}
    }
    

    /**O(N) times ( O(neighbors) + for low degree O(n))
     * So for the relevant high degree vertices this is O(n m)*/
    public void removeSelf() {
    	remove_BD(degree,id);
    	for(int i = 0; i < nb[id].length; i++) {    //for each neighbor v.
    		int v = nb[id][i]; 
    		vertex[v].deleteElement(id);
    		vertex[v].updateRank(); 
    	}
    	nRanked--;
    	remaining.clear(id);
    }
    
    
    /**This is O(n) for low degree, but O(1) for high degree, because that's the complexity of addToRanked and remove_BD */
    public void updateRank() {
    	long time1 = System.currentTimeMillis();
      int oldDegree = degree;
      evaluate();
      if (degree != oldDegree) {
      	remove_BD(oldDegree,id);
        nRanked--;
        addToRanked();
      }
      updateRankTime += System.currentTimeMillis() - time1;
    }
    

    /**This is O(n) for low degree, but O(1) for high degree, because that's the complexity of add_BD */
    public void addToRanked() {       	

    	/*If the degree is larger than byDegreeSize, byDegree is enlarged to twice its size.*/
    	if(degree >= byDegreeSize) { 
    		byDegreeSize *= 2;
    		int[][] newByDegree = new int[byDegreeSize][];
    		      
        for (int i = 0; i < byDegreeSize/2; i++) {
          newByDegree[i] = byDegree[i];
        }       
        for (int i = byDegreeSize/2; i < byDegreeSize; i++) {
        	newByDegree[i] = new int[] {};
        }  
        
        byDegree = newByDegree;  
    	}
    	
    	add_BD(degree,id);
      nRanked++;
      
      if (degree > maxDegree)
      	maxDegree = degree;
      
      if (degree < minDegree) {
          minDegree = degree;
      }
    }

    
    /* Function to delete an element from the neighborhood */
    /**O(neighbors)*/
    public void deleteElement (int deleteV) { 
    	
    	long time = System.currentTimeMillis();
    	int newDegree = nb[id].length - 1;
      
      /*Find position of element to be deleted. If element not found, return*/
      int position = Arrays.binarySearch(nb[id], 0, newDegree + 1, deleteV);       
      if (position < 0) {
        return;
      } 
      
      /*Construct a new neighborhood array*/
      int[] newArray = new int[newDegree];      
      if(position == 0) {
      	System.arraycopy(nb[id], 1, newArray, 0, newDegree);
      }
      else {
	      System.arraycopy(nb[id], 0, newArray, 0, position);
	      System.arraycopy(nb[id], position + 1, newArray, position, newDegree - position);
      }
      nb[id] = newArray;
      deleteElementTime += System.currentTimeMillis() - time;
    } 
    

    //Determines the size of the average fill, needed for each vertex
    void evaluate() {
      degree = nb[id].length;
      assert degree > 0;
    }
    

    //Determines which vertex should be eliminated earlier.
    @Override
    public int compareTo(Vertex v) {
      if (degree == v.degree) {
        return id - v.id;
      }
      long diff = ((long) v.degree) - ((long) degree);
      if (diff < 0) {
        return -1;
      }
      else if (diff == 0){
        return v.degree - degree;
      }
      else {
        return 1;
      }
    }

    
    @Override
    public int hashCode() {
      return id;
    }

  }

  //Find the position of element 'key' in array 'arr'.
  /**public int binarySearch(int arr[], int low, int high, int key) 
  { 
      if (high < low) 
          return -1; 
      int mid = (low + high) / 2; 
      if (key == arr[mid]) 
          return mid; 
      if (key > arr[mid]) 
          return binarySearch(arr, (mid + 1), high, key); 
      return binarySearch(arr, low, (mid - 1), key); 
  }*/
  
  
  /* Return true if arr2[] is a subset of arr1[] */
  public boolean isSubset(int arr2[], int arr1[]) { 
      int i = 0, j = 0; 
      int m = arr1.length;
      int n = arr2.length;
      
      if(m < n) 
      return false; 

      while( i < n && j < m ) 
      { 
          if( arr1[j] < arr2[i] ) 
              j++; 
          else if( arr1[j] == arr2[i] ) 
          { 
              j++; 
              i++; 
          } 
          else if( arr1[j] > arr2[i] ) 
              return false; 
      } 
        
      if( i < n ) 
          return false; 
      else
          return true; 
  } 
 
  
  //Subtract array 2 from array 1.
  public int[] subtract(int arr1[], int arr2[]) { 
	    int i = 0, j = 0; 
	    int m = arr1.length;
	    int n = arr2.length;
	    
	    int[] newArray = new int[]{};
	    int degree = 0;
	    
	    //Iterate over array 2. Collect the elements in array 1 that are not in array 2.
	    while (i < m && j < n) { 
	    	
	    	if (arr1[i] < arr2[j]) {
	    		
	    		degree++;
	  	        newArray = Arrays.copyOf(newArray, degree);
	  	        newArray[degree - 1] = arr1[i++];
	    	}
	    	else if (arr2[j] < arr1[i])
	    		j++;
	    	else {
	    		i++;
	    		j++;
	    	}
	    }
	     
	    /* Collect remaining elements of array one*/
	    while(i < m) {
	        degree++;
	        newArray = Arrays.copyOf(newArray, degree);
	        newArray[degree - 1] = arr1[i++];
	    } 
	    return newArray;    
	  }  
  
  /*Remove a vertex from byDegree*/
  /**This is O(n) for low degree, but O(1) for high degree */
  public void remove_BD(int deg, int v) {
  	
  	int position = Arrays.binarySearch(byDegree[deg], 0, byDegree[deg].length, v); 
  	int newLength = byDegree[deg].length - 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength];      
    if(position == 0) {
    	System.arraycopy(byDegree[deg], 1, newArray, 0, newLength);
    }
    else {
      System.arraycopy(byDegree[deg], 0, newArray, 0, position);
      System.arraycopy(byDegree[deg], position + 1, newArray, position, newLength - position);
    }
    
    byDegree[deg] = newArray;
  }
  
  /*Add a vertex to byDegree*/
  /**This is O(n) for low degree, but O(1) for high degree */
  public void add_BD(int deg, int v) {
  	
  	int newLength = byDegree[deg].length + 1;
  	
    /*Construct a new neighborhood array*/
    int[] newArray = new int[newLength]; 
    
    if(byDegree[deg].length == 0)
    	newArray[0] = v;    
    else if(v < byDegree[deg][0]) {
    	newArray[0] = v;
    	System.arraycopy(byDegree[deg], 0, newArray, 1, newLength-1);
    }
    else {	    
	    int i = 0;
	    while(i < byDegree[deg].length && byDegree[deg][i] < v ) {
	    	newArray[i] = byDegree[deg][i];
	    	i++;
	    }
	    newArray[i] = v;
	    i++;
	    while(i < newLength) {
	    	newArray[i] = byDegree[deg][i-1];
	    	i++;
	    }
    }
    
    byDegree[deg] = newArray;
  } 

  public static void GenerateSeparators(String path, String name, Graph_NR graph) {
  	long t0 = System.currentTimeMillis();
  	
  	System.out.println(path + name);
  	
  	//Graph_NR g = Graph_NR.readGraph(path, name);
  	
    System.out.println("\nGraph " + name + " read, n = " + 
          graph.n + ", m = " + graph.numberOfEdges());

      
    MinDegree_NRNR md = new MinDegree_NRNR(graph);
    TreeDecomposition_NR td = md.decompose();

    File file = new File(path + name);
    try {
    	PrintStream ps = new PrintStream(new FileOutputStream(file));
      ps.println(name);
      td.writeTo(ps);
      ps.close();
      } 
    catch (FileNotFoundException e) {
          // TODO Auto-generated catch block
      e.printStackTrace();
    }

      
    long t1 = System.currentTimeMillis();
    System.out.println("width = " + td.width + ", nBags = " + td.nb + ", in " + (t1 - t0) + " millisecs");
  }
  
  
  public static void test(String path, String name) throws Exception{
	  
	long t0 = System.currentTimeMillis();
	Graph_NR g = Graph_NR.readGraph("instance/" + path, name);
	
	//g.writeTo(System.out);
	
    System.out.println("\nGraph " + name + " read, n = " + 
        g.n + ", m = " + g.numberOfEdges());
    // for (int v = 0; v < g.n; v++) {
    // System.out.println(v + ": " + g.degree[v] + ", " + g.neighborSet[v]);
    // }
    
    MinDegree_NRNR md = new MinDegree_NRNR(g);

    TreeDecomposition_NR td = md.decompose();

    
    long t1 = System.currentTimeMillis();
    System.out.println("width = " + td.width + ", nBags = " + td.nb + ", in " + (t1 - t0) + " millisecs");
    
    

    //System.out.println("Graph " + name + " read, n = " + g.n + ", m = " + g.numberOfEdges());
    
    //td.validate();
    //  td.printBags();
    //  td.writeTo(System.out);
  }
  public static void main(String args[]) throws Exception {
	  
  
	  test("pkt/graphs", "pkt_n1268556_k40_p0.075_seed1");
	  
	  /**for(int i = 10; i < 100; i=i+2) {
		  String s = "he0" + Integer.toString(i);
		  test("he2017secret", s);
	  }*/
	  
  }
}
